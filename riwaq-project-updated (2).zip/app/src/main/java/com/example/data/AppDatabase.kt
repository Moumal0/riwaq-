package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.RiwaqDao
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BookEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatThreadEntity
import com.example.data.model.WorkoutEntity
import com.example.data.model.SportPlanItemEntity
import com.example.data.model.SportPlanLogEntity
import com.example.data.model.MealEntity
import com.example.data.model.CalendarEventEntity
import com.example.data.model.DailyEnthusiasmRecord
import com.example.data.model.HabitEntity
import com.example.data.model.HabitLogEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NoteFolderEntity
import com.example.data.model.TaskEntity

@Database(
    entities = [
        TaskEntity::class,
        HabitEntity::class,
        HabitLogEntity::class,
        NoteFolderEntity::class,
        NoteEntity::class,
        BookEntity::class,
        CalendarEventEntity::class,
        DailyEnthusiasmRecord::class,
        ChatThreadEntity::class,
        ChatMessageEntity::class,
        WorkoutEntity::class,
        SportPlanItemEntity::class,
        SportPlanLogEntity::class,
        MealEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun riwaqDao(): RiwaqDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `chat_threads` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `chat_messages` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `threadId` INTEGER NOT NULL, `text` TEXT NOT NULL, `colorHex` TEXT NOT NULL, `isMine` INTEGER NOT NULL, `createdAtMillis` INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `workouts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `minutes` INTEGER NOT NULL, `note` TEXT NOT NULL, `dateString` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL)")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `chat_threads` ADD COLUMN `type` TEXT NOT NULL DEFAULT 'LOCAL'")
                db.execSQL("CREATE TABLE IF NOT EXISTS `sport_plan` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `dayIndex` INTEGER NOT NULL, `exerciseKey` TEXT NOT NULL, `detail` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `sport_plan_logs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `itemId` INTEGER NOT NULL, `dateString` TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `meals` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `calories` INTEGER NOT NULL, `mealType` TEXT NOT NULL, `dateString` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL)")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "riwaq_database.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
