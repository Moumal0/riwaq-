package com.example.data.chat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID

enum class LinkStatus { IDLE, LISTENING, CONNECTING, CONNECTED, ERROR }

data class LinkUi(
    val status: LinkStatus = LinkStatus.IDLE,
    val info: String = ""
)

/**
 * رابط محادثة نظير-لنظير: إما عبر شبكة Wi-Fi المحلية (TCP) أو Bluetooth الكلاسيكي (RFCOMM).
 * جهاز يستضيف وآخر يتصل. الرسائل غير مشفّرة؛ استخدمها مع أجهزة تثق بها فقط.
 */
class ChatLink(private val scope: CoroutineScope) {

    private val _ui = MutableStateFlow(LinkUi())
    val ui: StateFlow<LinkUi> = _ui

    /** (لون الرسالة، النص) */
    @Volatile var onReceive: ((String, String) -> Unit)? = null

    private var job: Job? = null
    @Volatile private var out: DataOutputStream? = null
    private val resources = mutableListOf<Closeable>()
    private val writeLock = Any()

    companion object {
        val BT_UUID: UUID = UUID.fromString("7c3a4e0e-5b52-4f6e-9d27-4a1f7d2f9a11")
        const val LAN_PORT = 8765
        private const val SEP = '\u0001'

        fun localIpAddress(): String? = try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }
                ?.hostAddress
        } catch (_: Exception) {
            null
        }
    }

    private fun track(c: Closeable) {
        synchronized(resources) { resources.add(c) }
    }

    private fun closeAll() {
        out = null
        synchronized(resources) {
            resources.forEach { try { it.close() } catch (_: Exception) {} }
            resources.clear()
        }
    }

    private fun start(block: suspend () -> Unit) {
        close()
        job = scope.launch(Dispatchers.IO) {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (_ui.value.status != LinkStatus.IDLE) {
                    _ui.value = LinkUi(LinkStatus.ERROR, "انقطع الاتصال: ${e.message ?: "خطأ غير معروف"}")
                }
            } finally {
                closeAll()
            }
        }
    }

    fun hostLan() = start {
        val server = ServerSocket(LAN_PORT)
        track(server)
        val ip = localIpAddress() ?: "غير معروف (تأكد من اتصال Wi-Fi)"
        _ui.value = LinkUi(LinkStatus.LISTENING, "بانتظار الاتصال... عنوانك: $ip  المنفذ: $LAN_PORT")
        val socket = server.accept()
        track(socket)
        pump(socket.getInputStream(), socket.getOutputStream(), "متصل عبر LAN")
    }

    fun connectLan(ip: String) = start {
        _ui.value = LinkUi(LinkStatus.CONNECTING, "جارٍ الاتصال بـ $ip ...")
        val socket = Socket()
        track(socket)
        socket.connect(InetSocketAddress(ip.trim(), LAN_PORT), 8000)
        pump(socket.getInputStream(), socket.getOutputStream(), "متصل عبر LAN")
    }

    @SuppressLint("MissingPermission")
    fun hostBluetooth(adapter: BluetoothAdapter) = start {
        val server = adapter.listenUsingRfcommWithServiceRecord("RiwaqChat", BT_UUID)
        track(server)
        _ui.value = LinkUi(LinkStatus.LISTENING, "بانتظار اتصال Bluetooth من جهاز مقترن...")
        val socket = server.accept()
        track(socket)
        pump(socket.inputStream, socket.outputStream, "متصل عبر Bluetooth")
    }

    @SuppressLint("MissingPermission")
    fun connectBluetooth(adapter: BluetoothAdapter, device: BluetoothDevice) = start {
        _ui.value = LinkUi(LinkStatus.CONNECTING, "جارٍ الاتصال بـ ${device.name ?: device.address} ...")
        try { adapter.cancelDiscovery() } catch (_: Exception) {}
        val socket = device.createRfcommSocketToServiceRecord(BT_UUID)
        track(socket)
        socket.connect()
        pump(socket.inputStream, socket.outputStream, "متصل عبر Bluetooth")
    }

    private fun pump(input: java.io.InputStream, output: java.io.OutputStream, label: String) {
        val dout = DataOutputStream(output.buffered())
        val din = DataInputStream(input.buffered())
        out = dout
        _ui.value = LinkUi(LinkStatus.CONNECTED, label)
        while (true) {
            val raw = din.readUTF() // يرمي EOFException عند الإغلاق
            val i = raw.indexOf(SEP)
            if (i > 0) onReceive?.invoke(raw.substring(0, i), raw.substring(i + 1))
        }
    }

    fun isConnected(): Boolean = _ui.value.status == LinkStatus.CONNECTED

    fun send(colorHex: String, text: String) {
        val target = out ?: return
        scope.launch(Dispatchers.IO) {
            try {
                synchronized(writeLock) {
                    target.writeUTF("$colorHex$SEP$text")
                    target.flush()
                }
            } catch (_: Exception) {
                _ui.value = LinkUi(LinkStatus.ERROR, "تعذّر إرسال الرسالة")
            }
        }
    }

    fun close() {
        job?.cancel()
        job = null
        _ui.value = LinkUi(LinkStatus.IDLE, "")
        closeAll()
    }
}
