package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BookEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatThreadEntity
import com.example.data.model.WorkoutEntity
import com.example.data.model.SportPlanItemEntity
import com.example.data.model.SportPlanLogEntity
import com.example.data.model.MealEntity
import com.example.data.model.CalendarEventEntity
import com.example.data.model.DailyEnthusiasmRecord
import com.example.data.model.HabitEntity
import com.example.data.model.HabitLogEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NoteFolderEntity
import com.example.data.model.TaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RiwaqDao {

    // --- Tasks ---
    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, dueDateMillis ASC, id DESC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE dueDateMillis BETWEEN :startOfDay AND :endOfDay")
    suspend fun getTasksForDateRange(startOfDay: Long, endOfDay: Long): List<TaskEntity>

    @Query("SELECT * FROM tasks")
    suspend fun getAllTasksSnapshot(): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<TaskEntity>)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Long)

    // --- Habits ---
    @Query("SELECT * FROM habits ORDER BY sortOrder ASC, id ASC")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits")
    suspend fun getAllHabitsSnapshot(): List<HabitEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabits(habits: List<HabitEntity>)

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("DELETE FROM habits WHERE id = :id")
    suspend fun deleteHabitById(id: Long)

    // --- Habit Logs ---
    @Query("SELECT * FROM habit_logs")
    fun getAllHabitLogs(): Flow<List<HabitLogEntity>>

    @Query("SELECT * FROM habit_logs")
    suspend fun getAllHabitLogsSnapshot(): List<HabitLogEntity>

    @Query("SELECT * FROM habit_logs WHERE dateString = :dateString")
    fun getHabitLogsForDate(dateString: String): Flow<List<HabitLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabitLog(log: HabitLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabitLogs(logs: List<HabitLogEntity>)

    @Query("DELETE FROM habit_logs WHERE habitId = :habitId AND dateString = :dateString")
    suspend fun deleteHabitLog(habitId: Long, dateString: String)

    @Query("DELETE FROM habit_logs WHERE habitId = :habitId")
    suspend fun deleteLogsForHabit(habitId: Long)

    // --- Note Folders ---
    @Query("SELECT * FROM note_folders ORDER BY name ASC")
    fun getAllFolders(): Flow<List<NoteFolderEntity>>

    @Query("SELECT * FROM note_folders")
    suspend fun getAllFoldersSnapshot(): List<NoteFolderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: NoteFolderEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolders(folders: List<NoteFolderEntity>)

    @Update
    suspend fun updateFolder(folder: NoteFolderEntity)

    @Delete
    suspend fun deleteFolder(folder: NoteFolderEntity)

    // --- Notes ---
    @Query("SELECT * FROM notes ORDER BY updatedAtMillis DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes")
    suspend fun getAllNotesSnapshot(): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE id = :id")
    fun getNoteById(id: Long): Flow<NoteEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotes(notes: List<NoteEntity>)

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Delete
    suspend fun deleteNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: Long)

    // --- Books ---
    @Query("SELECT * FROM books ORDER BY lastReadMillis DESC, id DESC")
    fun getAllBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books")
    suspend fun getAllBooksSnapshot(): List<BookEntity>

    @Query("SELECT * FROM books WHERE id = :id")
    fun getBookById(id: Long): Flow<BookEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: BookEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooks(books: List<BookEntity>)

    @Update
    suspend fun updateBook(book: BookEntity)

    @Delete
    suspend fun deleteBook(book: BookEntity)

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun deleteBookById(id: Long)

    // --- Calendar Events ---
    @Query("SELECT * FROM calendar_events ORDER BY dateString ASC, time ASC")
    fun getAllEvents(): Flow<List<CalendarEventEntity>>

    @Query("SELECT * FROM calendar_events")
    suspend fun getAllEventsSnapshot(): List<CalendarEventEntity>

    @Query("SELECT * FROM calendar_events WHERE dateString = :dateString ORDER BY time ASC")
    fun getEventsForDate(dateString: String): Flow<List<CalendarEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: CalendarEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<CalendarEventEntity>)

    @Update
    suspend fun updateEvent(event: CalendarEventEntity)

    @Delete
    suspend fun deleteEvent(event: CalendarEventEntity)

    @Query("DELETE FROM calendar_events WHERE id = :id")
    suspend fun deleteEventById(id: Long)

    // --- Daily Enthusiasm Records ---
    @Query("SELECT * FROM daily_enthusiasm_records ORDER BY dateString DESC")
    fun getAllEnthusiasmRecords(): Flow<List<DailyEnthusiasmRecord>>

    @Query("SELECT * FROM daily_enthusiasm_records")
    suspend fun getAllEnthusiasmRecordsSnapshot(): List<DailyEnthusiasmRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEnthusiasmRecord(record: DailyEnthusiasmRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEnthusiasmRecords(records: List<DailyEnthusiasmRecord>)

    // --- Sport plan ---
    @Query("SELECT * FROM sport_plan ORDER BY dayIndex ASC, id ASC")
    fun getSportPlan(): Flow<List<SportPlanItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSportPlanItem(item: SportPlanItemEntity): Long

    @Query("DELETE FROM sport_plan WHERE id = :id")
    suspend fun deleteSportPlanItem(id: Long)

    @Query("DELETE FROM sport_plan_logs WHERE itemId = :itemId")
    suspend fun deleteSportLogsOfItem(itemId: Long)

    @Query("DELETE FROM sport_plan WHERE dayIndex = :dayIndex")
    suspend fun deleteSportPlanDay(dayIndex: Int)

    @Query("SELECT * FROM sport_plan_logs")
    fun getSportPlanLogs(): Flow<List<SportPlanLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSportPlanLog(log: SportPlanLogEntity): Long

    @Query("DELETE FROM sport_plan_logs WHERE itemId = :itemId AND dateString = :dateString")
    suspend fun deleteSportPlanLog(itemId: Long, dateString: String)

    @Query("SELECT COUNT(*) FROM sport_plan_logs WHERE itemId = :itemId AND dateString = :dateString")
    suspend fun countSportPlanLog(itemId: Long, dateString: String): Int

    @Query("DELETE FROM sport_plan")
    suspend fun clearSportPlan()

    @Query("DELETE FROM sport_plan_logs")
    suspend fun clearSportPlanLogs()

    // --- Meals ---
    @Query("SELECT * FROM meals ORDER BY createdAtMillis DESC")
    fun getMeals(): Flow<List<MealEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeal(meal: MealEntity): Long

    @Query("DELETE FROM meals WHERE id = :id")
    suspend fun deleteMeal(id: Long)

    @Query("DELETE FROM meals")
    suspend fun clearMeals()

    // --- Workouts ---
    @Query("SELECT * FROM workouts ORDER BY createdAtMillis DESC")
    fun getWorkouts(): Flow<List<WorkoutEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkout(workout: WorkoutEntity): Long

    @Query("DELETE FROM workouts WHERE id = :id")
    suspend fun deleteWorkout(id: Long)

    @Query("DELETE FROM workouts")
    suspend fun clearWorkouts()

    // --- Chats ---
    @Query("SELECT * FROM chat_threads ORDER BY id DESC")
    fun getChatThreads(): Flow<List<ChatThreadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatThread(thread: ChatThreadEntity): Long

    @Query("DELETE FROM chat_threads WHERE id = :id")
    suspend fun deleteChatThread(id: Long)

    @Query("SELECT * FROM chat_messages WHERE threadId = :threadId ORDER BY createdAtMillis ASC, id ASC")
    fun getChatMessages(threadId: Long): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages WHERE threadId = :threadId")
    suspend fun deleteChatMessagesOfThread(threadId: Long)

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteChatMessage(id: Long)

    @Query("DELETE FROM chat_threads")
    suspend fun clearChatThreads()

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatMessages()

    // --- Global Operations ---
    @Query("DELETE FROM tasks")
    suspend fun clearTasks()

    @Query("DELETE FROM habits")
    suspend fun clearHabits()

    @Query("DELETE FROM habit_logs")
    suspend fun clearHabitLogs()

    @Query("DELETE FROM note_folders")
    suspend fun clearNoteFolders()

    @Query("DELETE FROM notes")
    suspend fun clearNotes()

    @Query("DELETE FROM books")
    suspend fun clearBooks()

    @Query("DELETE FROM calendar_events")
    suspend fun clearCalendarEvents()

    @Query("DELETE FROM daily_enthusiasm_records")
    suspend fun clearEnthusiasmRecords()
}
