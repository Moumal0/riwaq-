package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class AppSettings(
    val primaryColorHex: String = "#3B82F6",
    val backgroundColorHex: String = "#F8FAFC",
    val sidebarColorHex: String = "#92B4F8",
    val sidebarWidthDp: Int = 64,
    val sidebarPosition: String = "RIGHT", // "RIGHT" or "LEFT"
    val language: String = "AR", // "AR" or "EN"
    val libraryDisplayDirection: String = "VERTICAL", // "VERTICAL" or "HORIZONTAL"
    val calendarBoxColorHex: String = "#FFFFFF",
    val calendarHeaderColorHex: String = "#3B82F6",
    val calendarCellsColorHex: String = "#E8F0FE",
    val calendarDividersColorHex: String = "#E2E8F0",
    val calendarTextColorHex: String = "#1E293B",
    val calendarEventColorHex: String = "#E07A5F",
    val calendarCustomImagePath: String? = null,
    val notificationsDailyReminders: Boolean = true,
    val notificationsTaskReminders: Boolean = true,
    val notificationsHabitReminders: Boolean = true,
    val notificationsEnthusiasmReminders: Boolean = true,
    val lastEnthusiasmBurnViewedDate: String? = null,
    val fontScale: Float = 1.0f,
    val monoFont: Boolean = false
)
