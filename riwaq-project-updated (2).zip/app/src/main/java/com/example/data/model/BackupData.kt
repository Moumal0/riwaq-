package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class RiwaqBackupData(
    val version: Int = 1,
    val appName: String = "Riwaq",
    val exportDate: String,
    val tasks: List<TaskEntity> = emptyList(),
    val habits: List<HabitEntity> = emptyList(),
    val habitLogs: List<HabitLogEntity> = emptyList(),
    val noteFolders: List<NoteFolderEntity> = emptyList(),
    val notes: List<NoteEntity> = emptyList(),
    val books: List<BookEntity> = emptyList(),
    val calendarEvents: List<CalendarEventEntity> = emptyList(),
    val dailyEnthusiasmRecords: List<DailyEnthusiasmRecord> = emptyList(),
    val settings: AppSettings = AppSettings()
)

data class ImportSummary(
    val tasksCount: Int,
    val habitsCount: Int,
    val notesCount: Int,
    val booksCount: Int,
    val eventsCount: Int
)
