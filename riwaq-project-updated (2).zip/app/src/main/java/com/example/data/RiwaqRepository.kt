package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.data.dao.RiwaqDao
import com.example.data.model.BookEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatThreadEntity
import com.example.data.model.WorkoutEntity
import com.example.data.model.SportPlanItemEntity
import com.example.data.model.SportPlanLogEntity
import com.example.data.model.MealEntity
import com.example.data.model.CalendarEventEntity
import com.example.data.model.DailyEnthusiasmRecord
import com.example.data.model.HabitEntity
import com.example.data.model.HabitLogEntity
import com.example.data.model.NoteEntity
import com.example.data.model.NoteFolderEntity
import com.example.data.model.RiwaqBackupData
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class RiwaqRepository(
    private val dao: RiwaqDao,
    private val context: Context
) {

    // --- Tasks ---
    val allTasks: Flow<List<TaskEntity>> = dao.getAllTasks()

    suspend fun insertTask(task: TaskEntity): Long = dao.insertTask(task)
    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)
    suspend fun deleteTask(task: TaskEntity) = dao.deleteTask(task)
    suspend fun deleteTaskById(id: Long) = dao.deleteTaskById(id)

    suspend fun toggleTaskComplete(task: TaskEntity) {
        val updated = task.copy(
            isCompleted = !task.isCompleted,
            completedAtMillis = if (!task.isCompleted) System.currentTimeMillis() else null
        )
        dao.updateTask(updated)
        // Refresh enthusiasm record for this task's date
        recordEnthusiasmForDate(task.dueDateMillis)
    }

    // --- Habits ---
    val allHabits: Flow<List<HabitEntity>> = dao.getAllHabits()
    val allHabitLogs: Flow<List<HabitLogEntity>> = dao.getAllHabitLogs()

    suspend fun insertHabit(habit: HabitEntity): Long = dao.insertHabit(habit)
    suspend fun updateHabit(habit: HabitEntity) = dao.updateHabit(habit)
    suspend fun deleteHabit(habit: HabitEntity) {
        dao.deleteLogsForHabit(habit.id)
        dao.deleteHabit(habit)
    }

    suspend fun toggleHabitLog(habitId: Long, dateString: String, completed: Boolean) {
        if (completed) {
            dao.insertHabitLog(HabitLogEntity(habitId = habitId, dateString = dateString, isCompleted = true))
        } else {
            dao.deleteHabitLog(habitId, dateString)
        }
    }

    fun getHabitLogsForDate(dateString: String): Flow<List<HabitLogEntity>> =
        dao.getHabitLogsForDate(dateString)

    // --- Sport plan & meals ---
    val sportPlan: Flow<List<SportPlanItemEntity>> = dao.getSportPlan()
    val sportPlanLogs: Flow<List<SportPlanLogEntity>> = dao.getSportPlanLogs()
    val meals: Flow<List<MealEntity>> = dao.getMeals()

    suspend fun addSportPlanItem(dayIndex: Int, exerciseKey: String, detail: String) {
        dao.insertSportPlanItem(SportPlanItemEntity(dayIndex = dayIndex, exerciseKey = exerciseKey, detail = detail))
    }

    suspend fun deleteSportPlanItem(id: Long) {
        dao.deleteSportLogsOfItem(id)
        dao.deleteSportPlanItem(id)
    }

    suspend fun setDayRest(dayIndex: Int, rest: Boolean, currentItems: List<SportPlanItemEntity>) {
        currentItems.forEach { dao.deleteSportLogsOfItem(it.id) }
        dao.deleteSportPlanDay(dayIndex)
        if (rest) dao.insertSportPlanItem(SportPlanItemEntity(dayIndex = dayIndex, exerciseKey = "REST"))
    }

    suspend fun toggleSportPlanLog(itemId: Long, dateString: String) {
        if (dao.countSportPlanLog(itemId, dateString) > 0) dao.deleteSportPlanLog(itemId, dateString)
        else dao.insertSportPlanLog(SportPlanLogEntity(itemId = itemId, dateString = dateString))
    }

    suspend fun addMeal(name: String, calories: Int, mealType: String, dateString: String) {
        dao.insertMeal(MealEntity(name = name, calories = calories, mealType = mealType, dateString = dateString))
    }

    suspend fun deleteMeal(id: Long) = dao.deleteMeal(id)

    // --- Workouts ---
    val workouts: Flow<List<WorkoutEntity>> = dao.getWorkouts()

    suspend fun addWorkout(name: String, minutes: Int, note: String, dateString: String) {
        dao.insertWorkout(WorkoutEntity(name = name, minutes = minutes, note = note, dateString = dateString))
    }

    suspend fun deleteWorkout(id: Long) = dao.deleteWorkout(id)

    // --- Chats ---
    val chatThreads: Flow<List<ChatThreadEntity>> = dao.getChatThreads()

    fun chatMessages(threadId: Long): Flow<List<ChatMessageEntity>> = dao.getChatMessages(threadId)

    suspend fun createChatThread(title: String, type: String): Long = dao.insertChatThread(ChatThreadEntity(title = title, type = type))

    suspend fun deleteChatThread(id: Long) {
        dao.deleteChatMessagesOfThread(id)
        dao.deleteChatThread(id)
    }

    suspend fun sendChatMessage(threadId: Long, text: String, colorHex: String, isMine: Boolean) {
        dao.insertChatMessage(ChatMessageEntity(threadId = threadId, text = text, colorHex = colorHex, isMine = isMine))
    }

    suspend fun deleteChatMessage(id: Long) = dao.deleteChatMessage(id)

    // --- Notes ---
    val allNotes: Flow<List<NoteEntity>> = dao.getAllNotes()
    val allFolders: Flow<List<NoteFolderEntity>> = dao.getAllFolders()

    fun getNoteById(id: Long): Flow<NoteEntity?> = dao.getNoteById(id)

    suspend fun insertFolder(name: String): Long =
        dao.insertFolder(NoteFolderEntity(name = name))

    suspend fun deleteFolder(folder: NoteFolderEntity) = dao.deleteFolder(folder)

    suspend fun saveNote(id: Long, title: String, content: String, folderId: Long?): Long {
        return if (id == 0L) {
            dao.insertNote(
                NoteEntity(
                    title = title,
                    content = content,
                    folderId = folderId,
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
        } else {
            dao.updateNote(
                NoteEntity(
                    id = id,
                    title = title,
                    content = content,
                    folderId = folderId,
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
            id
        }
    }

    suspend fun deleteNote(note: NoteEntity) = dao.deleteNote(note)

    // --- Books & PDF ---
    val allBooks: Flow<List<BookEntity>> = dao.getAllBooks()

    fun getBookById(id: Long): Flow<BookEntity?> = dao.getBookById(id)

    suspend fun importPdfBook(uri: Uri, fileName: String): Result<BookEntity> = withContext(Dispatchers.IO) {
        try {
            val booksDir = File(context.filesDir, "riwaq_books").apply { if (!exists()) mkdirs() }
            val cleanName = fileName.replace("[^a-zA-Z0-9_.-]".toRegex(), "_")
            val targetFile = File(booksDir, "${System.currentTimeMillis()}_$cleanName")

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("تعذر فتح ملف PDF المحدد"))

            // Determine page count
            var pageCount = 1
            try {
                ParcelFileDescriptor.open(targetFile, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        pageCount = renderer.pageCount.coerceAtLeast(1)
                    }
                }
            } catch (e: Exception) {
                // Keep default 1 if metadata reading has issue
            }

            val title = fileName.substringBeforeLast(".")
            val book = BookEntity(
                title = title.ifBlank { "كتاب بدون عنوان" },
                internalPdfPath = targetFile.absolutePath,
                currentPage = 0,
                totalPages = pageCount,
                isCompleted = false,
                lastReadMillis = System.currentTimeMillis()
            )
            val id = dao.insertBook(book)
            Result.success(book.copy(id = id))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateBookProgress(bookId: Long, page: Int) {
        val snapshot = dao.getAllBooksSnapshot().find { it.id == bookId } ?: return
        val isCompleted = page >= snapshot.totalPages - 1
        dao.updateBook(
            snapshot.copy(
                currentPage = page,
                isCompleted = isCompleted,
                lastReadMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateBookCover(bookId: Long, imageUri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val coversDir = File(context.filesDir, "riwaq_covers").apply { if (!exists()) mkdirs() }
            val targetFile = File(coversDir, "cover_${bookId}_${System.currentTimeMillis()}.png")

            context.contentResolver.openInputStream(imageUri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("تعذر قراءة صورة الغلاف"))

            val snapshot = dao.getAllBooksSnapshot().find { it.id == bookId }
                ?: return@withContext Result.failure(IllegalStateException("الكتاب غير موجود"))

            dao.updateBook(snapshot.copy(coverImagePath = targetFile.absolutePath))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun renameBook(bookId: Long, newTitle: String) {
        val snapshot = dao.getAllBooksSnapshot().find { it.id == bookId } ?: return
        dao.updateBook(snapshot.copy(title = newTitle))
    }

    suspend fun deleteBook(book: BookEntity) = withContext(Dispatchers.IO) {
        try {
            File(book.internalPdfPath).delete()
            book.coverImagePath?.let { File(it).delete() }
        } catch (_: Exception) {}
        dao.deleteBook(book)
    }

    // --- Calendar Events ---
    val allCalendarEvents: Flow<List<CalendarEventEntity>> = dao.getAllEvents()

    fun getCalendarEventsForDate(dateString: String): Flow<List<CalendarEventEntity>> =
        dao.getEventsForDate(dateString)

    suspend fun insertCalendarEvent(event: CalendarEventEntity): Long =
        dao.insertEvent(event)

    suspend fun deleteCalendarEvent(event: CalendarEventEntity) =
        dao.deleteEvent(event)

    // --- Enthusiasm Records & Calculation ---
    val allEnthusiasmRecords: Flow<List<DailyEnthusiasmRecord>> = dao.getAllEnthusiasmRecords()

    suspend fun recordEnthusiasmForDate(timestampMillis: Long) = withContext(Dispatchers.IO) {
        val cal = Calendar.getInstance().apply { timeInMillis = timestampMillis }
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val startOfDay = cal.timeInMillis

        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        val endOfDay = cal.timeInMillis

        val dateString = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(timestampMillis))
        val tasks = dao.getTasksForDateRange(startOfDay, endOfDay)
        if (tasks.isNotEmpty()) {
            val completed = tasks.count { it.isCompleted }
            val percentage = (completed.toFloat() / tasks.size.toFloat()) * 100f
            val achieved = percentage >= 85f
            dao.insertEnthusiasmRecord(
                DailyEnthusiasmRecord(
                    dateString = dateString,
                    isAchieved = achieved,
                    completionPercentage = percentage,
                    totalTasks = tasks.size,
                    completedTasks = completed,
                    timestampMillis = System.currentTimeMillis()
                )
            )
        }
    }

    // --- Backup & Restore ---
    suspend fun createBackupPayload(): RiwaqBackupData = withContext(Dispatchers.IO) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        RiwaqBackupData(
            version = 1,
            appName = "Riwaq",
            exportDate = dateFormat.format(Date()),
            tasks = dao.getAllTasksSnapshot(),
            habits = dao.getAllHabitsSnapshot(),
            habitLogs = dao.getAllHabitLogsSnapshot(),
            noteFolders = dao.getAllFoldersSnapshot(),
            notes = dao.getAllNotesSnapshot(),
            books = dao.getAllBooksSnapshot(),
            calendarEvents = dao.getAllEventsSnapshot(),
            dailyEnthusiasmRecords = dao.getAllEnthusiasmRecordsSnapshot()
        )
    }

    suspend fun restoreBackup(backup: RiwaqBackupData, replaceExisting: Boolean) = withContext(Dispatchers.IO) {
        if (replaceExisting) {
            dao.clearTasks()
            dao.clearHabits()
            dao.clearHabitLogs()
            dao.clearNoteFolders()
            dao.clearNotes()
            dao.clearBooks()
            dao.clearCalendarEvents()
            dao.clearEnthusiasmRecords()
        }

        dao.insertTasks(backup.tasks)
        dao.insertHabits(backup.habits)
        dao.insertHabitLogs(backup.habitLogs)
        dao.insertFolders(backup.noteFolders)
        dao.insertNotes(backup.notes)
        dao.insertBooks(backup.books)
        dao.insertEvents(backup.calendarEvents)
        dao.insertEnthusiasmRecords(backup.dailyEnthusiasmRecords)
    }

    suspend fun clearAllUserData() = withContext(Dispatchers.IO) {
        dao.clearTasks()
        dao.clearHabits()
        dao.clearHabitLogs()
        dao.clearNoteFolders()
        dao.clearNotes()
        dao.clearBooks()
        dao.clearCalendarEvents()
        dao.clearEnthusiasmRecords()
        dao.clearChatMessages()
        dao.clearWorkouts()
        dao.clearSportPlanLogs()
        dao.clearSportPlan()
        dao.clearMeals()
        dao.clearChatThreads()
        try {
            File(context.filesDir, "riwaq_books").deleteRecursively()
            File(context.filesDir, "riwaq_covers").deleteRecursively()
            File(context.filesDir, "calendar_avatar.png").delete()
        } catch (_: Exception) {}
    }
}
