package com.example.data

import android.content.Context
import android.net.Uri
import com.example.data.model.ImportSummary
import com.example.data.model.RiwaqBackupData
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class DocxBackupManager(private val context: Context) {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val adapter = moshi.adapter(RiwaqBackupData::class.java).indent("  ")

    suspend fun exportToDocx(backupData: RiwaqBackupData, outputStream: OutputStream): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val jsonString = adapter.toJson(backupData)
                val zipOut = ZipOutputStream(outputStream)

                // 1. [Content_Types].xml
                zipOut.putNextEntry(ZipEntry("[Content_Types].xml"))
                zipOut.write(getContentTypesXml().toByteArray(Charsets.UTF_8))
                zipOut.closeEntry()

                // 2. _rels/.rels
                zipOut.putNextEntry(ZipEntry("_rels/.rels"))
                zipOut.write(getRootRelsXml().toByteArray(Charsets.UTF_8))
                zipOut.closeEntry()

                // 3. customXml/riwaq_backup.json (Machine-readable internal backup payload)
                zipOut.putNextEntry(ZipEntry("customXml/riwaq_backup.json"))
                zipOut.write(jsonString.toByteArray(Charsets.UTF_8))
                zipOut.closeEntry()

                // 4. word/document.xml (Human-readable beautifully formatted Arabic Word doc)
                zipOut.putNextEntry(ZipEntry("word/document.xml"))
                zipOut.write(generateWordDocumentXml(backupData).toByteArray(Charsets.UTF_8))
                zipOut.closeEntry()

                zipOut.finish()
                zipOut.flush()
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /** تصدير مشفّر: JSON مضغوط ثم مشفّر بـ AES-256-GCM. لا يوجد أي جزء مقروء في الملف. */
    suspend fun exportEncrypted(backupData: RiwaqBackupData, outputStream: OutputStream, password: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val json = adapter.toJson(backupData).toByteArray(Charsets.UTF_8)
                val bos = ByteArrayOutputStream()
                GZIPOutputStream(bos).use { it.write(json) }
                outputStream.write(BackupCrypto.encrypt(bos.toByteArray(), password))
                outputStream.flush()
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /** قراءة نسخة: مشفّرة (.riwaq) أو قديمة غير مشفّرة (.docx). */
    suspend fun inspectBackup(bytes: ByteArray, password: String?): Result<RiwaqBackupData> =
        withContext(Dispatchers.IO) {
            try {
                if (BackupCrypto.isEncrypted(bytes)) {
                    if (password.isNullOrEmpty()) {
                        Result.failure(BackupPasswordRequiredException())
                    } else {
                        val plain = BackupCrypto.decrypt(bytes, password)
                        val json = GZIPInputStream(plain.inputStream()).use { it.readBytes() }.toString(Charsets.UTF_8)
                        val parsed = adapter.fromJson(json)
                        if (parsed == null || parsed.appName != "Riwaq") {
                            Result.failure(IllegalStateException("بيانات النسخة الاحتياطية غير صالحة أو تالفة"))
                        } else {
                            Result.success(parsed)
                        }
                    }
                } else {
                    inspectDocxBackup(bytes.inputStream())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun inspectDocxBackup(inputStream: InputStream): Result<RiwaqBackupData> =
        withContext(Dispatchers.IO) {
            try {
                val zipIn = ZipInputStream(inputStream)
                var backupJson: String? = null
                var entry: ZipEntry? = zipIn.nextEntry
                while (entry != null) {
                    if (entry.name == "customXml/riwaq_backup.json" || entry.name.endsWith("riwaq_backup.json")) {
                        val baos = ByteArrayOutputStream()
                        val buffer = ByteArray(1024)
                        var read: Int
                        while (zipIn.read(buffer).also { read = it } != -1) {
                            baos.write(buffer, 0, read)
                        }
                        backupJson = baos.toString("UTF-8")
                        break
                    }
                    zipIn.closeEntry()
                    entry = zipIn.nextEntry
                }

                if (backupJson == null) {
                    Result.failure(IllegalStateException("الملف المحدد لا يحتوي على بيانات نسخة احتياطية من تطبيق رِواق"))
                } else {
                    val parsed = adapter.fromJson(backupJson)
                    if (parsed == null || parsed.appName != "Riwaq") {
                        Result.failure(IllegalStateException("بيانات النسخة الاحتياطية غير صالحة أو تالفة"))
                    } else {
                        Result.success(parsed)
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun getContentTypesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Default Extension="json" ContentType="application/json"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>""".trimIndent()

    private fun getRootRelsXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/customXml" Target="customXml/riwaq_backup.json"/>
</Relationships>""".trimIndent()

    private fun escapeXml(text: String): String {
        return text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun generateWordDocumentXml(data: RiwaqBackupData): String {
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar"))
        val exportTime = dateFormat.format(Date())

        val completedTasksCount = data.tasks.count { it.isCompleted }
        val totalTasksCount = data.tasks.size
        val taskRate = if (totalTasksCount > 0) "${(completedTasksCount * 100) / totalTasksCount}%" else "0%"

        val totalHabits = data.habits.size
        val totalNotes = data.notes.size
        val totalBooks = data.books.size
        val totalEvents = data.calendarEvents.size

        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">""")
        sb.append("""<w:body>""")

        // Title
        sb.append(paragraph("رِواق — Riwaq", isHeading = true, size = 48, isCenter = true))
        sb.append(paragraph("تقرير ونسخة احتياطية لبيانات التطبيق", isHeading = false, size = 26, isCenter = true))
        sb.append(paragraph("تاريخ التصدير: $exportTime", isHeading = false, size = 22, isCenter = true))
        sb.append(paragraph("", isHeading = false, size = 20))

        // Section: الإحصائيات العامة
        sb.append(paragraph("1. الإحصائيات العامة", isHeading = true, size = 32))
        sb.append(paragraph("• معدل إنجاز المهام: $taskRate ($completedTasksCount من أصل $totalTasksCount مكتملة)", size = 24))
        sb.append(paragraph("• إجمالي العادات المسجلة: $totalHabits", size = 24))
        sb.append(paragraph("• إجمالي الكتب في المكتبة: $totalBooks", size = 24))
        sb.append(paragraph("• إجمالي الملاحظات: $totalNotes", size = 24))
        sb.append(paragraph("• إجمالي الأحداث في التقويم: $totalEvents", size = 24))
        sb.append(paragraph("", isHeading = false, size = 20))

        // Section: المهام
        sb.append(paragraph("2. قائمة المهام", isHeading = true, size = 32))
        if (data.tasks.isEmpty()) {
            sb.append(paragraph("لا توجد مهام مسجلة.", size = 24))
        } else {
            data.tasks.forEachIndexed { index, task ->
                val status = if (task.isCompleted) "✓ مكتملة" else "✕ غير مكتملة"
                val priority = when (task.priority.name) {
                    "URGENT" -> "طارئة"
                    "MEDIUM" -> "متوسطة"
                    else -> "عادية"
                }
                val due = SimpleDateFormat("yyyy/MM/dd", Locale("ar")).format(Date(task.dueDateMillis))
                sb.append(paragraph("${index + 1}. ${escapeXml(task.title)} [الأولوية: $priority | الحالة: $status | التاريخ: $due]", size = 22))
            }
        }
        sb.append(paragraph("", isHeading = false, size = 20))

        // Section: العادات
        sb.append(paragraph("3. قائمة العادات", isHeading = true, size = 32))
        if (data.habits.isEmpty()) {
            sb.append(paragraph("لا توجد عادات مسجلة.", size = 24))
        } else {
            data.habits.forEachIndexed { index, habit ->
                val freq = if (habit.isEveryDay) "كل يوم" else "أيام محددة"
                sb.append(paragraph("${index + 1}. ${escapeXml(habit.title)} [التكرار: $freq]", size = 22))
            }
        }
        sb.append(paragraph("", isHeading = false, size = 20))

        // Section: المكتبة والكتب
        sb.append(paragraph("4. الكتب والمكتبة", isHeading = true, size = 32))
        if (data.books.isEmpty()) {
            sb.append(paragraph("لا توجد كتب في المكتبة.", size = 24))
        } else {
            data.books.forEachIndexed { index, book ->
                val progress = if (book.totalPages > 0) "${(book.currentPage * 100) / book.totalPages}%" else "0%"
                sb.append(paragraph("${index + 1}. ${escapeXml(book.title)} [الصفحة: ${book.currentPage} من ${book.totalPages} — التقدم: $progress]", size = 22))
            }
        }
        sb.append(paragraph("", isHeading = false, size = 20))

        // Section: الملاحظات
        sb.append(paragraph("5. الملاحظات والمجلدات", isHeading = true, size = 32))
        if (data.notes.isEmpty()) {
            sb.append(paragraph("لا توجد ملاحظات مسجلة.", size = 24))
        } else {
            val folderMap = data.noteFolders.associateBy { it.id }
            data.notes.forEachIndexed { index, note ->
                val folderName = folderMap[note.folderId]?.name ?: "بدون مجلد"
                sb.append(paragraph("${index + 1}. ${escapeXml(note.title)} (المجلد: ${escapeXml(folderName)})", isHeading = true, size = 24))
                if (note.content.isNotBlank()) {
                    sb.append(paragraph(escapeXml(note.content), size = 20))
                }
            }
        }
        sb.append(paragraph("", isHeading = false, size = 20))

        // Section: أحداث التقويم
        sb.append(paragraph("6. أحداث التقويم", isHeading = true, size = 32))
        if (data.calendarEvents.isEmpty()) {
            sb.append(paragraph("لا توجد أحداث مسجلة في التقويم.", size = 24))
        } else {
            data.calendarEvents.forEachIndexed { index, ev ->
                sb.append(paragraph("${index + 1}. ${escapeXml(ev.title)} [التاريخ: ${ev.dateString}${if (ev.time.isNotBlank()) " - ${ev.time}" else ""}]", size = 22))
            }
        }

        sb.append("""</w:body>""")
        sb.append("""</w:document>""")
        return sb.toString()
    }

    private fun paragraph(text: String, isHeading: Boolean = false, size: Int = 24, isCenter: Boolean = false): String {
        val align = if (isCenter) """<w:jc w:val="center"/>""" else """<w:jc w:val="right"/>"""
        val bold = if (isHeading) """<w:b/>""" else ""
        return """
        <w:p>
            <w:pPr>
                $align
                <w:bidi/>
            </w:pPr>
            <w:r>
                <w:rPr>
                    <w:rtl/>
                    <w:rFonts w:ascii="Arial" w:cs="Arial"/>
                    <w:sz w:val="$size"/>
                    $bold
                </w:rPr>
                <w:t>$text</w:t>
            </w:r>
        </w:p>
        """.trimIndent()
    }
}
