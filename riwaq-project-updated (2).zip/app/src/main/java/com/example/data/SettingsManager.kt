package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppSettings
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("riwaq_app_settings", Context.MODE_PRIVATE)

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val adapter = moshi.adapter(AppSettings::class.java)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        val json = prefs.getString(KEY_SETTINGS_JSON, null) ?: return AppSettings()
        return try {
            adapter.fromJson(json) ?: AppSettings()
        } catch (_: Exception) {
            AppSettings()
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        _settings.value = newSettings
        try {
            val json = adapter.toJson(newSettings)
            prefs.edit().putString(KEY_SETTINGS_JSON, json).apply()
        } catch (_: Exception) {}
    }

    fun resetSettings() {
        val defaultSettings = AppSettings()
        updateSettings(defaultSettings)
    }

    companion object {
        private const val KEY_SETTINGS_JSON = "key_riwaq_settings_json"
    }
}
