package com.example.data

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class BackupPasswordRequiredException : Exception("هذا الملف مشفّر ويتطلب رمز المرور")
class WrongBackupPasswordException : Exception("رمز المرور غير صحيح أو الملف تالف")

/**
 * تشفير النسخ الاحتياطية: AES-256-GCM مع مفتاح مُشتق من رمز المرور بخوارزمية PBKDF2.
 * التنسيق: "RIWAQENC" + نسخة KDF (1 بايت) + salt(16) + iv(12) + البيانات المشفرة.
 */
object BackupCrypto {
    private val MAGIC = "RIWAQENC".toByteArray(Charsets.US_ASCII)
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val ITERATIONS = 150_000

    fun isEncrypted(bytes: ByteArray): Boolean {
        if (bytes.size <= MAGIC.size + 1 + SALT_LEN + IV_LEN) return false
        for (i in MAGIC.indices) if (bytes[i] != MAGIC[i]) return false
        return true
    }

    private fun deriveKey(password: String, salt: ByteArray, kdf: Int): SecretKeySpec {
        val algorithm = if (kdf == 1) "PBKDF2WithHmacSHA256" else "PBKDF2WithHmacSHA1"
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        val keyBytes = SecretKeyFactory.getInstance(algorithm).generateSecret(spec).encoded
        return SecretKeySpec(keyBytes, "AES")
    }

    fun encrypt(plain: ByteArray, password: String): ByteArray {
        val kdf = try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            1
        } catch (_: Exception) {
            2
        }
        val random = SecureRandom()
        val salt = ByteArray(SALT_LEN).also { random.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { random.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(password, salt, kdf), GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(plain)
        return MAGIC + byteArrayOf(kdf.toByte()) + salt + iv + encrypted
    }

    fun decrypt(data: ByteArray, password: String): ByteArray {
        var pos = MAGIC.size
        val kdf = data[pos].toInt()
        pos += 1
        val salt = data.copyOfRange(pos, pos + SALT_LEN)
        pos += SALT_LEN
        val iv = data.copyOfRange(pos, pos + IV_LEN)
        pos += IV_LEN
        val body = data.copyOfRange(pos, data.size)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, deriveKey(password, salt, kdf), GCMParameterSpec(128, iv))
            cipher.doFinal(body)
        } catch (_: Exception) {
            throw WrongBackupPasswordException()
        }
    }
}
