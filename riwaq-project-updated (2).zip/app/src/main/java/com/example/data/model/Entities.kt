package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

enum class TaskPriority {
    NORMAL,  // عادية (green)
    MEDIUM,  // متوسطة (yellow/orange)
    URGENT   // طارئة / عاجلة (red)
}

@Entity(tableName = "tasks")
@JsonClass(generateAdapter = true)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val dueDateMillis: Long = System.currentTimeMillis(),
    val priority: TaskPriority = TaskPriority.NORMAL,
    val durationMinutes: Int = 15,
    val isCompleted: Boolean = false,
    val completedAtMillis: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "habits")
@JsonClass(generateAdapter = true)
data class HabitEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val isEveryDay: Boolean = true,
    // Comma separated day indices (0=Saturday, 1=Sunday, 2=Monday, 3=Tuesday, 4=Wednesday, 5=Thursday, 6=Friday)
    val targetDays: String = "0,1,2,3,4,5,6",
    val habitTime: String = "",
    val sortOrder: Int = 0,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "habit_logs", primaryKeys = ["habitId", "dateString"])
@JsonClass(generateAdapter = true)
data class HabitLogEntity(
    val habitId: Long,
    val dateString: String, // format: "YYYY-MM-DD"
    val isCompleted: Boolean = true,
    val timestampMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "note_folders")
@JsonClass(generateAdapter = true)
data class NoteFolderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
@JsonClass(generateAdapter = true)
data class NoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val folderId: Long? = null,
    val title: String,
    val content: String,
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "books")
@JsonClass(generateAdapter = true)
data class BookEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val internalPdfPath: String,
    val coverImagePath: String? = null,
    val currentPage: Int = 0,
    val totalPages: Int = 1,
    val isCompleted: Boolean = false,
    val lastReadMillis: Long = System.currentTimeMillis(),
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "calendar_events")
@JsonClass(generateAdapter = true)
data class CalendarEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val dateString: String, // format: "YYYY-MM-DD"
    val time: String = "",
    val colorHex: String = "#92B4F8",
    val note: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_enthusiasm_records")
@JsonClass(generateAdapter = true)
data class DailyEnthusiasmRecord(
    @PrimaryKey
    val dateString: String, // format: "YYYY-MM-DD"
    val isAchieved: Boolean = false, // completed >= 85% tasks for that day
    val completionPercentage: Float = 0f,
    val totalTasks: Int = 0,
    val completedTasks: Int = 0,
    val timestampMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_threads")
data class ChatThreadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    // LOCAL = محلية، BLUETOOTH، LAN
    val type: String = "LOCAL",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val threadId: Long,
    val text: String,
    val colorHex: String,
    val isMine: Boolean = true,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "workouts")
data class WorkoutEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val minutes: Int,
    val note: String = "",
    val dateString: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "sport_plan")
data class SportPlanItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    // 0=السبت ... 6=الجمعة (نفس ترقيم العادات)
    val dayIndex: Int,
    // مفتاح التمرين من المكتبة، أو REST ليوم الراحة
    val exerciseKey: String,
    val detail: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "sport_plan_logs")
data class SportPlanLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val itemId: Long,
    val dateString: String
)

@Entity(tableName = "meals")
data class MealEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val calories: Int,
    val mealType: String,
    val dateString: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)
