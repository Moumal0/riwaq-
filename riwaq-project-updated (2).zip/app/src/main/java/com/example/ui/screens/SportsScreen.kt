package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import android.content.Context
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import com.example.data.model.MealEntity
import com.example.data.model.SportPlanItemEntity
import com.example.ui.theme.RiwaqPriorityGreen
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private val QuickExercises = listOf("جري", "مشي", "أثقال", "سباحة", "دراجة", "يوغا", "كرة قدم")

@Composable
private fun SportLogPane(viewModel: RiwaqViewModel, modifier: Modifier = Modifier) {
    val workouts by viewModel.workouts.collectAsStateWithLifecycle()
    var name by remember { mutableStateOf("") }
    var minutesText by remember { mutableStateOf("30") }

    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val todayStr = remember { sdf.format(Calendar.getInstance().time) }
    val weekStart = remember {
        sdf.format(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -6) }.time)
    }
    val weekWorkouts = remember(workouts) { workouts.filter { it.dateString >= weekStart && it.dateString <= todayStr } }
    val weekMinutes = weekWorkouts.sumOf { it.minutes }
    val todayMinutes = workouts.filter { it.dateString == todayStr }.sumOf { it.minutes }
    val activeDays = weekWorkouts.map { it.dateString }.toSet().size

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatBox("اليوم", "$todayMinutes د", Modifier.weight(1f))
                StatBox("آخر 7 أيام", "$weekMinutes د", Modifier.weight(1f))
                StatBox("أيام نشطة", "$activeDays/7", Modifier.weight(1f))
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(text = "تسجيل تمرين", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(QuickExercises, key = { it }) { ex ->
                        Text(
                            text = ex,
                            fontSize = 12.sp,
                            color = if (name == ex) Color.White else RiwaqBlue,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (name == ex) RiwaqBlue else Color(0xFFE8F0FE))
                                .clickable { name = ex }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم التمرين") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = minutesText,
                        onValueChange = { minutesText = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("الدقائق") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        val m = minutesText.toIntOrNull() ?: 0
                        if (name.isNotBlank() && m > 0) {
                            viewModel.addWorkout(name, m)
                            name = ""
                        }
                    }) { Text("إضافة", color = RiwaqBlue, fontWeight = FontWeight.Bold) }
                }
            }
        }

        if (workouts.isEmpty()) {
            item {
                EmptyStateView(
                    title = "لا توجد تمارين مسجلة",
                    subtitle = "سجّل أول تمرين لك لتبدأ المتابعة"
                )
            }
        } else {
            items(workouts.take(50), key = { "w_${it.id}" }) { w ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(1.dp, RiwaqCardBorder, RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = w.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = RiwaqTextPrimary)
                        Text(text = "${w.dateString} · ${w.minutes} د", fontSize = 12.sp, color = RiwaqTextMuted)
                    }
                    IconButton(onClick = { viewModel.deleteWorkout(w.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RiwaqPriorityRed)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(14.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = RiwaqBlue)
        Text(text = label, fontSize = 11.sp, color = RiwaqTextSecondary)
    }
}


private val DayNamesAr = listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
private val DayNamesEn = listOf("Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri")
private val MealTypes = listOf("فطور", "غداء", "عشاء", "وجبة خفيفة")

private fun todayIndex(): Int = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) % 7 // 0 = السبت

private fun dateForDayIndex(idx: Int): String {
    val c = Calendar.getInstance()
    c.add(Calendar.DAY_OF_YEAR, idx - todayIndex())
    return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
}

@Composable
fun SportsScreen(viewModel: RiwaqViewModel, modifier: Modifier = Modifier) {
    var tab by remember { mutableIntStateOf(0) }
    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = RiwaqBlue) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("الجدول") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("التمارين") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("التغذية") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("السجل") })
        }
        when (tab) {
            0 -> SchedulePane(viewModel, Modifier.weight(1f))
            1 -> ExercisesPane(viewModel, Modifier.weight(1f))
            2 -> NutritionPane(viewModel, Modifier.weight(1f))
            else -> SportLogPane(viewModel, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ExerciseIcon(icon: String, size: Int = 40) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color(0xFFE8F0FE)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = icon, fontSize = (size * 0.5f).sp)
    }
}

@Composable
private fun SchedulePane(viewModel: RiwaqViewModel, modifier: Modifier = Modifier) {
    val plan by viewModel.sportPlan.collectAsStateWithLifecycle()
    val logs by viewModel.sportPlanLogs.collectAsStateWithLifecycle()
    var selectedDay by remember { mutableIntStateOf(todayIndex()) }
    var showPicker by remember { mutableStateOf(false) }
    var pendingExercise by remember { mutableStateOf<Exercise?>(null) }

    val dayItems = remember(plan, selectedDay) { plan.filter { it.dayIndex == selectedDay } }
    val isRest = dayItems.any { it.exerciseKey == "REST" }
    val dateStr = remember(selectedDay) { dateForDayIndex(selectedDay) }
    val todayStr = remember { dateForDayIndex(todayIndex()) }
    val doneSet = remember(logs) { logs.map { "${it.itemId}|${it.dateString}" }.toSet() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(7) { i ->
                    val sel = i == selectedDay
                    val items = plan.filter { it.dayIndex == i }
                    val label = when {
                        items.any { it.exerciseKey == "REST" } -> "راحة"
                        items.isNotEmpty() -> "${items.size} تمارين"
                        else -> "—"
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (sel) RiwaqBlue else Color.White)
                            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(14.dp))
                            .clickable { selectedDay = i }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(DayNamesAr[i], fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else RiwaqTextPrimary)
                        Text(DayNamesEn[i], fontSize = 10.sp, color = if (sel) Color.White else RiwaqTextMuted)
                        Text(label, fontSize = 10.sp, color = if (sel) Color.White else RiwaqTextSecondary)
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showPicker = true }) { Text("+ إضافة تمرين", color = RiwaqBlue, fontWeight = FontWeight.Bold) }
                TextButton(onClick = { viewModel.setSportDayRest(selectedDay, !isRest) }) {
                    Text(if (isRest) "إلغاء يوم الراحة" else "تعيين يوم راحة", color = RiwaqTextSecondary)
                }
            }
        }

        if (isRest) {
            item {
                EmptyStateView(title = "يوم راحة 😴", subtitle = "الراحة جزء أساسي من التدريب")
            }
        } else if (dayItems.isEmpty()) {
            item {
                EmptyStateView(
                    title = "لا توجد تمارين لهذا اليوم",
                    subtitle = "أضف تمارين من المكتبة لبناء جدولك الأسبوعي"
                )
            }
        } else {
            items(dayItems, key = { "plan_${it.id}" }) { item ->
                val ex = findExercise(item.exerciseKey)
                val done = doneSet.contains("${item.id}|$dateStr")
                val canToggle = dateStr <= todayStr
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ExerciseIcon(ex?.icon ?: "🏋️")
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ex?.ar ?: item.exerciseKey, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = RiwaqTextPrimary)
                        Text(
                            text = listOfNotNull(ex?.en, item.detail.ifBlank { null }).joinToString(" · "),
                            fontSize = 12.sp,
                            color = RiwaqTextMuted
                        )
                    }
                    IconButton(
                        onClick = { if (canToggle) viewModel.toggleSportPlanLog(item.id, dateStr) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "إنجاز",
                            tint = if (done) RiwaqPriorityGreen else Color.LightGray
                        )
                    }
                    IconButton(onClick = { viewModel.deleteSportPlanItem(item.id) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RiwaqPriorityRed)
                    }
                }
            }
        }
    }

    if (showPicker) {
        ExercisePickerDialog(
            onDismiss = { showPicker = false },
            onPick = { showPicker = false; pendingExercise = it }
        )
    }
    pendingExercise?.let { ex ->
        PlanDetailDialog(
            exercise = ex,
            defaultDay = selectedDay,
            onDismiss = { pendingExercise = null },
            onSave = { day, detail ->
                viewModel.addSportPlanItem(day, ex.key, detail)
                selectedDay = day
                pendingExercise = null
            }
        )
    }
}

@Composable
private fun ExercisePickerDialog(onDismiss: () -> Unit, onPick: (Exercise) -> Unit) {
    var query by remember { mutableStateOf("") }
    val list = remember(query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) ExerciseLibrary
        else ExerciseLibrary.filter { it.ar.contains(q) || it.en.lowercase().contains(q) || it.group.contains(q) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اختر تمريناً") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("ابحث بالعربية أو الإنجليزية") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(list, key = { it.key }) { ex ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(ex) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ExerciseIcon(ex.icon, 36)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ex.ar, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = RiwaqTextPrimary)
                                Text("${ex.en} · ${ex.group}", fontSize = 11.sp, color = RiwaqTextMuted)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } }
    )
}

@Composable
private fun PlanDetailDialog(
    exercise: Exercise,
    defaultDay: Int,
    onDismiss: () -> Unit,
    onSave: (Int, String) -> Unit
) {
    var day by remember { mutableIntStateOf(defaultDay) }
    var detail by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${exercise.ar} · ${exercise.en}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(7) { i ->
                        val sel = i == day
                        Text(
                            text = DayNamesAr[i],
                            fontSize = 12.sp,
                            color = if (sel) Color.White else RiwaqBlue,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (sel) RiwaqBlue else Color(0xFFE8F0FE))
                                .clickable { day = i }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
                OutlinedTextField(
                    value = detail,
                    onValueChange = { detail = it },
                    placeholder = { Text("مثال: 3×12 أو 30 دقيقة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(day, detail) }) { Text("إضافة", color = RiwaqBlue) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ExercisesPane(viewModel: RiwaqViewModel, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Exercise?>(null) }
    val list = remember(query, group) {
        val q = query.trim().lowercase()
        ExerciseLibrary.filter {
            (group == null || it.group == group) &&
                (q.isEmpty() || it.ar.contains(q) || it.en.lowercase().contains(q))
        }
    }
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("ابحث عن تمرين...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ExerciseGroups) { g ->
                    val sel = group == g
                    Text(
                        text = g,
                        fontSize = 12.sp,
                        color = if (sel) Color.White else RiwaqBlue,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (sel) RiwaqBlue else Color(0xFFE8F0FE))
                            .clickable { group = if (sel) null else g }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }
        items(list, key = { it.key }) { ex ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White)
                    .border(1.dp, RiwaqCardBorder, RoundedCornerShape(14.dp))
                    .clickable { pending = ex }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ExerciseIcon(ex.icon)
                Column(modifier = Modifier.weight(1f)) {
                    Text(ex.ar, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = RiwaqTextPrimary)
                    Text(ex.en, fontSize = 12.sp, color = RiwaqTextMuted)
                }
                Text(ex.group, fontSize = 11.sp, color = RiwaqTextSecondary)
            }
        }
    }
    pending?.let { ex ->
        PlanDetailDialog(
            exercise = ex,
            defaultDay = todayIndex(),
            onDismiss = { pending = null },
            onSave = { day, detail ->
                viewModel.addSportPlanItem(day, ex.key, detail)
                pending = null
            }
        )
    }
}

@Composable
private fun NutritionPane(viewModel: RiwaqViewModel, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("riwaq_sports", Context.MODE_PRIVATE) }
    var goal by remember { mutableIntStateOf(prefs.getInt("kcal_goal", 2000)) }
    val meals by viewModel.meals.collectAsStateWithLifecycle()
    val todayStr = remember { dateForDayIndex(todayIndex()) }
    val todayMeals = remember(meals) { meals.filter { it.dateString == todayStr } }
    val total = todayMeals.sumOf { it.calories }

    var mealType by remember { mutableStateOf(MealTypes[0]) }
    var name by remember { mutableStateOf("") }
    var kcalText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("سعرات اليوم", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
                    Text("$total / $goal", fontSize = 14.sp, color = if (total > goal) RiwaqPriorityRed else RiwaqBlue)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFFE2E8F0))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth((if (goal > 0) total.toFloat() / goal else 0f).coerceIn(0f, 1f))
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (total > goal) RiwaqPriorityRed else RiwaqBlue)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الهدف اليومي:", fontSize = 12.sp, color = RiwaqTextSecondary)
                    IconButton(onClick = { goal = (goal - 100).coerceAtLeast(800); prefs.edit().putInt("kcal_goal", goal).apply() }) {
                        Icon(Icons.Default.Remove, contentDescription = "إنقاص", tint = RiwaqBlue)
                    }
                    Text("$goal", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
                    IconButton(onClick = { goal = (goal + 100).coerceAtMost(6000); prefs.edit().putInt("kcal_goal", goal).apply() }) {
                        Icon(Icons.Default.Add, contentDescription = "زيادة", tint = RiwaqBlue)
                    }
                }
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("إضافة وجبة", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(MealTypes) { t ->
                        val sel = mealType == t
                        Text(
                            text = t,
                            fontSize = 12.sp,
                            color = if (sel) Color.White else RiwaqBlue,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (sel) RiwaqBlue else Color(0xFFE8F0FE))
                                .clickable { mealType = t }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
                Text("اختيار سريع (قيم تقريبية):", fontSize = 11.sp, color = RiwaqTextMuted)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(FoodLibrary, key = { it.ar }) { f ->
                        Text(
                            text = "${f.ar} · ${f.kcal}",
                            fontSize = 11.sp,
                            color = RiwaqTextPrimary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFF1F5F9))
                                .clickable { name = f.ar; kcalText = f.kcal.toString() }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("الوجبة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = kcalText,
                        onValueChange = { kcalText = it.filter { c -> c.isDigit() }.take(4) },
                        label = { Text("السعرات") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        val k = kcalText.toIntOrNull() ?: 0
                        if (name.isNotBlank() && k > 0) {
                            viewModel.addMeal(name, k, mealType)
                            name = ""
                            kcalText = ""
                        }
                    }) { Text("إضافة", color = RiwaqBlue, fontWeight = FontWeight.Bold) }
                }
            }
        }

        if (todayMeals.isEmpty()) {
            item { EmptyStateView(title = "لا توجد وجبات اليوم", subtitle = "سجّل وجباتك لمتابعة السعرات") }
        } else {
            items(todayMeals, key = { "meal_${it.id}" }) { m ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(1.dp, RiwaqCardBorder, RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(m.name, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = RiwaqTextPrimary)
                        Text("${m.mealType} · ${m.calories} سعرة", fontSize = 12.sp, color = RiwaqTextMuted)
                    }
                    IconButton(onClick = { viewModel.deleteMeal(m.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RiwaqPriorityRed)
                    }
                }
            }
        }
    }
}
