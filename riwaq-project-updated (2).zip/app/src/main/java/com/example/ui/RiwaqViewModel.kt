package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DocxBackupManager
import com.example.data.RiwaqRepository
import com.example.data.SettingsManager
import com.example.data.model.AppSettings
import com.example.data.model.BookEntity
import com.example.data.model.CalendarEventEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatThreadEntity
import com.example.data.model.WorkoutEntity
import com.example.data.model.SportPlanItemEntity
import com.example.data.model.SportPlanLogEntity
import com.example.data.model.MealEntity
import com.example.data.chat.ChatLink
import com.example.data.chat.LinkUi
import com.example.data.model.DailyEnthusiasmRecord
import com.example.data.model.HabitEntity
import com.example.data.model.HabitLogEntity
import com.example.data.model.ImportSummary
import com.example.data.model.NoteEntity
import com.example.data.model.NoteFolderEntity
import com.example.data.model.RiwaqBackupData
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.ui.navigation.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class SeasonData(
    val seasonNumber: Int,
    val title: String,
    val completedTasksCount: Int = 0,
    val completedHabitsCount: Int = 0,
    val completedBooksCount: Int = 0,
    val enthusiasmDaysCount: Int = 0,
    val hasData: Boolean = false
)

data class RiwaqStatistics(
    val enthusiasmStreakDays: Int = 0,
    val yesterdayStreakDays: Int = 0,
    val bestStreakDays: Int = 0,
    val taskCompletionRatePercent: Int = 0,
    val habitAdherenceRatePercent: Int = 0,
    val completedBooksCount: Int = 0,
    val totalTasksCount: Int = 0,
    val completedTasksCount: Int = 0,
    val totalHabitsCount: Int = 0,
    val totalNotesCount: Int = 0,
    val hasEnoughData: Boolean = false,
    val seasons: List<SeasonData> = emptyList()
)

class RiwaqViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RiwaqRepository
    private val docxBackupManager: DocxBackupManager
    private val settingsManager: SettingsManager = SettingsManager(application)

    val appSettings: StateFlow<AppSettings> = settingsManager.settings

    fun updateSettings(newSettings: AppSettings) {
        settingsManager.updateSettings(newSettings)
    }

    init {
        val db = AppDatabase.getInstance(application)
        repository = RiwaqRepository(db.riwaqDao(), application)
        docxBackupManager = DocxBackupManager(application)
    }

    // --- Navigation State ---
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val screenHistory = mutableListOf<Screen>()

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenHistory.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (screenHistory.isNotEmpty()) {
            val prev = screenHistory.removeAt(screenHistory.size - 1)
            _currentScreen.value = prev
            true
        } else if (_currentScreen.value !is Screen.Home) {
            _currentScreen.value = Screen.Home
            true
        } else {
            false
        }
    }

    // --- Feedback messages ---
    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    // --- Tasks ---
    val allTasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTask(title: String, dueDateMillis: Long, priority: TaskPriority, durationMinutes: Int) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val task = TaskEntity(
                title = title.trim(),
                dueDateMillis = dueDateMillis,
                priority = priority,
                durationMinutes = durationMinutes
            )
            repository.insertTask(task)
            repository.recordEnthusiasmForDate(dueDateMillis)
        }
    }

    fun toggleTaskComplete(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleTaskComplete(task)
        }
    }

    fun updateTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    // --- Habits ---
    val allHabits: StateFlow<List<HabitEntity>> = repository.allHabits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allHabitLogs: StateFlow<List<HabitLogEntity>> = repository.allHabitLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addHabit(title: String, isEveryDay: Boolean, targetDays: String, habitTime: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val nextSort = (allHabits.value.maxOfOrNull { it.sortOrder } ?: 0) + 1
            repository.insertHabit(
                HabitEntity(
                    title = title.trim(),
                    isEveryDay = isEveryDay,
                    targetDays = targetDays,
                    habitTime = habitTime.trim(),
                    sortOrder = nextSort
                )
            )
        }
    }

    fun updateHabit(habit: HabitEntity) {
        viewModelScope.launch {
            repository.updateHabit(habit)
        }
    }

    fun moveHabit(habitId: Long, up: Boolean) {
        viewModelScope.launch {
            val list = allHabits.value
            val i = list.indexOfFirst { it.id == habitId }
            val j = if (up) i - 1 else i + 1
            if (i < 0 || j < 0 || j >= list.size) return@launch
            // إعادة ترقيم كاملة لتفادي تساوي sortOrder
            val reordered = list.toMutableList()
            val tmp = reordered[i]; reordered[i] = reordered[j]; reordered[j] = tmp
            reordered.forEachIndexed { idx, h ->
                if (h.sortOrder != idx) repository.updateHabit(h.copy(sortOrder = idx))
            }
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch {
            repository.deleteHabit(habit)
        }
    }

    fun toggleHabitToday(habitId: Long, completed: Boolean) {
        viewModelScope.launch {
            val todayStr = getTodayDateString()
            repository.toggleHabitLog(habitId, todayStr, completed)
        }
    }

    fun toggleHabitDate(habitId: Long, dateString: String, completed: Boolean) {
        viewModelScope.launch {
            repository.toggleHabitLog(habitId, dateString, completed)
        }
    }

    // --- Notes & Folders ---
    val allNotes: StateFlow<List<NoteEntity>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFolders: StateFlow<List<NoteFolderEntity>> = repository.allFolders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedFolderId = MutableStateFlow<Long?>(null)
    val selectedFolderId: StateFlow<Long?> = _selectedFolderId.asStateFlow()

    fun selectFolder(folderId: Long?) {
        _selectedFolderId.value = folderId
    }

    fun createFolder(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.insertFolder(name.trim())
        }
    }

    fun deleteFolder(folder: NoteFolderEntity) {
        viewModelScope.launch {
            repository.deleteFolder(folder)
            if (_selectedFolderId.value == folder.id) {
                _selectedFolderId.value = null
            }
        }
    }

    fun saveNote(noteId: Long, title: String, content: String, folderId: Long?) {
        if (title.isBlank() && content.isBlank()) return
        viewModelScope.launch {
            repository.saveNote(
                id = noteId,
                title = title.ifBlank { "ملاحظة بدون عنوان" }.trim(),
                content = content,
                folderId = folderId
            )
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    // --- Workouts ---
    val workouts: StateFlow<List<WorkoutEntity>> = repository.workouts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addWorkout(name: String, minutes: Int, note: String = "") {
        if (name.isBlank() || minutes <= 0) return
        viewModelScope.launch { repository.addWorkout(name.trim(), minutes, note.trim(), getTodayDateString()) }
    }

    fun deleteWorkout(id: Long) {
        viewModelScope.launch { repository.deleteWorkout(id) }
    }

    // --- Stopwatch (ساعة الإيقاف) ---
    data class StopwatchUi(val isRunning: Boolean = false, val elapsedSec: Int = 0)

    private val _stopwatch = MutableStateFlow(StopwatchUi())
    val stopwatch: StateFlow<StopwatchUi> = _stopwatch
    private var stopwatchJob: kotlinx.coroutines.Job? = null

    fun stopwatchToggle() {
        if (_stopwatch.value.isRunning) {
            stopwatchJob?.cancel()
            _stopwatch.value = _stopwatch.value.copy(isRunning = false)
        } else {
            _stopwatch.value = _stopwatch.value.copy(isRunning = true)
            stopwatchJob?.cancel()
            stopwatchJob = viewModelScope.launch {
                while (_stopwatch.value.isRunning) {
                    kotlinx.coroutines.delay(1000)
                    _stopwatch.value = _stopwatch.value.copy(elapsedSec = _stopwatch.value.elapsedSec + 1)
                }
            }
        }
    }

    fun stopwatchReset() {
        stopwatchJob?.cancel()
        _stopwatch.value = StopwatchUi()
    }

    /** تعديل الوقت يدوياً (بالثواني، موجب أو سالب) */
    fun stopwatchAdjust(deltaSec: Int) {
        _stopwatch.value = _stopwatch.value.copy(elapsedSec = (_stopwatch.value.elapsedSec + deltaSec).coerceAtLeast(0))
    }

    // --- Pomodoro ---
    data class PomodoroUi(
        val isRunning: Boolean = false,
        val isBreak: Boolean = false,
        val remainingSec: Int = 25 * 60,
        val workMin: Int = 25,
        val breakMin: Int = 5,
        val sessionsDone: Int = 0
    )

    private fun initialPomodoro(): PomodoroUi {
        val prefs = getApplication<Application>().getSharedPreferences("riwaq_pomo", android.content.Context.MODE_PRIVATE)
        val w = prefs.getInt("work", 25).coerceIn(5, 90)
        val b = prefs.getInt("break", 5).coerceIn(1, 30)
        return PomodoroUi(remainingSec = w * 60, workMin = w, breakMin = b)
    }

    private val _pomodoro = MutableStateFlow(initialPomodoro())
    val pomodoro: StateFlow<PomodoroUi> = _pomodoro
    private var pomodoroJob: kotlinx.coroutines.Job? = null

    fun pomodoroToggle() {
        if (_pomodoro.value.isRunning) {
            pomodoroJob?.cancel()
            _pomodoro.value = _pomodoro.value.copy(isRunning = false)
        } else {
            _pomodoro.value = _pomodoro.value.copy(isRunning = true)
            pomodoroJob?.cancel()
            pomodoroJob = viewModelScope.launch {
                while (_pomodoro.value.isRunning) {
                    kotlinx.coroutines.delay(1000)
                    val cur = _pomodoro.value
                    if (cur.remainingSec > 1) {
                        _pomodoro.value = cur.copy(remainingSec = cur.remainingSec - 1)
                    } else if (cur.isBreak) {
                        _pomodoro.value = cur.copy(isBreak = false, remainingSec = cur.workMin * 60)
                    } else {
                        _pomodoro.value = cur.copy(
                            isBreak = true,
                            remainingSec = cur.breakMin * 60,
                            sessionsDone = cur.sessionsDone + 1
                        )
                    }
                }
            }
        }
    }

    fun pomodoroReset() {
        pomodoroJob?.cancel()
        val cur = _pomodoro.value
        _pomodoro.value = cur.copy(isRunning = false, isBreak = false, remainingSec = cur.workMin * 60)
    }

    fun pomodoroSetDurations(workMin: Int, breakMin: Int) {
        val cur = _pomodoro.value
        if (cur.isRunning) return
        val w = workMin.coerceIn(5, 90)
        val b = breakMin.coerceIn(1, 30)
        _pomodoro.value = cur.copy(workMin = w, breakMin = b, isBreak = false, remainingSec = w * 60)
        getApplication<Application>().getSharedPreferences("riwaq_pomo", android.content.Context.MODE_PRIVATE)
            .edit().putInt("work", w).putInt("break", b).apply()
    }

    // --- Chats ---
    val chatThreads: StateFlow<List<ChatThreadEntity>> = repository.chatThreads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun chatMessages(threadId: Long): kotlinx.coroutines.flow.Flow<List<ChatMessageEntity>> =
        repository.chatMessages(threadId)

    fun createChatThread(title: String, type: String) {
        viewModelScope.launch {
            repository.createChatThread(title.ifBlank { "محادثة جديدة" }.trim(), type)
        }
    }

    // --- Chat link (LAN / Bluetooth) ---
    private val chatLink = ChatLink(viewModelScope)
    val linkUi: StateFlow<LinkUi> = chatLink.ui
    private val _linkThreadId = MutableStateFlow<Long?>(null)
    val linkThreadId: StateFlow<Long?> = _linkThreadId

    private fun bindLink(threadId: Long) {
        _linkThreadId.value = threadId
        chatLink.onReceive = { color, text ->
            viewModelScope.launch { repository.sendChatMessage(threadId, text, color, false) }
        }
    }

    private fun btAdapter(): android.bluetooth.BluetoothAdapter? =
        getApplication<Application>().getSystemService(android.bluetooth.BluetoothManager::class.java)?.adapter

    fun linkHostLan(threadId: Long) { bindLink(threadId); chatLink.hostLan() }
    fun linkConnectLan(threadId: Long, ip: String) { bindLink(threadId); chatLink.connectLan(ip) }

    @android.annotation.SuppressLint("MissingPermission")
    fun linkHostBluetooth(threadId: Long) {
        val a = btAdapter()
        if (a == null || !a.isEnabled) return
        bindLink(threadId); chatLink.hostBluetooth(a)
    }

    @android.annotation.SuppressLint("MissingPermission")
    fun linkConnectBluetooth(threadId: Long, address: String) {
        val a = btAdapter() ?: return
        val dev = try { a.getRemoteDevice(address) } catch (_: Exception) { return }
        bindLink(threadId); chatLink.connectBluetooth(a, dev)
    }

    fun isBluetoothAvailable(): Boolean = btAdapter()?.isEnabled == true

    /** الأجهزة المقترنة (اسم، عنوان). يتطلب صلاحية BLUETOOTH_CONNECT على أندرويد 12+ */
    @android.annotation.SuppressLint("MissingPermission")
    fun bondedBluetoothDevices(): List<Pair<String, String>> = try {
        btAdapter()?.bondedDevices?.map { (it.name ?: it.address) to it.address } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    fun linkClose() { chatLink.close(); _linkThreadId.value = null }
    fun linkIsConnected(): Boolean = chatLink.isConnected()
    fun linkSend(colorHex: String, text: String) = chatLink.send(colorHex, text)

    override fun onCleared() {
        chatLink.close()
        super.onCleared()
    }

    // --- Sport plan & nutrition ---
    val sportPlan: StateFlow<List<SportPlanItemEntity>> = repository.sportPlan
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sportPlanLogs: StateFlow<List<SportPlanLogEntity>> = repository.sportPlanLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val meals: StateFlow<List<MealEntity>> = repository.meals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addSportPlanItem(dayIndex: Int, exerciseKey: String, detail: String) {
        viewModelScope.launch {
            // إضافة تمرين تُلغي يوم الراحة
            val rest = sportPlan.value.filter { it.dayIndex == dayIndex && it.exerciseKey == "REST" }
            rest.forEach { repository.deleteSportPlanItem(it.id) }
            repository.addSportPlanItem(dayIndex, exerciseKey, detail.trim())
        }
    }

    fun deleteSportPlanItem(id: Long) { viewModelScope.launch { repository.deleteSportPlanItem(id) } }

    fun setSportDayRest(dayIndex: Int, rest: Boolean) {
        viewModelScope.launch {
            repository.setDayRest(dayIndex, rest, sportPlan.value.filter { it.dayIndex == dayIndex })
        }
    }

    fun toggleSportPlanLog(itemId: Long, dateString: String) {
        viewModelScope.launch { repository.toggleSportPlanLog(itemId, dateString) }
    }

    fun addMeal(name: String, calories: Int, mealType: String) {
        if (name.isBlank() || calories <= 0) return
        viewModelScope.launch { repository.addMeal(name.trim(), calories, mealType, getTodayDateString()) }
    }

    fun deleteMeal(id: Long) { viewModelScope.launch { repository.deleteMeal(id) } }

    fun deleteChatThread(threadId: Long) {
        viewModelScope.launch { repository.deleteChatThread(threadId) }
    }

    fun sendChatMessage(threadId: Long, text: String, colorHex: String, isMine: Boolean) {
        if (text.isBlank()) return
        viewModelScope.launch { repository.sendChatMessage(threadId, text.trim(), colorHex, isMine) }
    }

    fun deleteChatMessage(messageId: Long) {
        viewModelScope.launch { repository.deleteChatMessage(messageId) }
    }

    // --- Books & PDF ---
    val allBooks: StateFlow<List<BookEntity>> = repository.allBooks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun importPdf(uri: Uri, fileName: String) {
        viewModelScope.launch {
            val result = repository.importPdfBook(uri, fileName)
            result.onSuccess {
                _userMessage.emit("تمت إضافة الكتاب إلى المكتبة بنجاح")
            }.onFailure {
                _userMessage.emit("فشل استيراد ملف PDF: ${it.message}")
            }
        }
    }

    fun updateBookProgress(bookId: Long, page: Int) {
        viewModelScope.launch {
            repository.updateBookProgress(bookId, page)
        }
    }

    fun updateBookCover(bookId: Long, imageUri: Uri) {
        viewModelScope.launch {
            val res = repository.updateBookCover(bookId, imageUri)
            res.onSuccess {
                _userMessage.emit("تم تحديث غلاف الكتاب بنجاح")
            }.onFailure {
                _userMessage.emit("فشل تحديث الغلاف: ${it.message}")
            }
        }
    }

    fun renameBook(bookId: Long, newTitle: String) {
        if (newTitle.isBlank()) return
        viewModelScope.launch {
            repository.renameBook(bookId, newTitle.trim())
        }
    }

    fun deleteBook(book: BookEntity) {
        viewModelScope.launch {
            repository.deleteBook(book)
            _userMessage.emit("تم حذف الكتاب من المكتبة")
        }
    }

    // --- Calendar Events ---
    val allCalendarEvents: StateFlow<List<CalendarEventEntity>> = repository.allCalendarEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedCalendarDate = MutableStateFlow(getTodayDateString())
    val selectedCalendarDate: StateFlow<String> = _selectedCalendarDate.asStateFlow()

    val calendarSelectedYear = MutableStateFlow(Calendar.getInstance().get(Calendar.YEAR))
    val calendarSelectedMonth = MutableStateFlow(Calendar.getInstance().get(Calendar.MONTH))

    fun setCalendarMonthYear(year: Int, month: Int) {
        calendarSelectedYear.value = year
        calendarSelectedMonth.value = month
    }

    fun selectCalendarDate(dateString: String) {
        _selectedCalendarDate.value = dateString
    }

    fun markEnthusiasmBurnViewedForToday() {
        val today = getTodayDateString()
        updateSettings(appSettings.value.copy(lastEnthusiasmBurnViewedDate = today))
    }

    fun addCalendarEvent(title: String, dateString: String, time: String, colorHex: String, note: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.insertCalendarEvent(
                CalendarEventEntity(
                    title = title.trim(),
                    dateString = dateString,
                    time = time.trim(),
                    colorHex = colorHex,
                    note = note.trim()
                )
            )
        }
    }

    fun deleteCalendarEvent(event: CalendarEventEntity) {
        viewModelScope.launch {
            repository.deleteCalendarEvent(event)
        }
    }

    // --- Statistics & Enthusiasm System ---
    val statistics: StateFlow<RiwaqStatistics> = combine(
        allTasks,
        allHabits,
        allHabitLogs,
        allBooks,
        repository.allEnthusiasmRecords
    ) { tasks, habits, logs, books, enthusiasmRecords ->
        computeStatistics(tasks, habits, logs, books, allNotes.value, enthusiasmRecords)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), RiwaqStatistics())

    private fun computeStatistics(
        tasks: List<TaskEntity>,
        habits: List<HabitEntity>,
        logs: List<HabitLogEntity>,
        books: List<BookEntity>,
        notes: List<NoteEntity>,
        enthusiasmRecords: List<DailyEnthusiasmRecord>
    ): RiwaqStatistics {
        val totalTasks = tasks.size
        val completedTasks = tasks.count { it.isCompleted }
        val taskRate = if (totalTasks > 0) (completedTasks * 100) / totalTasks else 0

        val completedBooks = books.count { it.isCompleted || (it.totalPages > 0 && it.currentPage >= it.totalPages - 1) }

        // Habit adherence rate over the past 30 days
        val habitRate = if (habits.isNotEmpty()) {
            val totalPossible = habits.size * 30
            val recentLogs = logs.size.coerceAtMost(totalPossible)
            ((recentLogs.toFloat() / totalPossible.toFloat()) * 100f).toInt().coerceIn(0, 100)
        } else {
            0
        }

        // Enthusiasm streak calculation:
        // Rule: A day is completed if >= 85% of tasks for that day are completed.
        val recordsMap = enthusiasmRecords.associateBy { it.dateString }

        // Check streak backwards from today
        var streak = 0
        val cal = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        // First check today
        val todayStr = sdf.format(cal.time)
        val todayTasks = tasks.filter {
            val taskCal = Calendar.getInstance().apply { timeInMillis = it.dueDateMillis }
            sdf.format(taskCal.time) == todayStr
        }

        var todayCounted = false
        if (todayTasks.isNotEmpty()) {
            val todayCompleted = todayTasks.count { it.isCompleted }
            val todayPercent = (todayCompleted.toFloat() / todayTasks.size.toFloat()) * 100f
            if (todayPercent >= 85f) {
                streak++
                todayCounted = true
            }
        }

        // Now step backwards day by day
        for (i in 1..365) {
            val checkCal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -i)
            }
            val checkDateStr = sdf.format(checkCal.time)
            val record = recordsMap[checkDateStr]
            if (record != null && record.isAchieved) {
                streak++
            } else {
                // If today wasn't completed yet, but yesterday and before were, continue streak from yesterday
                if (i == 1 && !todayCounted) {
                    val yesterdayRecord = recordsMap[checkDateStr]
                    if (yesterdayRecord != null && yesterdayRecord.isAchieved) {
                        streak++
                        continue
                    }
                }
                break
            }
        }

        // Calculate yesterday streak (for yesterday's paper burn ceremony)
        var yesterdayStreak = 0
        for (i in 1..365) {
            val checkCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val checkDateStr = sdf.format(checkCal.time)
            val record = recordsMap[checkDateStr]
            if (record != null && record.isAchieved) {
                yesterdayStreak++
            } else {
                break
            }
        }

        // Calculate best streak historically
        val sortedDates = recordsMap.keys.sorted()
        var currentRun = 0
        var bestStreak = streak
        for (d in sortedDates) {
            val rec = recordsMap[d]
            if (rec != null && rec.isAchieved) {
                currentRun++
                if (currentRun > bestStreak) bestStreak = currentRun
            } else {
                currentRun = 0
            }
        }

        // Calculate 6 Seasons of the Year (Jan+Feb, Mar+Apr, May+Jun, Jul+Aug, Sep+Oct, Nov+Dec)
        val currentYear = cal.get(Calendar.YEAR)
        val seasonTitles = listOf(
            "يناير وفبراير",
            "مارس وأبريل",
            "مايو ويونيو",
            "يوليو وأغسطس",
            "سبتمبر وأكتوبر",
            "نوفمبر وديسمبر"
        )

        val seasonsList = (1..6).map { sNum ->
            val m1 = (sNum - 1) * 2 // 0, 2, 4, 6, 8, 10
            val m2 = m1 + 1         // 1, 3, 5, 7, 9, 11

            val sTasks = tasks.count {
                val tCal = Calendar.getInstance().apply { timeInMillis = it.dueDateMillis }
                it.isCompleted && tCal.get(Calendar.YEAR) == currentYear && (tCal.get(Calendar.MONTH) == m1 || tCal.get(Calendar.MONTH) == m2)
            }

            val sHabits = logs.count {
                val parts = it.dateString.split("-")
                if (parts.size >= 2) {
                    val y = parts[0].toIntOrNull() ?: 0
                    val m = (parts[1].toIntOrNull() ?: 1) - 1
                    it.isCompleted && y == currentYear && (m == m1 || m == m2)
                } else false
            }

            val sBooks = books.count {
                val bCal = Calendar.getInstance().apply { timeInMillis = it.lastReadMillis }
                (it.isCompleted || (it.totalPages > 0 && it.currentPage >= it.totalPages - 1)) &&
                        bCal.get(Calendar.YEAR) == currentYear && (bCal.get(Calendar.MONTH) == m1 || bCal.get(Calendar.MONTH) == m2)
            }

            val sEnthusiasm = enthusiasmRecords.count {
                val parts = it.dateString.split("-")
                if (parts.size >= 2) {
                    val y = parts[0].toIntOrNull() ?: 0
                    val m = (parts[1].toIntOrNull() ?: 1) - 1
                    it.isAchieved && y == currentYear && (m == m1 || m == m2)
                } else false
            }

            val hasData = sTasks > 0 || sHabits > 0 || sBooks > 0 || sEnthusiasm > 0
            SeasonData(
                seasonNumber = sNum,
                title = seasonTitles[sNum - 1],
                completedTasksCount = sTasks,
                completedHabitsCount = sHabits,
                completedBooksCount = sBooks,
                enthusiasmDaysCount = sEnthusiasm,
                hasData = hasData
            )
        }

        val hasEnoughData = totalTasks > 0 || habits.isNotEmpty() || books.isNotEmpty() || notes.isNotEmpty()

        return RiwaqStatistics(
            enthusiasmStreakDays = streak,
            yesterdayStreakDays = yesterdayStreak,
            bestStreakDays = bestStreak,
            taskCompletionRatePercent = taskRate,
            habitAdherenceRatePercent = habitRate,
            completedBooksCount = completedBooks,
            totalTasksCount = totalTasks,
            completedTasksCount = completedTasks,
            totalHabitsCount = habits.size,
            totalNotesCount = notes.size,
            hasEnoughData = hasEnoughData,
            seasons = seasonsList
        )
    }

    // --- DOCX Backup & Restore ---
    suspend fun exportBackup(outputStream: OutputStream, password: String): Result<Unit> {
        val payload = repository.createBackupPayload().copy(settings = appSettings.value)
        return docxBackupManager.exportEncrypted(payload, outputStream, password)
    }

    suspend fun inspectBackupBytes(bytes: ByteArray, password: String?): Result<RiwaqBackupData> {
        return docxBackupManager.inspectBackup(bytes, password)
    }

    fun restoreBackupData(backupData: RiwaqBackupData, replaceExisting: Boolean, onDone: (ImportSummary) -> Unit) {
        viewModelScope.launch {
            repository.restoreBackup(backupData, replaceExisting)
            updateSettings(backupData.settings)
            val summary = ImportSummary(
                tasksCount = backupData.tasks.size,
                habitsCount = backupData.habits.size,
                notesCount = backupData.notes.size,
                booksCount = backupData.books.size,
                eventsCount = backupData.calendarEvents.size
            )
            onDone(summary)
            _userMessage.emit("تم استيراد البيانات بنجاح!")
        }
    }

    fun setCalendarCustomImage(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val file = java.io.File(app.filesDir, "calendar_avatar.png")
                app.contentResolver.openInputStream(uri)?.use { input ->
                    java.io.FileOutputStream(file).use { output ->
                        input.copyTo(output)
                    }
                }
                updateSettings(appSettings.value.copy(calendarCustomImagePath = file.absolutePath))
                _userMessage.emit("تم تحديث صورة التقويم بنجاح")
            } catch (e: Exception) {
                _userMessage.emit("فشل تحديث الصورة: ${e.message}")
            }
        }
    }

    fun resetCalendarCustomImage() {
        updateSettings(appSettings.value.copy(calendarCustomImagePath = null))
    }

    fun clearAllUserData(onDone: () -> Unit) {
        viewModelScope.launch {
            repository.clearAllUserData()
            settingsManager.resetSettings()
            onDone()
            _userMessage.emit("تم مسح كافة البيانات بنجاح")
        }
    }

    fun getRiwaqItemsMatching(query: String): List<RiwaqLinkItem> {
        val q = query.trim().lowercase()
        val list = mutableListOf<RiwaqLinkItem>()
        allHabits.value.filter { q.isEmpty() || it.title.lowercase().contains(q) }.forEach {
            list.add(RiwaqLinkItem(it.id, "habit", it.title, "★"))
        }
        allTasks.value.filter { q.isEmpty() || it.title.lowercase().contains(q) }.forEach {
            list.add(RiwaqLinkItem(it.id, "task", it.title, "✓"))
        }
        allBooks.value.filter { q.isEmpty() || it.title.lowercase().contains(q) }.forEach {
            list.add(RiwaqLinkItem(it.id, "book", it.title, "📚"))
        }
        allNotes.value.filter { q.isEmpty() || it.title.lowercase().contains(q) }.forEach {
            list.add(RiwaqLinkItem(it.id, "note", it.title, "📝"))
        }
        allCalendarEvents.value.filter { q.isEmpty() || it.title.lowercase().contains(q) }.forEach {
            list.add(RiwaqLinkItem(it.id, "event", it.title, "📅"))
        }
        return list
    }

    companion object {
        fun getTodayDateString(): String {
            return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        }
    }
}

data class RiwaqLinkItem(
    val id: Long,
    val type: String, // "habit", "task", "book", "note", "event"
    val title: String,
    val displayIcon: String
)
