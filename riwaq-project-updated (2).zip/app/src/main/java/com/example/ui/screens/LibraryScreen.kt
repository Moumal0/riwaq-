package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.rememberAsyncImagePainter
import com.example.data.model.BookEntity
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.navigation.Screen
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import java.io.File

@Composable
private fun LibraryPane(
    viewModel: RiwaqViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val books by viewModel.allBooks.collectAsStateWithLifecycle()

    var selectedBookForMenu by remember { mutableStateOf<BookEntity?>(null) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var renameInput by remember { mutableStateOf("") }
    var bookToDelete by remember { mutableStateOf<BookEntity?>(null) }

    // PDF File Picker
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            var fileName = "كتاب.pdf"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    fileName = cursor.getString(nameIndex) ?: fileName
                }
            }
            viewModel.importPdf(uri, fileName)
        }
    }

    // Cover Image Picker
    val coverPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { imageUri: Uri? ->
        if (imageUri != null && selectedBookForMenu != null) {
            viewModel.updateBookCover(selectedBookForMenu!!.id, imageUri)
            selectedBookForMenu = null
        }
    }

    val settings by viewModel.appSettings.collectAsStateWithLifecycle()
    val isHorizontalLayout = settings.libraryDisplayDirection == "HORIZONTAL"

    Box(modifier = modifier.fillMaxSize()) {
        if (isHorizontalLayout) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "المكتبة (عرض أفقي)",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = RiwaqTextPrimary
                        )
                    }
                }

                if (books.isEmpty()) {
                    item {
                        EmptyStateView(
                            title = "المكتبة فارغة",
                            subtitle = "اضغط على زر (+) لإضافة ملف PDF من جهازك وقراءته وحفظ تقدمك"
                        )
                    }
                } else {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "أرفف الكتب الأفقية",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = RiwaqTextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(books, key = { "horizontal_shelf_${it.id}" }) { book ->
                                BookCoverCard(
                                    book = book,
                                    cardWidth = 120.dp,
                                    cardHeight = 160.dp,
                                    onClick = { onNavigate(Screen.PdfReader(book.id)) },
                                    onLongClick = { selectedBookForMenu = book }
                                )
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "قائمة الكتب وقراءة التفاصيل",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = RiwaqTextPrimary
                            )
                        }
                    }

                    items(books, key = { "horizontal_item_${it.id}" }) { book ->
                        HorizontalBookCard(
                            book = book,
                            onClick = { onNavigate(Screen.PdfReader(book.id)) },
                            onLongClick = { selectedBookForMenu = book }
                        )
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                item(span = { GridItemSpan(3) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "المكتبة",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = RiwaqTextPrimary
                        )
                    }
                }

                // Recent Books Section
                if (books.isNotEmpty()) {
                    item(span = { GridItemSpan(3) }) {
                        Column {
                            Text(
                                text = "اخر الكتب",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = RiwaqTextPrimary,
                                modifier = Modifier.align(Alignment.End)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(books.take(4), key = { "recent_${it.id}" }) { book ->
                                    BookCoverCard(
                                        book = book,
                                        cardWidth = 100.dp,
                                        cardHeight = 135.dp,
                                        onClick = { onNavigate(Screen.PdfReader(book.id)) },
                                        onLongClick = { selectedBookForMenu = book }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "جميع الكتب",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = RiwaqTextPrimary,
                                modifier = Modifier.align(Alignment.End)
                            )
                        }
                    }
                }

                // Books Grid
                if (books.isEmpty()) {
                    item(span = { GridItemSpan(3) }) {
                        EmptyStateView(
                            title = "المكتبة فارغة",
                            subtitle = "اضغط على زر (+) لإضافة ملف PDF من جهازك وقراءته وحفظ تقدمك"
                        )
                    }
                } else {
                    items(books, key = { "book_grid_${it.id}" }) { book ->
                        BookCoverCard(
                            book = book,
                            cardWidth = 95.dp,
                            cardHeight = 130.dp,
                            onClick = { onNavigate(Screen.PdfReader(book.id)) },
                            onLongClick = { selectedBookForMenu = book }
                        )
                    }
                }
            }
        }

        // Floating Action Button (+)
        FloatingActionButton(
            onClick = {
                pdfPickerLauncher.launch(arrayOf("application/pdf"))
            },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
                .testTag("add_book_fab"),
            containerColor = Color.White,
            contentColor = RiwaqBlue,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة ملف PDF",
                modifier = Modifier.size(28.dp)
            )
        }

        // Context Menu for Selected Book (Change cover, rename, delete)
        if (selectedBookForMenu != null) {
            AlertDialog(
                onDismissRequest = { selectedBookForMenu = null },
                title = { Text(selectedBookForMenu?.title ?: "") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(
                            onClick = {
                                val b = selectedBookForMenu
                                selectedBookForMenu = null
                                b?.let { onNavigate(Screen.PdfReader(it.id)) }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Book, contentDescription = null, tint = RiwaqBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("فتح وقراءة الكتاب", color = RiwaqBlue)
                        }

                        TextButton(
                            onClick = {
                                coverPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, tint = RiwaqBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تغيير الغلاف", color = RiwaqBlue)
                        }

                        TextButton(
                            onClick = {
                                renameInput = selectedBookForMenu?.title ?: ""
                                showRenameDialog = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = RiwaqBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إعادة التسمية", color = RiwaqBlue)
                        }

                        TextButton(
                            onClick = {
                                bookToDelete = selectedBookForMenu
                                selectedBookForMenu = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = RiwaqPriorityRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("حذف الكتاب", color = RiwaqPriorityRed)
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { selectedBookForMenu = null }) {
                        Text("إغلاق")
                    }
                }
            )
        }

        // Rename Dialog
        if (showRenameDialog && selectedBookForMenu != null) {
            AlertDialog(
                onDismissRequest = { showRenameDialog = false },
                title = { Text("إعادة تسمية الكتاب") },
                text = {
                    OutlinedTextField(
                        value = renameInput,
                        onValueChange = { renameInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (renameInput.isNotBlank()) {
                            viewModel.renameBook(selectedBookForMenu!!.id, renameInput)
                            showRenameDialog = false
                            selectedBookForMenu = null
                        }
                    }) {
                        Text("حفظ", color = RiwaqBlue)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRenameDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // Delete Book Confirmation
        if (bookToDelete != null) {
            AlertDialog(
                onDismissRequest = { bookToDelete = null },
                title = { Text("حذف الكتاب") },
                text = { Text("هل أنت متأكد من رغبتك في حذف '${bookToDelete?.title}' من مكتبتك؟") },
                confirmButton = {
                    TextButton(onClick = {
                        bookToDelete?.let { viewModel.deleteBook(it) }
                        bookToDelete = null
                    }) {
                        Text("حذف", color = RiwaqPriorityRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { bookToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun BookCoverCard(
    book: BookEntity,
    cardWidth: androidx.compose.ui.unit.Dp,
    cardHeight: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val progress = if (book.totalPages > 0) book.currentPage.toFloat() / book.totalPages.toFloat() else 0f
    val hasCustomCover = book.coverImagePath != null && File(book.coverImagePath).exists()

    Column(
        modifier = Modifier
            .width(cardWidth)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .width(cardWidth)
                .height(cardHeight)
                .clip(RoundedCornerShape(14.dp))
                .background(if (hasCustomCover) Color.Transparent else Color(0xFF68B984))
                .border(1.dp, RiwaqCardBorder, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (hasCustomCover) {
                Image(
                    painter = rememberAsyncImagePainter(File(book.coverImagePath!!)),
                    contentDescription = book.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Book,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = book.title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = RiwaqTextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = RiwaqBlue,
            trackColor = Color(0xFFE2E8F0)
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun HorizontalBookCard(
    book: BookEntity,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val progress = if (book.totalPages > 0) book.currentPage.toFloat() / book.totalPages.toFloat() else 0f
    val hasCustomCover = book.coverImagePath != null && File(book.coverImagePath).exists()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = book.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = RiwaqTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "صفحة ${book.currentPage + 1} من ${book.totalPages} (${(progress * 100).toInt()}%)",
                    fontSize = 12.sp,
                    color = RiwaqTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = RiwaqBlue,
                    trackColor = Color(0xFFE2E8F0)
                )
            }

            Box(
                modifier = Modifier
                    .size(width = 65.dp, height = 85.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (hasCustomCover) Color.Transparent else Color(0xFF68B984))
                    .border(1.dp, RiwaqCardBorder, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (hasCustomCover) {
                    Image(
                        painter = rememberAsyncImagePainter(File(book.coverImagePath!!)),
                        contentDescription = book.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Book,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(
    viewModel: RiwaqViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    var tab by remember { mutableStateOf(0) }
    androidx.compose.foundation.layout.Column(modifier = modifier.fillMaxSize()) {
        androidx.compose.material3.TabRow(
            selectedTabIndex = tab,
            containerColor = Color.Transparent,
            contentColor = RiwaqBlue
        ) {
            androidx.compose.material3.Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("المكتبة") })
            androidx.compose.material3.Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("بومودورو") })
        }
        if (tab == 0) {
            LibraryPane(viewModel = viewModel, onNavigate = onNavigate, modifier = Modifier.weight(1f))
        } else {
            PomodoroPanel(viewModel = viewModel, modifier = Modifier.weight(1f))
        }
    }
}
