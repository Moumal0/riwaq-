package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BookEntity
import com.example.data.model.HabitEntity
import com.example.data.model.NoteEntity
import com.example.data.model.TaskEntity
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.PriorityIndicator
import com.example.ui.navigation.Screen
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary

@Composable
fun HomeScreen(
    viewModel: RiwaqViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.allTasks.collectAsStateWithLifecycle()
    val habits by viewModel.allHabits.collectAsStateWithLifecycle()
    val habitLogs by viewModel.allHabitLogs.collectAsStateWithLifecycle()
    val notes by viewModel.allNotes.collectAsStateWithLifecycle()
    val books by viewModel.allBooks.collectAsStateWithLifecycle()

    val todayStr = remember { RiwaqViewModel.getTodayDateString() }
    val completedHabitIds = remember(habitLogs, todayStr) {
        habitLogs.filter { it.dateString == todayStr && it.isCompleted }.map { it.habitId }.toSet()
    }

    var showQuickActionDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val filteredTasks = remember(tasks, searchQuery) {
        if (searchQuery.isBlank()) tasks else tasks.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }
    val filteredHabits = remember(habits, searchQuery) {
        if (searchQuery.isBlank()) habits else habits.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }
    // ثلاث عادات غير منجزة؛ عند إكمال واحدة تختفي وتظهر التالية
    val pendingHabits = remember(filteredHabits, completedHabitIds) {
        filteredHabits.filter { !completedHabitIds.contains(it.id) }.take(3)
    }
    // ثلاث مهام: الطارئة ثم المتوسطة ثم العادية
    val topTasks = remember(filteredTasks) {
        filteredTasks.filter { !it.isCompleted }
            .sortedBy { t ->
                when (t.priority.name) {
                    "URGENT", "HIGH" -> 0
                    "MEDIUM" -> 1
                    else -> 2
                }
            }
            .take(3)
    }
    val recentBooks = remember(filteredBooks) { filteredBooks.sortedByDescending { it.lastReadMillis }.take(4) }
    val filteredNotes = remember(notes, searchQuery) {
        if (searchQuery.isBlank()) notes else notes.filter { it.title.contains(searchQuery, ignoreCase = true) || it.content.contains(searchQuery, ignoreCase = true) }
    }
    val filteredBooks = remember(books, searchQuery) {
        if (searchQuery.isBlank()) books else books.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. العادات (Habits)
            item {
                SectionHeader(
                    title = "العادات",
                    actionTitle = "عرض الكل",
                    onAction = { onNavigate(Screen.Habits) }
                )
            }

            if (filteredHabits.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "لا توجد عادات بعد",
                        subtitle = "اضغط على زر الإجراء بالأسفل أو قسم العادات لإضافة عادة جديدة"
                    )
                }
            } else {
                if (pendingHabits.isEmpty()) {
                    item {
                        EmptyStateView(
                            title = "أنجزت عادات اليوم كلها 🎉",
                            subtitle = "أحسنت! ستظهر عاداتك الجديدة غداً"
                        )
                    }
                }
                items(pendingHabits, key = { "habit_${it.id}" }) { habit ->
                    val isDone = completedHabitIds.contains(habit.id)
                    HomeHabitCard(
                        habit = habit,
                        isDone = isDone,
                        onToggle = { done -> viewModel.toggleHabitToday(habit.id, done) },
                        onClick = { onNavigate(Screen.Habits) }
                    )
                }
            }

            // 2. المهمات (Tasks)
            item {
                Spacer(modifier = Modifier.height(8.dp))
                SectionHeader(
                    title = "المهمات",
                    actionTitle = "عرض الكل",
                    onAction = { onNavigate(Screen.Tasks) }
                )
            }

            if (filteredTasks.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "لا توجد مهام اليوم",
                        subtitle = "ابدأ يومك بإضافة مهام جديدة لإنجازها وحساب الحماس"
                    )
                }
            } else {
                items(topTasks, key = { "task_${it.id}" }) { task ->
                    HomeTaskCard(
                        task = task,
                        onToggle = { viewModel.toggleTaskComplete(task) },
                        onClick = { onNavigate(Screen.Tasks) }
                    )
                }
            }

            // 4. واصل القراءة (Continue Reading)
            item {
                Spacer(modifier = Modifier.height(8.dp))
                SectionHeader(
                    title = "واصل القراءة",
                    actionTitle = "المكتبة",
                    onAction = { onNavigate(Screen.Library) }
                )
            }

            if (filteredBooks.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "لا توجد كتب حالياً",
                        subtitle = "أضف كتب PDF إلى مكتبتك لقراءتها وحفظ تقدمك"
                    )
                }
            } else {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        items(recentBooks, key = { "book_${it.id}" }) { book ->
                            HomeBookCard(
                                book = book,
                                onClick = { onNavigate(Screen.PdfReader(book.id)) }
                            )
                        }
                    }
                }
            }
            // 3. آخر الملاحظات (Latest Notes)
            item {
                Spacer(modifier = Modifier.height(8.dp))
                SectionHeader(
                    title = "اخر الملاحظات",
                    actionTitle = "عرض الكل",
                    onAction = { onNavigate(Screen.Notes) }
                )
            }

            if (filteredNotes.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "لا توجد ملاحظات",
                        subtitle = "دوّن أفكارك وخواطرك في قسم الملاحظات"
                    )
                }
            } else {
                items(filteredNotes.take(2), key = { "note_${it.id}" }) { note ->
                    HomeNoteCard(
                        note = note,
                        onClick = { onNavigate(Screen.NoteEditor(note.id, note.folderId)) }
                    )
                }
            }
        }

        // Bottom Action Button (Search & Quick Action)
        FloatingActionButton(
            onClick = { showQuickActionDialog = true },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
                .testTag("home_action_button"),
            containerColor = Color.White,
            contentColor = RiwaqBlue,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "بحث وإجراءات سريعة",
                modifier = Modifier.size(28.dp)
            )
        }

        if (showQuickActionDialog) {
            HomeQuickActionDialog(
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                onDismiss = { showQuickActionDialog = false },
                onNavigate = onNavigate
            )
        }
    }
}

@Composable
private fun SectionHeader(
    title: String,
    actionTitle: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = RiwaqTextPrimary
        )
        TextButton(onClick = onAction) {
            Text(
                text = actionTitle,
                fontSize = 13.sp,
                color = RiwaqBlue
            )
        }
    }
}

@Composable
private fun HomeHabitCard(
    habit: HabitEntity,
    isDone: Boolean,
    onToggle: (Boolean) -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left toggle buttons (✕ and ✓)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = { onToggle(false) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إلغاء الإنجاز",
                        tint = if (!isDone) RiwaqPriorityRed else Color.LightGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = { onToggle(true) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "تم الإنجاز",
                        tint = if (isDone) RiwaqPriorityGreen else Color.LightGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Habit Title
            Text(
                text = habit.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = RiwaqTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun HomeTaskCard(
    task: TaskEntity,
    onToggle: () -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 12.dp, end = 0.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left toggle buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (task.isCompleted) Icons.Default.Check else Icons.Default.Close,
                        contentDescription = if (task.isCompleted) "مكتملة" else "غير مكتملة",
                        tint = if (task.isCompleted) RiwaqPriorityGreen else RiwaqPriorityRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Task title
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = task.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (task.isCompleted) RiwaqTextMuted else RiwaqTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Priority Indicator Stripe on right edge
            PriorityIndicator(priority = task.priority)
        }
    }
}

@Composable
private fun HomeNoteCard(
    note: NoteEntity,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = note.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = RiwaqTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (note.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = note.content,
                    fontSize = 13.sp,
                    color = RiwaqTextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun HomeBookCard(
    book: BookEntity,
    onClick: () -> Unit
) {
    val progress = if (book.totalPages > 0) book.currentPage.toFloat() / book.totalPages.toFloat() else 0f
    Box(
        modifier = Modifier
            .width(130.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(width = 80.dp, height = 110.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF68B984)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Book,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = book.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = RiwaqTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = RiwaqBlue,
                trackColor = Color(0xFFE2E8F0)
            )
        }
    }
}

@Composable
private fun HomeQuickActionDialog(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onNavigate: (Screen) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "البحث والإجراءات السريعة",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = RiwaqTextPrimary
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input"),
                    placeholder = { Text("ابحث في المهام، الملاحظات، العادات...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = RiwaqBlue)
                    },
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = {
                        onDismiss()
                        onNavigate(Screen.Tasks)
                    }) {
                        Text("+ إضافة مهمة", color = RiwaqBlue)
                    }
                    TextButton(onClick = {
                        onDismiss()
                        onNavigate(Screen.Habits)
                    }) {
                        Text("+ إضافة عادة", color = RiwaqBlue)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = {
                        onDismiss()
                        onNavigate(Screen.NoteEditor(0, null))
                    }) {
                        Text("+ كتابة ملاحظة", color = RiwaqBlue)
                    }
                    TextButton(onClick = {
                        onDismiss()
                        onNavigate(Screen.Library)
                    }) {
                        Text("+ إضافة كتاب PDF", color = RiwaqBlue)
                    }
                }

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text("إغلاق", color = RiwaqTextSecondary)
                }
            }
        }
    }
}
