package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.TaskPriority
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqPriorityOrange
import com.example.ui.theme.RiwaqPriorityRed

@Composable
fun PriorityIndicator(
    priority: TaskPriority,
    modifier: Modifier = Modifier,
    onRight: Boolean = true
) {
    val color = when (priority) {
        TaskPriority.URGENT -> RiwaqPriorityRed
        TaskPriority.MEDIUM -> RiwaqPriorityOrange
        TaskPriority.NORMAL -> RiwaqPriorityGreen
    }

    Box(
        modifier = modifier
            .width(6.dp)
            .fillMaxHeight()
            .background(
                color = color,
                shape = if (onRight) RoundedCornerShape(topStart = 0.dp, bottomStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp)
                else RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp, topEnd = 0.dp, bottomEnd = 0.dp)
            )
    )
}
