package com.example.ui.components

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary

/**
 * Utility to safely parse hex colors with fallback.
 */
fun parseHexColor(hex: String, fallback: Color = RiwaqBlue): Color {
    return try {
        Color(AndroidColor.parseColor(hex))
    } catch (_: Exception) {
        fallback
    }
}

/**
 * Utility to format Compose Color to uppercase #RRGGBB hex string.
 */
fun formatColorToHex(color: Color): String {
    val argb = color.toArgb()
    val r = (argb shr 16) and 0xFF
    val g = (argb shr 8) and 0xFF
    val b = argb and 0xFF
    return String.format("#%02X%02X%02X", r, g, b)
}

/**
 * Modern M3 Color Picker with Hue, Saturation, Lightness sliders, Hex input,
 * and live interactive preview swatch.
 */
@Composable
fun RiwaqColorPickerDialog(
    title: String,
    initialHex: String,
    onDismiss: () -> Unit,
    onColorSelected: (String) -> Unit
) {
    // Initial color extraction to HSL
    val initialColor = remember(initialHex) { parseHexColor(initialHex) }
    val initialHsl = remember(initialColor) {
        val hsv = FloatArray(3)
        AndroidColor.colorToHSV(initialColor.toArgb(), hsv)
        hsv
    }

    var hue by remember { mutableFloatStateOf(initialHsl[0].coerceIn(0f, 360f)) }
    var saturation by remember { mutableFloatStateOf(initialHsl[1].coerceIn(0f, 1f)) }
    var value by remember { mutableFloatStateOf(initialHsl[2].coerceIn(0f, 1f)) }

    // Live computed color
    val currentColor = remember(hue, saturation, value) {
        val argb = AndroidColor.HSVToColor(floatArrayOf(hue, saturation, value))
        Color(argb)
    }

    var hexInputText by remember { mutableStateOf(formatColorToHex(currentColor)) }

    LaunchedEffect(currentColor) {
        val formatted = formatColorToHex(currentColor)
        if (!hexInputText.equals(formatted, ignoreCase = true)) {
            hexInputText = formatted
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = RiwaqTextPrimary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Live Swatch Preview Comparison (Current vs Initial)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "اللون الجديد", fontSize = 11.sp, color = RiwaqTextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(currentColor)
                                .border(1.5.dp, RiwaqCardBorder, RoundedCornerShape(12.dp))
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "اللون الأصلي", fontSize = 11.sp, color = RiwaqTextSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(initialColor)
                                .border(1.5.dp, RiwaqCardBorder, RoundedCornerShape(12.dp))
                                .clickable {
                                    hue = initialHsl[0]
                                    saturation = initialHsl[1]
                                    value = initialHsl[2]
                                }
                        )
                    }

                    // Hex code input
                    OutlinedTextField(
                        value = hexInputText,
                        onValueChange = { input ->
                            hexInputText = input
                            val clean = if (input.startsWith("#")) input else "#$input"
                            try {
                                if (clean.length == 7) {
                                    val parsed = AndroidColor.parseColor(clean)
                                    val newHsv = FloatArray(3)
                                    AndroidColor.colorToHSV(parsed, newHsv)
                                    hue = newHsv[0]
                                    saturation = newHsv[1]
                                    value = newHsv[2]
                                }
                            } catch (_: Exception) {}
                        },
                        label = { Text("رمز HEX", fontSize = 10.sp) },
                        modifier = Modifier.width(110.dp),
                        singleLine = true
                    )
                }

                // --- 1. Hue Slider (Spectrum) ---
                Column {
                    Text(text = "درجة اللون (Hue)", fontSize = 12.sp, color = RiwaqTextSecondary)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(14.dp)
                            .clip(RoundedCornerShape(7.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxWidth().height(14.dp)) {
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        Color.Red,
                                        Color.Yellow,
                                        Color.Green,
                                        Color.Cyan,
                                        Color.Blue,
                                        Color.Magenta,
                                        Color.Red
                                    )
                                )
                            )
                        }
                    }
                    Slider(
                        value = hue,
                        onValueChange = { hue = it },
                        valueRange = 0f..360f,
                        colors = SliderDefaults.colors(thumbColor = RiwaqBlue)
                    )
                }

                // --- 2. Saturation Slider ---
                Column {
                    Text(text = "التشبع (Saturation)", fontSize = 12.sp, color = RiwaqTextSecondary)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(14.dp)
                            .clip(RoundedCornerShape(7.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxWidth().height(14.dp)) {
                            val fullColor = Color(AndroidColor.HSVToColor(floatArrayOf(hue, 1f, value)))
                            val desatColor = Color(AndroidColor.HSVToColor(floatArrayOf(hue, 0f, value)))
                            drawRect(
                                brush = Brush.horizontalGradient(listOf(desatColor, fullColor))
                            )
                        }
                    }
                    Slider(
                        value = saturation,
                        onValueChange = { saturation = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = RiwaqBlue)
                    )
                }

                // --- 3. Lightness / Value Slider ---
                Column {
                    Text(text = "السطوع (Brightness)", fontSize = 12.sp, color = RiwaqTextSecondary)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(14.dp)
                            .clip(RoundedCornerShape(7.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxWidth().height(14.dp)) {
                            val brightColor = Color(AndroidColor.HSVToColor(floatArrayOf(hue, saturation, 1f)))
                            drawRect(
                                brush = Brush.horizontalGradient(listOf(Color.Black, brightColor))
                            )
                        }
                    }
                    Slider(
                        value = value,
                        onValueChange = { value = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = RiwaqBlue)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onColorSelected(formatColorToHex(currentColor))
                    onDismiss()
                }
            ) {
                Text("تطبيق اللون", color = RiwaqBlue, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

/**
 * Reusable Color Row with Presets + "Custom Color..." button opening full picker.
 */
@Composable
fun ColorPickerWithPresetsRow(
    title: String,
    selectedHex: String,
    presets: List<Pair<String, String>>,
    onColorSelected: (String) -> Unit
) {
    var showCustomPicker by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Button to open full color wheel picker
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFEFF6FF))
                    .clickable { showCustomPicker = true }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ColorLens,
                        contentDescription = "عجلة الألوان",
                        tint = RiwaqBlue,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "عجلة ألوان حرة...",
                        fontSize = 11.sp,
                        color = RiwaqBlue,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = RiwaqTextPrimary
            )
        }

        // Swatches list
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            // First item: The custom selected color if it is not in presets
            val isCustomActive = presets.none { it.first.equals(selectedHex, ignoreCase = true) }
            if (isCustomActive) {
                item {
                    val activeColor = parseHexColor(selectedHex)
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { showCustomPicker = true }
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(activeColor)
                                .border(width = 3.dp, color = RiwaqBlue, shape = CircleShape)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "مخصص",
                            fontSize = 10.sp,
                            color = RiwaqBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            items(presets) { (hex, name) ->
                val isSelected = selectedHex.equals(hex, ignoreCase = true)
                val color = parseHexColor(hex)

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onColorSelected(hex) }
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (isSelected) 3.dp else 1.dp,
                                color = if (isSelected) RiwaqBlue else RiwaqCardBorder,
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = name,
                        fontSize = 10.sp,
                        color = if (isSelected) RiwaqBlue else RiwaqTextSecondary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }

    if (showCustomPicker) {
        RiwaqColorPickerDialog(
            title = "تخصيص $title",
            initialHex = selectedHex,
            onDismiss = { showCustomPicker = false },
            onColorSelected = onColorSelected
        )
    }
}
