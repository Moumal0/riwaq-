package com.example.ui.screens

data class Exercise(
    val key: String,
    val ar: String,
    val en: String,
    val group: String,
    val icon: String
)

data class FoodItem(val ar: String, val kcal: Int, val unit: String)

val ExerciseGroups = listOf("صدر", "ظهر", "أكتاف", "ذراعان", "بطن", "أرجل", "كارديو", "مرونة")

val ExerciseLibrary: List<Exercise> = listOf(
    // صدر
    Exercise("pushup", "ضغط", "Push-up", "صدر", "🤸"),
    Exercise("incline_pushup", "ضغط مائل", "Incline Push-up", "صدر", "🤸"),
    Exercise("diamond_pushup", "ضغط الماس", "Diamond Push-up", "صدر", "💎"),
    Exercise("bench_press", "بنش بريس", "Bench Press", "صدر", "🏋️"),
    Exercise("incline_db_press", "ضغط دمبل مائل", "Incline Dumbbell Press", "صدر", "🏋️"),
    Exercise("dumbbell_fly", "فتح دمبل", "Dumbbell Fly", "صدر", "🦅"),
    Exercise("dips", "متوازي", "Dips", "صدر", "⬇️"),
    // ظهر
    Exercise("pullup", "عقلة", "Pull-up", "ظهر", "🧗"),
    Exercise("chinup", "عقلة عكسية", "Chin-up", "ظهر", "🧗"),
    Exercise("bent_row", "تجديف بالبار", "Barbell Row", "ظهر", "🚣"),
    Exercise("db_row", "تجديف دمبل", "Dumbbell Row", "ظهر", "🚣"),
    Exercise("lat_pulldown", "سحب علوي", "Lat Pulldown", "ظهر", "⬇️"),
    Exercise("deadlift", "رفعة ميتة", "Deadlift", "ظهر", "🏋️"),
    Exercise("superman", "سوبرمان", "Superman", "ظهر", "🦸"),
    // أكتاف
    Exercise("ohp", "ضغط كتف", "Overhead Press", "أكتاف", "🏋️"),
    Exercise("lateral_raise", "رفرفة جانبية", "Lateral Raise", "أكتاف", "🙆"),
    Exercise("front_raise", "رفرفة أمامية", "Front Raise", "أكتاف", "🙆"),
    Exercise("face_pull", "سحب للوجه", "Face Pull", "أكتاف", "🎯"),
    Exercise("shrug", "رفع الأكتاف", "Shrugs", "أكتاف", "🤷"),
    // ذراعان
    Exercise("bicep_curl", "بايسبس كيرل", "Biceps Curl", "ذراعان", "💪"),
    Exercise("hammer_curl", "هامر كيرل", "Hammer Curl", "ذراعان", "🔨"),
    Exercise("tricep_ext", "ترايسبس خلف الرأس", "Triceps Extension", "ذراعان", "💪"),
    Exercise("tricep_pushdown", "ترايسبس سحب", "Triceps Pushdown", "ذراعان", "⬇️"),
    Exercise("close_grip_pushup", "ضغط ضيق", "Close-grip Push-up", "ذراعان", "🤸"),
    // بطن
    Exercise("plank", "بلانك", "Plank", "بطن", "🧘"),
    Exercise("side_plank", "بلانك جانبي", "Side Plank", "بطن", "🧘"),
    Exercise("crunch", "تمرين المعدة", "Crunch", "بطن", "🔥"),
    Exercise("situp", "جلوس من الاستلقاء", "Sit-up", "بطن", "🔥"),
    Exercise("leg_raise", "رفع الأرجل", "Leg Raise", "بطن", "🦵"),
    Exercise("russian_twist", "التفاف روسي", "Russian Twist", "بطن", "🌀"),
    Exercise("mountain_climber", "تسلق الجبال", "Mountain Climber", "بطن", "⛰️"),
    Exercise("bicycle_crunch", "دراجة هوائية", "Bicycle Crunch", "بطن", "🚲"),
    // أرجل
    Exercise("squat", "سكوات", "Squat", "أرجل", "🦵"),
    Exercise("lunge", "اندفاع", "Lunge", "أرجل", "🦵"),
    Exercise("bulgarian", "سكوات بلغاري", "Bulgarian Split Squat", "أرجل", "🦵"),
    Exercise("leg_press", "ضغط الأرجل", "Leg Press", "أرجل", "🦿"),
    Exercise("romanian_dl", "رفعة رومانية", "Romanian Deadlift", "أرجل", "🏋️"),
    Exercise("calf_raise", "رفع السمانة", "Calf Raise", "أرجل", "🦶"),
    Exercise("glute_bridge", "جسر الأرداف", "Glute Bridge", "أرجل", "🌉"),
    Exercise("wall_sit", "جلوس على الحائط", "Wall Sit", "أرجل", "🧱"),
    Exercise("step_up", "صعود الدرجة", "Step-up", "أرجل", "🪜"),
    // كارديو
    Exercise("run", "جري", "Running", "كارديو", "🏃"),
    Exercise("walk", "مشي", "Walking", "كارديو", "🚶"),
    Exercise("cycling", "دراجة", "Cycling", "كارديو", "🚴"),
    Exercise("swim", "سباحة", "Swimming", "كارديو", "🏊"),
    Exercise("jump_rope", "نط الحبل", "Jump Rope", "كارديو", "🪢"),
    Exercise("burpee", "بيربي", "Burpee", "كارديو", "💥"),
    Exercise("jumping_jack", "قفز النجمة", "Jumping Jacks", "كارديو", "⭐"),
    Exercise("hiit", "تمارين عالية الشدة", "HIIT", "كارديو", "⚡"),
    Exercise("stairs", "صعود السلالم", "Stair Climbing", "كارديو", "🪜"),
    Exercise("rowing", "جهاز التجديف", "Rowing Machine", "كارديو", "🚣"),
    Exercise("football", "كرة قدم", "Football", "كارديو", "⚽"),
    Exercise("basketball", "كرة سلة", "Basketball", "كارديو", "🏀"),
    Exercise("boxing", "ملاكمة", "Boxing", "كارديو", "🥊"),
    // مرونة
    Exercise("yoga", "يوغا", "Yoga", "مرونة", "🧘"),
    Exercise("stretching", "إطالة", "Stretching", "مرونة", "🤸"),
    Exercise("pilates", "بيلاتس", "Pilates", "مرونة", "🧘"),
    Exercise("foam_roll", "تدليك بالأسطوانة", "Foam Rolling", "مرونة", "🧴")
)

fun findExercise(key: String): Exercise? = ExerciseLibrary.firstOrNull { it.key == key }

/** قيم تقريبية للمساعدة في الإدخال السريع، وليست بديلاً عن مصدر غذائي دقيق. */
val FoodLibrary: List<FoodItem> = listOf(
    FoodItem("تمرة", 23, "حبة"),
    FoodItem("تمور (5 حبات)", 115, "حصة"),
    FoodItem("رغيف خبز", 80, "رغيف"),
    FoodItem("رز مطبوخ", 205, "كوب"),
    FoodItem("صدر دجاج مشوي", 165, "100 غ"),
    FoodItem("لحم بقر مطبوخ", 250, "100 غ"),
    FoodItem("سمك مشوي", 130, "100 غ"),
    FoodItem("بيضة مسلوقة", 78, "حبة"),
    FoodItem("حليب", 120, "كوب"),
    FoodItem("لبن/زبادي", 100, "كوب"),
    FoodItem("جبن أبيض", 75, "30 غ"),
    FoodItem("عدس مطبوخ", 230, "كوب"),
    FoodItem("حمص مطبوخ", 270, "كوب"),
    FoodItem("شوفان", 150, "40 غ"),
    FoodItem("موزة", 105, "حبة"),
    FoodItem("تفاحة", 95, "حبة"),
    FoodItem("برتقالة", 62, "حبة"),
    FoodItem("لوز", 165, "28 غ"),
    FoodItem("زيت زيتون", 120, "ملعقة كبيرة"),
    FoodItem("بطاطس مسلوقة", 130, "حبة متوسطة"),
    FoodItem("سلطة خضار", 50, "طبق"),
    FoodItem("مكرونة مطبوخة", 220, "كوب"),
    FoodItem("بيتزا", 285, "شريحة"),
    FoodItem("همبرغر", 350, "حبة"),
    FoodItem("عصير برتقال", 110, "كوب"),
    FoodItem("مشروب غازي", 140, "علبة")
)
