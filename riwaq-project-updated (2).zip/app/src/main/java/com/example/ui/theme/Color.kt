package com.example.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** حالة السمة: تغيير اللون المميز يُحدّث كل الواجهات التي تستخدم RiwaqBlue فوراً. */
object ThemeState {
    var accent by mutableStateOf(Color(0xFF3B82F6))
}

val RiwaqBlue: Color get() = ThemeState.accent
val RiwaqBlueDark = Color(0xFF1D4ED8)
val RiwaqRailBg = Color(0xFF92B4F8)
val RiwaqRailIconActive = Color(0xFF1E3A8A)
val RiwaqRailIconInactive = Color(0xFFE0EDFF)

val RiwaqBg = Color(0xFFF8FAFC)
val RiwaqCardBg = Color(0xFFFFFFFF)
val RiwaqCardBorder = Color(0xFFE2E8F0)

val RiwaqPriorityGreen = Color(0xFF22C55E)
val RiwaqPriorityOrange = Color(0xFFF59E0B)
val RiwaqPriorityRed = Color(0xFFEF4444)

val RiwaqTerracotta = Color(0xFFC27D6B)
val RiwaqTerracottaHeader = Color(0xFFB87360)

val RiwaqTextPrimary = Color(0xFF1E293B)
val RiwaqTextSecondary = Color(0xFF64748B)
val RiwaqTextMuted = Color(0xFF94A3B8)
