package com.example.ui.screens

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.RiwaqViewModel

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** تثبيت التطبيق (Screen Pinning): يمنع مغادرة التطبيق بالإيماءات العادية، مع بقاء التنقل داخله وقفل الشاشة. */
fun Context.pinApp() {
    try { findActivity()?.startLockTask() } catch (_: Exception) {}
}

fun Context.unpinApp() {
    try { findActivity()?.stopLockTask() } catch (_: Exception) {}
}

fun Context.isAppPinned(): Boolean = try {
    val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
} catch (_: Exception) {
    false
}

private fun formatClock(totalSec: Int): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

/**
 * التركيز الفائق: الصورة تملأ الشاشة، المؤقت في النصف العلوي،
 * والنصف السفلي مغطّى بتعتيم أسود بنسبة 50% وفيه أزرار التحكم.
 * يمكن اختيار مؤقت بومودورو أو ساعة إيقاف قابلة للتعديل، وتغيير الصورة من المعرض.
 */
@Composable
fun UltraFocusDialog(viewModel: RiwaqViewModel, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("riwaq_focus", Context.MODE_PRIVATE) }
    var bgUri by remember { mutableStateOf(prefs.getString("bg_uri", null)) }
    var mode by remember { mutableStateOf(prefs.getString("mode", "POMODORO") ?: "POMODORO") }
    val p by viewModel.pomodoro.collectAsStateWithLifecycle()
    val sw by viewModel.stopwatch.collectAsStateWithLifecycle()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            bgUri = uri.toString()
            prefs.edit().putString("bg_uri", bgUri).apply()
        }
    }

    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
            val uri = bgUri
            if (uri == null) {
                Image(
                    painter = painterResource(R.drawable.focus_bg),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                AsyncImage(
                    model = Uri.parse(uri),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // النصف العلوي: المؤقت فوق الصورة
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    val isPomodoro = mode == "POMODORO"
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isPomodoro) (if (p.isBreak) "استراحة" else "تركيز") else "ساعة الإيقاف",
                            fontSize = 16.sp,
                            color = Color.White.copy(alpha = 0.9f),
                            style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 8f))
                        )
                        Text(
                            text = if (isPomodoro) formatClock(p.remainingSec) else formatClock(sw.elapsedSec),
                            fontSize = 64.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 3f), 12f))
                        )
                    }
                }

                // النصف السفلي: تعتيم أسود 50% + أدوات التحكم
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf("POMODORO" to "بومودورو", "STOPWATCH" to "ساعة إيقاف").forEach { (m, label) ->
                            val sel = mode == m
                            Text(
                                text = label,
                                fontSize = 13.sp,
                                color = if (sel) Color.Black else Color.White,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (sel) Color.White else Color.White.copy(alpha = 0.18f))
                                    .clickable {
                                        mode = m
                                        prefs.edit().putString("mode", m).apply()
                                    }
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }
                    }

                    if (mode == "POMODORO") {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            IconButton(onClick = { viewModel.pomodoroReset() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "إعادة", tint = Color.White)
                            }
                            PlayButton(running = p.isRunning, onClick = { viewModel.pomodoroToggle() })
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                                IconButton(onClick = { viewModel.stopwatchReset() }) {
                                    Icon(Icons.Default.Refresh, contentDescription = "تصفير", tint = Color.White)
                                }
                                PlayButton(running = sw.isRunning, onClick = { viewModel.stopwatchToggle() })
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(-600 to "-10د", -60 to "-1د", 60 to "+1د", 600 to "+10د").forEach { (d, label) ->
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        color = Color.White,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color.White.copy(alpha = 0.18f))
                                            .clickable { viewModel.stopwatchAdjust(d) }
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { picker.launch(arrayOf("image/*")) }) {
                            Text("تغيير الصورة", color = Color.White)
                        }
                        TextButton(onClick = {
                            ctx.unpinApp()
                            onExit()
                        }) { Text("إنهاء التركيز", color = Color(0xFFFCA5A5), fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayButton(running: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.9f)),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onClick) {
            Icon(
                if (running) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (running) "إيقاف مؤقت" else "ابدأ",
                tint = Color.Black,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}
