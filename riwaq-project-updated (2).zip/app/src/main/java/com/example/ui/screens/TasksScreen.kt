package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.PriorityIndicator
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqPriorityOrange
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary

@Composable
fun TasksScreen(
    viewModel: RiwaqViewModel,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.allTasks.collectAsStateWithLifecycle()
    var selectedPriorityFilter by remember { mutableStateOf<TaskPriority?>(null) }

    var showAddDialog by remember { mutableStateOf(false) }
    var taskToEdit by remember { mutableStateOf<TaskEntity?>(null) }
    var taskToDelete by remember { mutableStateOf<TaskEntity?>(null) }

    val settings by viewModel.appSettings.collectAsStateWithLifecycle()
    val stripOnRight = settings.sidebarPosition == "RIGHT"

    // الترتيب: غير المكتملة أولاً، ثم الطارئة، فالمتوسطة، فالعادية
    val filteredTasks = remember(tasks, selectedPriorityFilter) {
        val base = if (selectedPriorityFilter == null) tasks else tasks.filter { it.priority == selectedPriorityFilter }
        base.sortedWith(
            compareBy<TaskEntity> { it.isCompleted }.thenBy {
                when (it.priority) {
                    TaskPriority.URGENT -> 0
                    TaskPriority.MEDIUM -> 1
                    TaskPriority.NORMAL -> 2
                }
            }
        )
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${tasks.count { it.isCompleted }}/${tasks.size} مكتملة",
                        fontSize = 13.sp,
                        color = RiwaqTextSecondary
                    )
                    Text(
                        text = "المهمات",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary
                    )
                }
            }

            // Priority Filter Bar (Matching Screenshot 6 header)
            item {
                PriorityFilterBar(
                    selectedPriority = selectedPriorityFilter,
                    onSelect = { selectedPriorityFilter = it }
                )
            }

            if (filteredTasks.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "لا توجد مهام حالياً",
                        subtitle = "اضغط على زر (+) في الأسفل لإنشاء مهمة جديدة"
                    )
                }
            } else {
                items(filteredTasks, key = { "task_${it.id}" }) { task ->
                    TaskCard(
                        task = task,
                        onToggle = { viewModel.toggleTaskComplete(task) },
                        onEdit = { taskToEdit = task },
                        onDelete = { taskToDelete = task },
                        stripOnRight = stripOnRight
                    )
                }
            }
        }

        // Floating Action Button (+)
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
                .testTag("add_task_fab"),
            containerColor = Color.White,
            contentColor = RiwaqBlue,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة مهمة جديدة",
                modifier = Modifier.size(28.dp)
            )
        }

        // Add or Edit Dialog
        if (showAddDialog || taskToEdit != null) {
            TaskFormDialog(
                initialTask = taskToEdit,
                onDismiss = {
                    showAddDialog = false
                    taskToEdit = null
                },
                onSave = { title, priority, duration ->
                    if (taskToEdit != null) {
                        viewModel.updateTask(
                            taskToEdit!!.copy(
                                title = title,
                                priority = priority,
                                durationMinutes = duration
                            )
                        )
                    } else {
                        viewModel.addTask(
                            title = title,
                            dueDateMillis = System.currentTimeMillis(),
                            priority = priority,
                            durationMinutes = duration
                        )
                    }
                    showAddDialog = false
                    taskToEdit = null
                },
                onDelete = {
                    taskToDelete = taskToEdit
                    taskToEdit = null
                    showAddDialog = false
                }
            )
        }

        // Delete Confirmation Dialog
        if (taskToDelete != null) {
            AlertDialog(
                onDismissRequest = { taskToDelete = null },
                title = { Text("حذف المهمة") },
                text = { Text("هل تريد بالتأكيد حذف هذه المهمة؟") },
                confirmButton = {
                    TextButton(onClick = {
                        taskToDelete?.let { viewModel.deleteTask(it) }
                        taskToDelete = null
                    }) {
                        Text("حذف", color = RiwaqPriorityRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { taskToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
private fun PriorityFilterBar(
    selectedPriority: TaskPriority?,
    onSelect: (TaskPriority?) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // All
            FilterDotItem(
                label = "الكل",
                color = RiwaqBlue,
                isSelected = selectedPriority == null,
                onClick = { onSelect(null) }
            )

            // Normal
            FilterDotItem(
                label = "عادية",
                color = RiwaqPriorityGreen,
                isSelected = selectedPriority == TaskPriority.NORMAL,
                onClick = { onSelect(TaskPriority.NORMAL) }
            )

            // Medium
            FilterDotItem(
                label = "متوسطة",
                color = RiwaqPriorityOrange,
                isSelected = selectedPriority == TaskPriority.MEDIUM,
                onClick = { onSelect(TaskPriority.MEDIUM) }
            )

            // Urgent
            FilterDotItem(
                label = "طارئة",
                color = RiwaqPriorityRed,
                isSelected = selectedPriority == TaskPriority.URGENT,
                onClick = { onSelect(TaskPriority.URGENT) }
            )
        }
    }
}

@Composable
private fun FilterDotItem(
    label: String,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) color.copy(alpha = 0.15f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) color else RiwaqTextPrimary
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun TaskCard(
    task: TaskEntity,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    stripOnRight: Boolean = true
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = onEdit,
                onLongClick = onDelete
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left toggle buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (task.isCompleted) Icons.Default.Check else Icons.Default.Close,
                        contentDescription = if (task.isCompleted) "مكتملة" else "غير مكتملة",
                        tint = if (task.isCompleted) RiwaqPriorityGreen else RiwaqPriorityRed,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Task title
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = task.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (task.isCompleted) RiwaqTextMuted else RiwaqTextPrimary,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

        }

        // شريط الحالة على نفس جهة الشريط الجانبي (يمين/يسار)
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Ltr
        ) {
            Box(modifier = Modifier.matchParentSize()) {
                PriorityIndicator(
                    priority = task.priority,
                    onRight = stripOnRight,
                    modifier = Modifier.align(if (stripOnRight) Alignment.CenterEnd else Alignment.CenterStart)
                )
            }
        }
    }
}

@Composable
private fun TaskFormDialog(
    initialTask: TaskEntity?,
    onDismiss: () -> Unit,
    onSave: (title: String, priority: TaskPriority, duration: Int) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember { mutableStateOf(initialTask?.title ?: "") }
    var priority by remember { mutableStateOf(initialTask?.priority ?: TaskPriority.NORMAL) }
    var durationMinutes by remember { mutableStateOf(initialTask?.durationMinutes ?: 15) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header (Close / Save buttons)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء", tint = RiwaqPriorityRed)
                        }
                        IconButton(
                            onClick = {
                                if (title.isNotBlank()) {
                                    onSave(title, priority, durationMinutes)
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "حفظ", tint = RiwaqPriorityGreen)
                        }
                    }

                    Text(
                        text = if (initialTask == null) "اكتب المهمة" else "تعديل المهمة",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary
                    )
                }

                // Input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("مثال: زيارة طبيب الأسنان") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_title_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                // Priority dots selection (Matching Screenshot 6)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        // Green (Normal)
                        PriorityDotButton(
                            color = RiwaqPriorityGreen,
                            isSelected = priority == TaskPriority.NORMAL,
                            onClick = { priority = TaskPriority.NORMAL }
                        )
                        // Orange (Medium)
                        PriorityDotButton(
                            color = RiwaqPriorityOrange,
                            isSelected = priority == TaskPriority.MEDIUM,
                            onClick = { priority = TaskPriority.MEDIUM }
                        )
                        // Red (Urgent)
                        PriorityDotButton(
                            color = RiwaqPriorityRed,
                            isSelected = priority == TaskPriority.URGENT,
                            onClick = { priority = TaskPriority.URGENT }
                        )
                    }
                    Text(
                        text = "حالة المهمة",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = RiwaqTextPrimary
                    )
                }

                // Task time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(15, 30, 60).forEach { mins ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (durationMinutes == mins) RiwaqBlue else Color(0xFFF1F5F9))
                                    .clickable { durationMinutes = mins }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "$mins min",
                                    fontSize = 12.sp,
                                    color = if (durationMinutes == mins) Color.White else RiwaqTextPrimary
                                )
                            }
                        }
                    }
                    Text(
                        text = "وقت المهمة",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = RiwaqTextPrimary
                    )
                }

                if (initialTask != null) {
                    TextButton(
                        onClick = onDelete,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = RiwaqPriorityRed)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حذف هذه المهمة", color = RiwaqPriorityRed)
                    }
                }
            }
        }
    }
}

@Composable
private fun PriorityDotButton(
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(if (isSelected) color.copy(alpha = 0.25f) else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(color)
        )
    }
}
