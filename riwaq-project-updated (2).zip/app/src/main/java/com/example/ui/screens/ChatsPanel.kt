package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import com.example.data.chat.LinkStatus
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ChatThreadEntity
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary

// برتقالي، أزرق، أصفر، أحمر قاتم
private val ChatPalette = listOf("#F97316", "#3B82F6", "#EAB308", "#991B1B")

private fun typeLabel(type: String) = when (type) {
    "BLUETOOTH" -> "Bluetooth"
    "LAN" -> "LAN"
    else -> "محلية"
}

private fun parseChatColor(hex: String): Color =
    try { Color(AndroidColor.parseColor(hex)) } catch (_: Exception) { RiwaqBlue }

private fun chatTextColorFor(bg: Color): Color {
    val lum = 0.299f * bg.red + 0.587f * bg.green + 0.114f * bg.blue
    return if (lum > 0.6f) Color(0xFF111111) else Color.White
}

/** المحادثات المحلية (أوفلاين) — محادثات بألوان فقاعات مخصصة، مخزنة على الجهاز. */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ChatsPanel(viewModel: RiwaqViewModel, modifier: Modifier = Modifier) {
    val threads by viewModel.chatThreads.collectAsStateWithLifecycle()
    var openThreadId by remember { mutableStateOf<Long?>(null) }
    var showNewDialog by remember { mutableStateOf(false) }
    var titleInput by remember { mutableStateOf("") }
    var threadToDelete by remember { mutableStateOf<ChatThreadEntity?>(null) }
    var newType by remember { mutableStateOf("LOCAL") }

    val openThread = threads.find { it.id == openThreadId }

    if (openThread != null) {
        ChatThreadView(
            thread = openThread,
            viewModel = viewModel,
            onBack = { openThreadId = null },
            modifier = modifier
        )
        return
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "محادثات محلية على جهازك (أوفلاين)",
                fontSize = 12.sp,
                color = RiwaqTextSecondary
            )
            if (threads.isEmpty()) {
                EmptyStateView(
                    title = "لا توجد محادثات",
                    subtitle = "اضغط على زر (+) لبدء محادثة جديدة"
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(threads, key = { "thread_${it.id}" }) { t ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
                                .combinedClickable(
                                    onClick = { openThreadId = t.id },
                                    onLongClick = { threadToDelete = t }
                                )
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(RiwaqBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = t.title.take(1),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = t.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = RiwaqTextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = typeLabel(t.type),
                                fontSize = 11.sp,
                                color = RiwaqBlue,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFE8F0FE))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }

        androidx.compose.material3.FloatingActionButton(
            onClick = { showNewDialog = true },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp),
            containerColor = Color.White,
            contentColor = RiwaqBlue,
            shape = CircleShape
        ) {
            Icon(Icons.Default.Add, contentDescription = "محادثة جديدة", modifier = Modifier.size(28.dp))
        }
    }

    if (showNewDialog) {
        AlertDialog(
            onDismissRequest = { showNewDialog = false; titleInput = "" },
            title = { Text("محادثة جديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        placeholder = { Text("اسم المحادثة...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("LOCAL", "BLUETOOTH", "LAN").forEach { t ->
                            val sel = newType == t
                            Text(
                                text = typeLabel(t),
                                fontSize = 13.sp,
                                color = if (sel) Color.White else RiwaqBlue,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (sel) RiwaqBlue else Color(0xFFE8F0FE))
                                    .clickable { newType = t }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                    Text(
                        text = when (newType) {
                            "BLUETOOTH" -> "تتواصل مع جهاز مقترن عبر Bluetooth بدون إنترنت."
                            "LAN" -> "تتواصل مع جهاز على نفس شبكة Wi-Fi."
                            else -> "محادثة محفوظة على هذا الجهاز فقط."
                        },
                        fontSize = 12.sp,
                        color = RiwaqTextSecondary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.createChatThread(titleInput, newType)
                    newType = "LOCAL"
                    showNewDialog = false
                    titleInput = ""
                }) { Text("إنشاء", color = RiwaqBlue) }
            },
            dismissButton = {
                TextButton(onClick = { showNewDialog = false; titleInput = "" }) { Text("إلغاء") }
            }
        )
    }

    if (threadToDelete != null) {
        AlertDialog(
            onDismissRequest = { threadToDelete = null },
            title = { Text("حذف المحادثة") },
            text = { Text("سيتم حذف '${threadToDelete?.title}' وكل رسائلها.") },
            confirmButton = {
                TextButton(onClick = {
                    threadToDelete?.let { viewModel.deleteChatThread(it.id) }
                    threadToDelete = null
                }) { Text("حذف", color = RiwaqPriorityRed) }
            },
            dismissButton = {
                TextButton(onClick = { threadToDelete = null }) { Text("إلغاء") }
            }
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ChatThreadView(
    thread: ChatThreadEntity,
    viewModel: RiwaqViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val flow = remember(thread.id) { viewModel.chatMessages(thread.id) }
    val messages by flow.collectAsStateWithLifecycle(initialValue = emptyList<ChatMessageEntity>())
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var colorHex by remember { mutableStateOf(ChatPalette[0]) }
    var isMine by remember { mutableStateOf(true) }
    val ctx = LocalContext.current
    val link by viewModel.linkUi.collectAsStateWithLifecycle()
    val linkThread by viewModel.linkThreadId.collectAsStateWithLifecycle()
    val isNetwork = thread.type != "LOCAL"
    val linkActive = isNetwork && linkThread == thread.id
    val connected = linkActive && link.status == LinkStatus.CONNECTED
    var ipInput by remember { mutableStateOf("") }
    var showIpField by remember { mutableStateOf(false) }
    var showDevices by remember { mutableStateOf(false) }
    var pendingBt by remember { mutableStateOf<(() -> Unit)?>(null) }
    val btPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingBt?.invoke() else Toast.makeText(ctx, "صلاحية Bluetooth مطلوبة", Toast.LENGTH_SHORT).show()
        pendingBt = null
    }
    val runWithBt: (() -> Unit) -> Unit = { action ->
        if (Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        ) {
            action()
        } else {
            pendingBt = action
            btPermLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Column(modifier = modifier.fillMaxSize().imePadding()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = RiwaqTextPrimary)
            }
            Text(
                text = thread.title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = RiwaqTextPrimary,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { viewModel.deleteChatThread(thread.id); onBack() }) {
                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RiwaqPriorityRed)
            }
        }

        if (isNetwork) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF1F5F9))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = (if (thread.type == "LAN") "LAN: " else "Bluetooth: ") +
                        (if (linkActive && link.info.isNotEmpty()) link.info else "غير متصل"),
                    fontSize = 12.sp,
                    color = if (connected) Color(0xFF15803D) else RiwaqTextSecondary
                )
                if (!linkActive || link.status == LinkStatus.IDLE || link.status == LinkStatus.ERROR) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            if (thread.type == "LAN") viewModel.linkHostLan(thread.id)
                            else if (!viewModel.isBluetoothAvailable()) {
                                Toast.makeText(ctx, "فعّل Bluetooth أولاً", Toast.LENGTH_SHORT).show()
                            } else runWithBt { viewModel.linkHostBluetooth(thread.id) }
                        }) { Text("استضافة", color = RiwaqBlue) }
                        TextButton(onClick = {
                            if (thread.type == "LAN") showIpField = !showIpField
                            else if (!viewModel.isBluetoothAvailable()) {
                                Toast.makeText(ctx, "فعّل Bluetooth واقترن بالجهاز الآخر من إعدادات النظام أولاً", Toast.LENGTH_LONG).show()
                            } else runWithBt { showDevices = true }
                        }) { Text("اتصال", color = RiwaqBlue) }
                    }
                    if (thread.type == "LAN" && showIpField) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = ipInput,
                                onValueChange = { ipInput = it.filter { c -> c.isDigit() || c == '.' } },
                                placeholder = { Text("عنوان الجهاز المضيف 192.168.x.x") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = {
                                if (ipInput.isNotBlank()) viewModel.linkConnectLan(thread.id, ipInput)
                            }) { Text("اتصل", color = RiwaqBlue) }
                        }
                    }
                } else {
                    TextButton(onClick = { viewModel.linkClose() }) { Text("قطع الاتصال", color = RiwaqPriorityRed) }
                }
            }
        }

        if (showDevices) {
            val devices = remember { viewModel.bondedBluetoothDevices() }
            AlertDialog(
                onDismissRequest = { showDevices = false },
                title = { Text("اختر جهازاً مقترناً") },
                text = {
                    if (devices.isEmpty()) {
                        Text("لا توجد أجهزة مقترنة. اقترن بالجهاز الآخر من إعدادات Bluetooth في النظام.")
                    } else {
                        Column {
                            devices.forEach { (n, addr) ->
                                Text(
                                    text = n,
                                    color = RiwaqBlue,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showDevices = false
                                            viewModel.linkConnectBluetooth(thread.id, addr)
                                        }
                                        .padding(vertical = 10.dp)
                                )
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showDevices = false }) { Text("إغلاق") } }
            )
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { "msg_${it.id}" }) { m ->
                val bg = parseChatColor(m.colorHex)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.isMine) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .widthIn(max = 280.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(bg)
                            .combinedClickable(
                                onClick = {},
                                onLongClick = { viewModel.deleteChatMessage(m.id) }
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(text = m.text, color = chatTextColorFor(bg), fontSize = 14.sp)
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ChatPalette.forEach { hex ->
                    Box(
                        modifier = Modifier
                            .size(if (hex == colorHex) 30.dp else 26.dp)
                            .clip(CircleShape)
                            .background(parseChatColor(hex))
                            .border(
                                if (hex == colorHex) 2.dp else 0.dp,
                                RiwaqTextPrimary,
                                CircleShape
                            )
                            .clickable { colorHex = hex }
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                if (!isNetwork) Text(
                    text = if (isMine) "المُرسِل: أنا" else "المُرسِل: الطرف الآخر",
                    fontSize = 12.sp,
                    color = RiwaqBlue,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { isMine = !isMine }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("اكتب رسالة...", color = RiwaqTextMuted) },
                    modifier = Modifier.weight(1f),
                    maxLines = 4
                )
                IconButton(onClick = {
                    if (input.isNotBlank()) {
                        if (!isNetwork) {
                            viewModel.sendChatMessage(thread.id, input, colorHex, isMine)
                            input = ""
                        } else if (connected) {
                            viewModel.sendChatMessage(thread.id, input, colorHex, true)
                            viewModel.linkSend(colorHex, input.trim())
                            input = ""
                        } else {
                            Toast.makeText(ctx, "غير متصل بالجهاز الآخر", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "إرسال", tint = RiwaqBlue)
                }
            }
        }
    }
}
