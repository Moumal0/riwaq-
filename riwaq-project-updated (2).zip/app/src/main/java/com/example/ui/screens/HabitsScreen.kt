package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.HabitEntity
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqPriorityOrange
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun HabitsScreen(
    viewModel: RiwaqViewModel,
    modifier: Modifier = Modifier
) {
    val habits by viewModel.allHabits.collectAsStateWithLifecycle()
    val habitLogs by viewModel.allHabitLogs.collectAsStateWithLifecycle()

    val todayStr = remember { RiwaqViewModel.getTodayDateString() }
    val completedHabitIds = remember(habitLogs, todayStr) {
        habitLogs.filter { it.dateString == todayStr && it.isCompleted }.map { it.habitId }.toSet()
    }

    var expandedHabitId by remember { mutableStateOf<Long?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var habitToEdit by remember { mutableStateOf<HabitEntity?>(null) }
    var habitToDelete by remember { mutableStateOf<HabitEntity?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "العادات",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary
                    )
                }
            }

            if (habits.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "لا توجد عادات مسجلة",
                        subtitle = "اضغط على زر (+) في الأسفل لإنشاء عاداتك اليومية"
                    )
                }
            } else {
                items(habits, key = { "habit_${it.id}" }) { habit ->
                    val isDoneToday = completedHabitIds.contains(habit.id)
                    val isExpanded = expandedHabitId == habit.id

                    HabitItemCard(
                        habit = habit,
                        isDoneToday = isDoneToday,
                        isExpanded = isExpanded,
                        onToggleToday = { done -> viewModel.toggleHabitToday(habit.id, done) },
                        onCardClick = {
                            expandedHabitId = if (isExpanded) null else habit.id
                        },
                        onLongClick = { habitToEdit = habit },
                        onToggleDate = { dateStr, done ->
                            viewModel.toggleHabitDate(habit.id, dateStr, done)
                        },
                        onMoveUp = { viewModel.moveHabit(habit.id, up = true) },
                        onMoveDown = { viewModel.moveHabit(habit.id, up = false) },
                        allLogs = habitLogs.filter { it.habitId == habit.id }
                    )
                }

                // Habits progress chart
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                    HabitsProgressChart(habits = habits, habitLogs = habitLogs)
                }
            }
        }

        // Floating Action Button (+)
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
                .testTag("add_habit_fab"),
            containerColor = Color.White,
            contentColor = RiwaqBlue,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "إضافة عادة جديدة",
                modifier = Modifier.size(28.dp)
            )
        }

        // Add or Edit Dialog
        if (showAddDialog || habitToEdit != null) {
            HabitFormDialog(
                initialHabit = habitToEdit,
                onDismiss = {
                    showAddDialog = false
                    habitToEdit = null
                },
                onSave = { title, isEveryDay, days, time ->
                    if (habitToEdit != null) {
                        viewModel.updateHabit(
                            habitToEdit!!.copy(
                                title = title,
                                isEveryDay = isEveryDay,
                                targetDays = days,
                                habitTime = time
                            )
                        )
                    } else {
                        viewModel.addHabit(title, isEveryDay, days, time)
                    }
                    showAddDialog = false
                    habitToEdit = null
                },
                onDelete = {
                    habitToDelete = habitToEdit
                    habitToEdit = null
                    showAddDialog = false
                }
            )
        }

        // Delete Confirmation Dialog
        if (habitToDelete != null) {
            AlertDialog(
                onDismissRequest = { habitToDelete = null },
                title = { Text("حذف العادة") },
                text = { Text("هل أنت متأكد من رغبتك في حذف عادة '${habitToDelete?.title}' وسجلاتها؟") },
                confirmButton = {
                    TextButton(onClick = {
                        habitToDelete?.let { viewModel.deleteHabit(it) }
                        habitToDelete = null
                    }) {
                        Text("حذف", color = RiwaqPriorityRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { habitToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun HabitItemCard(
    habit: HabitEntity,
    isDoneToday: Boolean,
    isExpanded: Boolean,
    onToggleToday: (Boolean) -> Unit,
    onCardClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleDate: (String, Boolean) -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    allLogs: List<com.example.data.model.HabitLogEntity>
) {
    val completedDates = remember(allLogs) {
        allLogs.filter { it.isCompleted }.map { it.dateString }.toSet()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = onCardClick,
                onLongClick = onLongClick
            )
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left check/cross actions
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { onToggleToday(false) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إلغاء",
                            tint = if (!isDoneToday) RiwaqPriorityRed else Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = { onToggleToday(true) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "إنجاز",
                            tint = if (isDoneToday) RiwaqPriorityGreen else Color.LightGray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Title and drag/expand icon
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = habit.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = RiwaqTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = onMoveUp, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowUp,
                            contentDescription = "تحريك لأعلى",
                            tint = RiwaqTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = onMoveDown, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "تحريك لأسفل",
                            tint = RiwaqTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Expanded Tracker View (Matching Screenshot 3)
            if (isExpanded) {
                Spacer(modifier = Modifier.height(14.dp))

                HabitMonthCalendar(
                    completedDates = completedDates,
                    createdAtMillis = habit.createdAtMillis,
                    onToggleDate = onToggleDate
                )
                Spacer(modifier = Modifier.height(14.dp))

                // Streak indicators (Calculated dynamically from real completion logs)
                val streak7 = calculateRecentStreak(completedDates, 7)
                val streak14 = calculateRecentStreak(completedDates, 14)
                val progress7 = (streak7.toFloat() / 7f).coerceIn(0f, 1f)
                val progress14 = (streak14.toFloat() / 14f).coerceIn(0f, 1f)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // 14D Streak Bar
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$streak14/14D",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RiwaqPriorityOrange
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .width(60.dp)
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFFF1F5F9))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(progress14)
                                        .height(5.dp)
                                        .background(RiwaqPriorityOrange, RoundedCornerShape(3.dp))
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        // 7D Streak Bar
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$streak7/7D",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RiwaqPriorityOrange
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .width(60.dp)
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFFF1F5F9))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(progress7)
                                        .height(5.dp)
                                        .background(RiwaqPriorityOrange, RoundedCornerShape(3.dp))
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2 Weeks x 7 Days Grid
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val dayFormat = SimpleDateFormat("EE", Locale("ar"))
                val cal = Calendar.getInstance()

                // Generate last 14 days
                val pastDays = (0..13).map { i ->
                    val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
                    sdf.format(c.time)
                }.reversed()

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    pastDays.chunked(7).forEach { weekDays ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            weekDays.forEach { dateStr ->
                                val isChecked = completedDates.contains(dateStr)
                                val isToday = dateStr == RiwaqViewModel.getTodayDateString()

                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when {
                                                isChecked -> RiwaqPriorityGreen
                                                isToday -> Color(0xFFE2E8F0)
                                                else -> Color(0xFFF1F5F9)
                                            }
                                        )
                                        .clickable {
                                            onToggleDate(dateStr, !isChecked)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isChecked) Icons.Default.Check else Icons.Default.Close,
                                        contentDescription = null,
                                        tint = if (isChecked) Color.White else Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "اضغط على أي يوم لتبديل حالة الإنجاز",
                    fontSize = 11.sp,
                    color = RiwaqTextMuted,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

private fun calculateRecentStreak(completedDates: Set<String>, daysWindow: Int): Int {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    var count = 0
    for (i in 0 until daysWindow) {
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
        val dateStr = sdf.format(c.time)
        if (completedDates.contains(dateStr)) {
            count++
        }
    }
    return count
}

@Composable
private fun HabitsProgressChart(
    habits: List<HabitEntity>,
    habitLogs: List<com.example.data.model.HabitLogEntity>
) {
    val activeHabitIds = remember(habits) { habits.map { it.id }.toSet() }

    // Compute last 7 days metrics
    val chartDays = remember(habits, habitLogs) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dayNameFormat = SimpleDateFormat("E", Locale("ar"))
        val list = mutableListOf<Triple<String, String, Float>>() // dateStr, label, rate

        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val dateStr = sdf.format(cal.time)
            val label = if (i == 0) "اليوم" else dayNameFormat.format(cal.time)

            val doneCount = if (activeHabitIds.isNotEmpty()) {
                habitLogs.count { it.habitId in activeHabitIds && it.dateString == dateStr && it.isCompleted }
            } else 0

            val rate = if (activeHabitIds.isNotEmpty()) {
                (doneCount.toFloat() / activeHabitIds.size.toFloat()).coerceIn(0f, 1f)
            } else 0f

            list.add(Triple(dateStr, label, rate))
        }
        list
    }

    val todayRate = (chartDays.lastOrNull()?.third ?: 0f) * 100f

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (habits.isNotEmpty()) {
                Text(
                    text = "اليوم: ${todayRate.toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = RiwaqBlue
                )
            } else {
                Spacer(modifier = Modifier.width(1.dp))
            }

            Text(
                text = "منحنى الالتزام والنشاط (آخر 7 أيام)",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = RiwaqTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (habits.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "أضف عاداتك لتبدأ بمتابعة منحنى التزامك اليومي الحقيقي.",
                    fontSize = 13.sp,
                    color = RiwaqTextMuted
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val paddingX = 24.dp.toPx()
                    val chartWidth = w - (paddingX * 2)

                    // Draw subtle horizontal grid lines (0%, 50%, 100%)
                    for (i in 0..2) {
                        val y = (h - 24.dp.toPx()) * (i / 2f) + 8.dp.toPx()
                        drawLine(
                            color = Color(0xFFF1F5F9),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    // Compute points coordinates
                    val points = chartDays.mapIndexed { index, item ->
                        val x = paddingX + (index.toFloat() / (chartDays.size - 1).toFloat()) * chartWidth
                        // Rate 1.0f at top (8dp), 0.0f at bottom (h - 24dp)
                        val topY = 12.dp.toPx()
                        val bottomY = h - 26.dp.toPx()
                        val y = bottomY - (item.third * (bottomY - topY))
                        Offset(x, y)
                    }

                    if (points.isNotEmpty()) {
                        // Smooth cubic curve path
                        val path = Path()
                        val fillPath = Path()

                        path.moveTo(points[0].x, points[0].y)
                        fillPath.moveTo(points[0].x, points[0].y)

                        for (i in 1 until points.size) {
                            val prev = points[i - 1]
                            val curr = points[i]
                            val cx = (prev.x + curr.x) / 2f
                            path.cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
                            fillPath.cubicTo(cx, prev.y, cx, curr.y, curr.x, curr.y)
                        }

                        // Close fill path
                        fillPath.lineTo(points.last().x, h - 24.dp.toPx())
                        fillPath.lineTo(points.first().x, h - 24.dp.toPx())
                        fillPath.close()

                        // Draw soft gradient under curve
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    RiwaqBlue.copy(alpha = 0.18f),
                                    RiwaqBlue.copy(alpha = 0.02f)
                                )
                            )
                        )

                        // Draw stroke
                        drawPath(
                            path = path,
                            color = RiwaqBlue,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Draw data point circles
                        points.forEachIndexed { idx, pt ->
                            val isTodayPoint = (idx == points.size - 1)
                            if (isTodayPoint) {
                                drawCircle(color = Color.White, radius = 6.dp.toPx(), center = pt)
                                drawCircle(color = RiwaqBlue, radius = 5.dp.toPx(), center = pt)
                            } else {
                                drawCircle(color = RiwaqBlue, radius = 3.5.dp.toPx(), center = pt)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // X-axis day labels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                chartDays.forEach { (_, label, _) ->
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (label == "اليوم") FontWeight.Bold else FontWeight.Normal,
                        color = if (label == "اليوم") RiwaqBlue else RiwaqTextMuted
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HabitFormDialog(
    initialHabit: HabitEntity?,
    onDismiss: () -> Unit,
    onSave: (title: String, isEveryDay: Boolean, targetDays: String, time: String) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember { mutableStateOf(initialHabit?.title ?: "") }
    var isEveryDay by remember { mutableStateOf(initialHabit?.isEveryDay ?: true) }
    var habitTime by remember { mutableStateOf(initialHabit?.habitTime ?: "15 min") }

    val daysList = remember { listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الاربعاء", "الخميس", "الجمعة") }
    val selectedDays = remember {
        val initialIndices = initialHabit?.targetDays?.split(",")?.mapNotNull { it.toIntOrNull() } ?: listOf(0, 1, 2, 3, 4, 5, 6)
        mutableStateListOf<Int>().apply { addAll(initialIndices) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White)
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top Action buttons (Close / Save)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إلغاء", tint = RiwaqPriorityRed)
                        }
                        IconButton(
                            onClick = {
                                if (title.isNotBlank()) {
                                    val daysStr = selectedDays.joinToString(",")
                                    onSave(title, isEveryDay, daysStr, habitTime)
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "حفظ", tint = RiwaqPriorityGreen)
                        }
                    }

                    Text(
                        text = if (initialHabit == null) "اكتب العادة" else "تعديل العادة",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary
                    )
                }

                // Title Input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("مثال: قراءة 15 صفحة يومياً") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("habit_title_input"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                // Frequency selection (Matching Screenshot 4)
                Text(
                    text = "تحديد الايام",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = RiwaqTextPrimary,
                    modifier = Modifier.align(Alignment.End)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    FilterChip(
                        selected = !isEveryDay,
                        onClick = { isEveryDay = false },
                        label = { Text("ايام محددة") },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    FilterChip(
                        selected = isEveryDay,
                        onClick = { isEveryDay = true },
                        label = { Text("كل يوم") }
                    )
                }

                if (!isEveryDay) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        daysList.forEachIndexed { index, dayName ->
                            val isSelected = selectedDays.contains(index)
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 3.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) RiwaqBlue else Color(0xFFF1F5F9))
                                    .clickable {
                                        if (isSelected) selectedDays.remove(index) else selectedDays.add(index)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = dayName,
                                    fontSize = 12.sp,
                                    color = if (isSelected) Color.White else RiwaqTextPrimary
                                )
                            }
                        }
                    }
                }

                // Habit time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF1F5F9))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = habitTime, fontSize = 13.sp, color = RiwaqTextPrimary)
                    }
                    Text(
                        text = "وقت العادة",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = RiwaqTextPrimary
                    )
                }

                if (initialHabit != null) {
                    TextButton(
                        onClick = onDelete,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = RiwaqPriorityRed)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حذف هذه العادة", color = RiwaqPriorityRed)
                    }
                }
            }
        }
    }
}
