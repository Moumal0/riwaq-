package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HabitEntity
import com.example.data.model.HabitLogEntity
import com.example.data.model.SportPlanItemEntity
import com.example.data.model.SportPlanLogEntity
import com.example.data.model.TaskEntity
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqPriorityOrange
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.GregorianCalendar
import java.util.Locale

private val SeasonLabels = listOf("Jan–Feb", "Mar–Apr", "May–Jun", "Jul–Aug", "Sep–Oct", "Nov–Dec")

private data class SeasonStats(
    val percent: Int,
    val completed: Int,
    val expected: Int,
    val perHabit: List<Pair<String, Int>>,
    val days: List<Float?>
)

/** فصل = شهران ميلاديان. season: 0..5 */
private fun computeSeason(
    habits: List<HabitEntity>,
    logs: List<HabitLogEntity>,
    year: Int,
    season: Int
): SeasonStats {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val todayStr = sdf.format(Calendar.getInstance().time)
    val startMonth = season * 2
    val endMonth = startMonth + 1
    val cursor = GregorianCalendar(year, startMonth, 1)
    val lastDay = GregorianCalendar(year, endMonth, 1).getActualMaximum(Calendar.DAY_OF_MONTH)
    val end = GregorianCalendar(year, endMonth, lastDay)

    val done = HashSet<String>()
    logs.filter { it.isCompleted }.forEach { done.add("${it.habitId}|${it.dateString}") }

    val expectedBy = HashMap<Long, Int>()
    val completedBy = HashMap<Long, Int>()
    val dayFractions = mutableListOf<Float?>()
    var totalExpected = 0
    var totalDone = 0

    while (!cursor.after(end)) {
        val ds = sdf.format(cursor.time)
        if (ds > todayStr) {
            dayFractions.add(null)
        } else {
            val dayIdx = cursor.get(Calendar.DAY_OF_WEEK) % 7 // 0 = السبت
            val dayEnd = cursor.timeInMillis + 86_400_000L
            val scheduled = habits.filter { h ->
                h.createdAtMillis <= dayEnd &&
                    (h.isEveryDay || h.targetDays.split(",").any { it.trim() == dayIdx.toString() })
            }
            if (scheduled.isEmpty()) {
                dayFractions.add(null)
            } else {
                var d = 0
                scheduled.forEach { h ->
                    expectedBy[h.id] = (expectedBy[h.id] ?: 0) + 1
                    if (done.contains("${h.id}|$ds")) {
                        d++
                        completedBy[h.id] = (completedBy[h.id] ?: 0) + 1
                    }
                }
                totalExpected += scheduled.size
                totalDone += d
                dayFractions.add(d.toFloat() / scheduled.size)
            }
        }
        cursor.add(Calendar.DAY_OF_MONTH, 1)
    }

    val perHabit = habits.mapNotNull { h ->
        val e = expectedBy[h.id] ?: 0
        if (e == 0) null else h.title to ((completedBy[h.id] ?: 0) * 100 / e)
    }.sortedByDescending { it.second }

    val pct = if (totalExpected == 0) 0 else totalDone * 100 / totalExpected
    return SeasonStats(pct, totalDone, totalExpected, perHabit, dayFractions)
}

/** السنة مقسمة إلى 6 فصول، كل فصل شهران: التزامك، أفضل/أضعف عادة، ومقارنة بالفصل السابق. */
@Composable
fun HabitSeasonsSection(
    habits: List<HabitEntity>,
    logs: List<HabitLogEntity>,
    modifier: Modifier = Modifier,
    tasks: List<TaskEntity> = emptyList(),
    sportItems: List<SportPlanItemEntity> = emptyList(),
    sportLogs: List<SportPlanLogEntity> = emptyList()
) {
    val now = remember { Calendar.getInstance() }
    var year by remember { mutableIntStateOf(now.get(Calendar.YEAR)) }
    var season by remember { mutableIntStateOf(now.get(Calendar.MONTH) / 2) }

    // الجدول الرياضي يُعامل كعادات أسبوعية في حساب الفصل (معرّفات سالبة لتفادي التعارض)
    val allHabits = remember(habits, sportItems) {
        habits + sportItems.filter { it.exerciseKey != "REST" }.map {
            HabitEntity(
                id = -it.id,
                title = "🏋️ " + (findExercise(it.exerciseKey)?.ar ?: it.exerciseKey),
                isEveryDay = false,
                targetDays = it.dayIndex.toString(),
                createdAtMillis = it.createdAtMillis
            )
        }
    }
    val allLogs = remember(logs, sportLogs) {
        logs + sportLogs.map { HabitLogEntity(habitId = -it.itemId, dateString = it.dateString, isCompleted = true) }
    }
    val stats = remember(allHabits, allLogs, year, season) { computeSeason(allHabits, allLogs, year, season) }
    val prevStats = remember(allHabits, allLogs, year, season) {
        if (season > 0) computeSeason(allHabits, allLogs, year, season - 1)
        else computeSeason(allHabits, allLogs, year - 1, 5)
    }
    val seasonTasks = remember(tasks, year, season) {
        val start = GregorianCalendar(year, season * 2, 1).timeInMillis
        val endCal = GregorianCalendar(year, season * 2 + 2, 1)
        val end = endCal.timeInMillis
        tasks.filter { it.dueDateMillis in start until end }
    }
    val tasksDone = seasonTasks.count { it.isCompleted }
    val delta = stats.percent - prevStats.percent

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "‹", fontSize = 22.sp, color = RiwaqBlue,
                    modifier = Modifier.clickable { year -= 1 }.padding(horizontal = 8.dp)
                )
                Text(text = "$year", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
                Text(
                    text = "›", fontSize = 22.sp, color = RiwaqBlue,
                    modifier = Modifier.clickable { year += 1 }.padding(horizontal = 8.dp)
                )
            }
            Text(text = "فصول السنة", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(SeasonLabels) { i, label ->
                val sel = i == season
                Text(
                    text = "${i + 1} · $label",
                    fontSize = 12.sp,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    color = if (sel) Color.White else RiwaqTextPrimary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (sel) RiwaqBlue else Color(0xFFF1F5F9))
                        .clickable { season = i }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }

        // نسبة الالتزام
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "${stats.percent}%", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = RiwaqBlue)
                Text(text = "الالتزام: ${stats.completed} من ${stats.expected}", fontSize = 12.sp, color = RiwaqTextSecondary)
            }
            if (stats.expected > 0 && prevStats.expected > 0) {
                val up = delta >= 0
                Text(
                    text = (if (up) "▲ +" else "▼ ") + "$delta% عن الفصل السابق",
                    fontSize = 12.sp,
                    color = if (up) RiwaqPriorityGreen else RiwaqPriorityOrange
                )
            }
        }

        // خريطة الأيام
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            stats.days.chunked(10).forEach { rowDays ->
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rowDays.forEach { f ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    if (f == null) Color(0xFFF1F5F9)
                                    else RiwaqBlue.copy(alpha = 0.15f + 0.85f * f)
                                )
                        )
                    }
                    repeat(10 - rowDays.size) { Spacer(modifier = Modifier.weight(1f)) }
                }
            }
        }

        // المهام المنجزة في الفصل
        if (seasonTasks.isNotEmpty()) {
            Text(
                text = "المهام المنجزة: $tasksDone من ${seasonTasks.size} (${tasksDone * 100 / seasonTasks.size}%)",
                fontSize = 12.sp,
                color = RiwaqTextSecondary
            )
        }

        // أفضل وأضعف عادة
        if (stats.perHabit.isNotEmpty()) {
            val best = stats.perHabit.first()
            val worst = stats.perHabit.last()
            Text(text = "الأفضل: ${best.first} (${best.second}%)", fontSize = 12.sp, color = RiwaqPriorityGreen)
            if (stats.perHabit.size > 1) {
                Text(text = "تحتاج اهتماماً: ${worst.first} (${worst.second}%)", fontSize = 12.sp, color = RiwaqPriorityOrange)
            }
            Spacer(modifier = Modifier.height(2.dp))
            stats.perHabit.forEach { (title, pct) ->
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "$pct%", fontSize = 12.sp, color = RiwaqTextSecondary)
                        Text(text = title, fontSize = 13.sp, color = RiwaqTextPrimary)
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFFE2E8F0))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(pct.coerceIn(0, 100) / 100f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(RiwaqBlue)
                        )
                    }
                }
            }
        } else {
            Text(text = "لا توجد بيانات في هذا الفصل بعد", fontSize = 12.sp, color = RiwaqTextMuted)
        }
    }
}
