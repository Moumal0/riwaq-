package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.TextButton
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RiwaqViewModel
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary

/** مؤقت بومودورو: يستمر بالعمل أثناء التنقل بين الشاشات لأن حالته في الـ ViewModel. */
@Composable
fun PomodoroPanel(viewModel: RiwaqViewModel, modifier: Modifier = Modifier) {
    val p by viewModel.pomodoro.collectAsStateWithLifecycle()
    val total = (if (p.isBreak) p.breakMin else p.workMin) * 60
    val progress = if (total > 0) 1f - p.remainingSec.toFloat() / total.toFloat() else 0f
    val accent = if (p.isBreak) RiwaqPriorityGreen else RiwaqBlue
    val mm = p.remainingSec / 60
    val ss = p.remainingSec % 60
    val ctx = LocalContext.current
    var pinned by remember { mutableStateOf(ctx.isAppPinned()) }
    var pinRefresh by remember { mutableStateOf(0) }
    var showUltra by remember { mutableStateOf(false) }
    LaunchedEffect(pinRefresh) {
        delay(700)
        pinned = ctx.isAppPinned()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(androidx.compose.foundation.rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = if (p.isBreak) "استراحة" else "تركيز",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = accent
        )
        Spacer(modifier = Modifier.height(16.dp))

        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(240.dp)) {
            CircularProgressIndicator(
                progress = { 1f },
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFFE2E8F0),
                strokeWidth = 10.dp
            )
            CircularProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxSize(),
                color = accent,
                strokeWidth = 10.dp
            )
            Text(
                text = "%02d:%02d".format(mm, ss),
                fontSize = 48.sp,
                fontWeight = FontWeight.Bold,
                color = RiwaqTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { viewModel.pomodoroReset() }) {
                Icon(Icons.Default.Refresh, contentDescription = "إعادة", tint = RiwaqTextSecondary)
            }
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = { viewModel.pomodoroToggle() }) {
                    Icon(
                        if (p.isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (p.isRunning) "إيقاف مؤقت" else "ابدأ",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text(text = "جلسات التركيز المكتملة: ${p.sessionsDone}", fontSize = 14.sp, color = RiwaqTextSecondary)

        Spacer(modifier = Modifier.height(16.dp))
        DurationStepper(
            label = "مدة التركيز",
            minutes = p.workMin,
            enabled = !p.isRunning,
            onMinus = { viewModel.pomodoroSetDurations(p.workMin - 5, p.breakMin) },
            onPlus = { viewModel.pomodoroSetDurations(p.workMin + 5, p.breakMin) }
        )
        DurationStepper(
            label = "مدة الاستراحة",
            minutes = p.breakMin,
            enabled = !p.isRunning,
            onMinus = { viewModel.pomodoroSetDurations(p.workMin, p.breakMin - 1) },
            onPlus = { viewModel.pomodoroSetDurations(p.workMin, p.breakMin + 1) }
        )

        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                if (pinned) ctx.unpinApp() else ctx.pinApp()
                pinRefresh++
            }) {
                Text(if (pinned) "إيقاف وضع التركيز" else "وضع التركيز", color = RiwaqBlue)
            }
            TextButton(onClick = {
                ctx.pinApp()
                pinRefresh++
                if (!p.isRunning) viewModel.pomodoroToggle()
                showUltra = true
            }) { Text("التركيز الفائق", color = RiwaqBlue, fontWeight = FontWeight.Bold) }
        }
        Text(
            text = "وضع التركيز يستخدم «تثبيت التطبيق» في أندرويد (فعّله من الإعدادات > الأمان). للخروج: اضغط مطولاً على زرّي الرجوع والتطبيقات الأخيرة معاً.",
            fontSize = 11.sp,
            color = RiwaqTextMuted
        )

        Spacer(modifier = Modifier.height(16.dp))
        DistractionTracker()
    }

    if (showUltra) {
        UltraFocusDialog(viewModel = viewModel, onExit = { showUltra = false; pinRefresh++ })
    }
}

@Composable
private fun DurationStepper(
    label: String,
    minutes: Int,
    enabled: Boolean,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconButton(onClick = onMinus, enabled = enabled) {
            Icon(Icons.Default.Remove, contentDescription = "إنقاص", tint = if (enabled) RiwaqBlue else RiwaqTextMuted)
        }
        Text(text = "$label: $minutes د", fontSize = 14.sp, color = RiwaqTextPrimary)
        IconButton(onClick = onPlus, enabled = enabled) {
            Icon(Icons.Default.Add, contentDescription = "زيادة", tint = if (enabled) RiwaqBlue else RiwaqTextMuted)
        }
    }
}

/** قسم التشتت: عدّاد بسيط لمرات الانشغال عن المهمة اليوم مع سجل آخر 7 أيام. */
@Composable
private fun DistractionTracker() {
    val ctx = LocalContext.current
    val prefs = androidx.compose.runtime.remember {
        ctx.getSharedPreferences("riwaq_distraction", android.content.Context.MODE_PRIVATE)
    }
    val fmt = androidx.compose.runtime.remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US) }
    val today = fmt.format(java.util.Date())
    var todayCount by androidx.compose.runtime.remember { mutableStateOf(prefs.getInt("d_$today", 0)) }
    val history = androidx.compose.runtime.remember(todayCount) {
        (0..6).map { off ->
            val c = java.util.Calendar.getInstance()
            c.add(java.util.Calendar.DAY_OF_YEAR, -off)
            val key = fmt.format(c.time)
            key.substring(5) to prefs.getInt("d_$key", 0)
        }
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
            .background(Color.White)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("التشتت", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
        Text("سجّل كل مرة انشغلت فيها عن مهمتك لتعرف نمطك.", fontSize = 12.sp, color = RiwaqTextSecondary)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("اليوم: $todayCount", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = RiwaqBlue)
            TextButton(onClick = {
                todayCount += 1
                prefs.edit().putInt("d_$today", todayCount).apply()
            }) { Text("+ تشتّتُّ الآن", color = RiwaqBlue) }
            TextButton(onClick = {
                todayCount = 0
                prefs.edit().putInt("d_$today", 0).apply()
            }) { Text("تصفير", color = RiwaqTextMuted) }
        }
        Text(
            history.joinToString("  ·  ") { "${it.first}: ${it.second}" },
            fontSize = 11.sp, color = RiwaqTextMuted
        )
    }
}
