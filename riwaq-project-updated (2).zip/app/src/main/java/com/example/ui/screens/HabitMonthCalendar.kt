package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.GregorianCalendar
import java.util.Locale

/**
 * تقويم شهري للعادة: الأيام المنجزة بالأخضر مع علامة ✓، والفائتة بالأحمر مع ✕،
 * والمستقبلية رمادية. الضغط على يوم ماضٍ أو اليوم يبدّل حالته.
 */
@Composable
fun HabitMonthCalendar(
    completedDates: Set<String>,
    createdAtMillis: Long,
    onToggleDate: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val now = remember { Calendar.getInstance() }
    var monthOffset by remember { mutableIntStateOf(0) }
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val todayStr = remember { sdf.format(now.time) }

    val first = GregorianCalendar(now.get(Calendar.YEAR), now.get(Calendar.MONTH), 1).apply {
        add(Calendar.MONTH, monthOffset)
    }
    val title = SimpleDateFormat("MMM yyyy", Locale.US).format(first.time)
    val daysInMonth = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val lead = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7 // الاثنين = 0
    val createdDayStr = sdf.format(java.util.Date(createdAtMillis))

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { monthOffset -= 1 }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "الشهر السابق", tint = RiwaqTextPrimary)
                }
                Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = RiwaqTextPrimary)
                IconButton(
                    onClick = { if (monthOffset < 0) monthOffset += 1 },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        Icons.Default.KeyboardArrowRight,
                        contentDescription = "الشهر التالي",
                        tint = if (monthOffset < 0) RiwaqTextPrimary else Color.LightGray
                    )
                }
            }

            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { d ->
                    Text(
                        text = d,
                        modifier = Modifier.weight(1f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            val totalCells = lead + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (c in 0 until 7) {
                        val day = r * 7 + c - lead + 1
                        if (day < 1 || day > daysInMonth) {
                            Spacer(modifier = Modifier.weight(1f))
                        } else {
                            val cell = (first.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, day) }
                            val ds = sdf.format(cell.time)
                            val done = completedDates.contains(ds)
                            val future = ds > todayStr
                            val beforeStart = ds < createdDayStr && !done
                            val bg = when {
                                done -> Color(0xFFDCEBDD)
                                future || beforeStart -> Color(0xFFF5F5F7)
                                else -> Color(0xFFFCE9EC)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bg)
                                    .clickable(enabled = !future) { onToggleDate(ds, !done) }
                                    .padding(3.dp)
                            ) {
                                when {
                                    done -> Icon(
                                        Icons.Default.Check, contentDescription = null,
                                        tint = RiwaqPriorityGreen,
                                        modifier = Modifier.align(Alignment.Center).size(18.dp)
                                    )
                                    future || beforeStart -> {}
                                    else -> Icon(
                                        Icons.Default.Close, contentDescription = null,
                                        tint = RiwaqPriorityRed,
                                        modifier = Modifier.align(Alignment.Center).size(18.dp)
                                    )
                                }
                                Text(
                                    text = "$day",
                                    fontSize = 9.sp,
                                    color = if (ds == todayStr) RiwaqBlue else RiwaqTextMuted,
                                    fontWeight = if (ds == todayStr) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.align(Alignment.BottomEnd)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
