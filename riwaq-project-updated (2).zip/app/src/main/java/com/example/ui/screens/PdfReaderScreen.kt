package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RiwaqViewModel
import com.example.ui.theme.RiwaqBlue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/** جلسة قراءة PDF: تفتح الملف مرة واحدة وتصيّر الصفحات عند الطلب. */
private class PdfSession private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer
) {
    val pageCount: Int = renderer.pageCount
    private val mutex = Mutex()
    @Volatile private var closed = false

    suspend fun render(index: Int, targetWidth: Int): Bitmap? = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (closed) return@withLock null
            try {
                renderer.openPage(index).use { page ->
                    val ratio = page.height.toFloat() / page.width.toFloat()
                    val h = (targetWidth * ratio).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(targetWidth, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            } catch (_: Throwable) {
                null
            }
        }
    }

    fun close() {
        closed = true
        try { renderer.close() } catch (_: Throwable) {}
        try { pfd.close() } catch (_: Throwable) {}
    }

    companion object {
        fun open(file: File): PdfSession? = try {
            if (!file.exists()) null
            else {
                val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                PdfSession(pfd, PdfRenderer(pfd))
            }
        } catch (_: Throwable) {
            null
        }
    }
}

private fun loadBookmarks(prefs: SharedPreferences, bookId: Long): List<Int> =
    (prefs.getStringSet("bm_$bookId", emptySet()) ?: emptySet())
        .mapNotNull { it.toIntOrNull() }
        .sorted()

private fun saveBookmarks(prefs: SharedPreferences, bookId: Long, pages: List<Int>) {
    prefs.edit().putStringSet("bm_$bookId", pages.map { it.toString() }.toSet()).apply()
}

private val InvertFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

@Composable
fun PdfReaderScreen(
    bookId: Long,
    viewModel: RiwaqViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val books by viewModel.allBooks.collectAsStateWithLifecycle()
    val book = remember(books, bookId) { books.find { it.id == bookId } }
    val context = LocalContext.current
    val view = LocalView.current
    val prefs = remember { context.getSharedPreferences("riwaq_reader", Context.MODE_PRIVATE) }

    var showBars by remember { mutableStateOf(true) }
    var night by remember { mutableStateOf(prefs.getBoolean("night", false)) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pinch by remember { mutableFloatStateOf(1f) }
    var bookmarks by remember(bookId) { mutableStateOf(loadBookmarks(prefs, bookId)) }
    var showBookmarksDialog by remember { mutableStateOf(false) }
    var showJumpDialog by remember { mutableStateOf(false) }
    var jumpInput by remember { mutableStateOf("") }
    var pendingJump by remember { mutableStateOf<Int?>(null) }

    val path = book?.internalPdfPath
    val session = remember(path) { path?.let { PdfSession.open(File(it)) } }
    DisposableEffect(session) { onDispose { session?.close() } }

    val listState = rememberLazyListState()
    val pageCount = session?.pageCount ?: 0
    val currentPage by remember { derivedStateOf { listState.firstVisibleItemIndex } }

    // استعادة آخر صفحة ثم متابعة حفظ التقدم
    LaunchedEffect(session) {
        if (session != null) {
            val start = (book?.currentPage ?: 0).coerceIn(0, (session.pageCount - 1).coerceAtLeast(0))
            listState.scrollToItem(start)
            snapshotFlow { listState.firstVisibleItemIndex }.collect { viewModel.updateBookProgress(bookId, it) }
        }
    }

    // وضع الاستغراق: إخفاء أشرطة النظام عند إخفاء أشرطة القارئ
    val window = (view.context as? Activity)?.window
    DisposableEffect(showBars) {
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            if (showBars) {
                controller.show(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {}
    }
    DisposableEffect(Unit) {
        onDispose {
            if (window != null) {
                WindowCompat.getInsetsController(window, view).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    BackHandler { onBack() }

    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val density = LocalDensity.current.density
    val pageWidthPx = (screenWidthDp * density * zoom).toInt().coerceIn(200, 2000)
    val cache = remember { LruCache<String, Bitmap>(3) }
    val pageBg = if (night) Color(0xFF111111) else Color(0xFFE5E7EB)

    Box(modifier = modifier.fillMaxSize().background(pageBg)) {
        if (session == null) {
            Text(
                text = "تعذّر فتح ملف الكتاب",
                color = if (night) Color.White else Color.Red,
                fontSize = 14.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .horizontalScroll(rememberScrollState())
                    .pointerInput(Unit) { detectTapGestures(onTap = { showBars = !showBars }) }
                    .pointerInput(Unit) {
                        // قرص بإصبعين: تكبير سلس (تحجيم مباشر أثناء الإيماءة ثم إعادة التصيير بجودة أعلى)
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            var multi = false
                            do {
                                val event = awaitPointerEvent(PointerEventPass.Initial)
                                if (event.changes.count { it.pressed } >= 2) {
                                    multi = true
                                    val z = event.calculateZoom()
                                    if (z != 1f) pinch = (pinch * z).coerceIn(1f / zoom, 3f / zoom)
                                    event.changes.forEach { it.consume() }
                                }
                            } while (event.changes.any { it.pressed })
                            if (multi) {
                                zoom = (zoom * pinch).coerceIn(1f, 3f)
                                pinch = 1f
                            }
                        }
                    }
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .width((screenWidthDp * zoom).dp)
                        .graphicsLayer {
                            scaleX = pinch
                            scaleY = pinch
                            transformOrigin = TransformOrigin(0.5f, 0f)
                        },
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(count = pageCount, key = { it }) { index ->
                        PdfPageItem(
                            session = session,
                            index = index,
                            widthPx = pageWidthPx,
                            night = night,
                            cache = cache
                        )
                    }
                }
            }
        }

        if (showBars) {
            // الشريط العلوي
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(Color(0xE6FFFFFF))
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = Color(0xFF1E293B))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = book?.title ?: "قارئ الكتب",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    val pct = if (pageCount > 0) ((currentPage + 1) * 100 / pageCount) else 0
                    Text(
                        text = "صفحة ${currentPage + 1} من $pageCount  ($pct%)",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        modifier = Modifier.clickable { jumpInput = ""; showJumpDialog = true }
                    )
                }
                IconButton(onClick = { zoom = (zoom - 0.25f).coerceAtLeast(1f) }) {
                    Icon(Icons.Default.Remove, contentDescription = "تصغير", tint = RiwaqBlue)
                }
                IconButton(onClick = { zoom = (zoom + 0.25f).coerceAtMost(3f) }) {
                    Icon(Icons.Default.Add, contentDescription = "تكبير", tint = RiwaqBlue)
                }
                IconButton(onClick = {
                    night = !night
                    prefs.edit().putBoolean("night", night).apply()
                }) {
                    Icon(
                        if (night) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "الوضع الليلي",
                        tint = RiwaqBlue
                    )
                }
                IconButton(onClick = {
                    val p = currentPage
                    bookmarks = if (bookmarks.contains(p)) bookmarks - p else (bookmarks + p).sorted()
                    saveBookmarks(prefs, bookId, bookmarks)
                }) {
                    Icon(
                        if (bookmarks.contains(currentPage)) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "علامة مرجعية",
                        tint = RiwaqBlue
                    )
                }
                IconButton(onClick = { showBookmarksDialog = true }) {
                    Icon(Icons.Default.Bookmarks, contentDescription = "العلامات", tint = RiwaqBlue)
                }
            }

            // الشريط السفلي: منزلق الصفحات
            if (pageCount > 1) {
                var sliderValue by remember { mutableFloatStateOf(0f) }
                var dragging by remember { mutableStateOf(false) }
                val shown = if (dragging) sliderValue else currentPage.toFloat()
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color(0xE6FFFFFF))
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = shown,
                        onValueChange = { sliderValue = it; dragging = true },
                        onValueChangeFinished = {
                            dragging = false
                            val target = sliderValue.toInt().coerceIn(0, pageCount - 1)
                            // الانتقال يتم عبر LaunchedEffect أدناه
                            pendingJump = target
                        },
                        valueRange = 0f..(pageCount - 1).toFloat(),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    // تنفيذ القفز إلى صفحة (من المنزلق أو الحوارات)
    LaunchedEffect(pendingJump) {
        val t = pendingJump
        if (t != null) {
            listState.scrollToItem(t.coerceIn(0, (pageCount - 1).coerceAtLeast(0)))
            pendingJump = null
        }
    }

    if (showJumpDialog) {
        AlertDialog(
            onDismissRequest = { showJumpDialog = false },
            title = { Text("الانتقال إلى صفحة") },
            text = {
                OutlinedTextField(
                    value = jumpInput,
                    onValueChange = { jumpInput = it.filter { c -> c.isDigit() } },
                    placeholder = { Text("1 - $pageCount") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    jumpInput.toIntOrNull()?.let { pendingJump = (it - 1).coerceIn(0, (pageCount - 1).coerceAtLeast(0)) }
                    showJumpDialog = false
                }) { Text("انتقال", color = RiwaqBlue) }
            },
            dismissButton = { TextButton(onClick = { showJumpDialog = false }) { Text("إلغاء") } }
        )
    }

    if (showBookmarksDialog) {
        AlertDialog(
            onDismissRequest = { showBookmarksDialog = false },
            title = { Text("العلامات المرجعية") },
            text = {
                if (bookmarks.isEmpty()) {
                    Text("لا توجد علامات. اضغط أيقونة العلامة لحفظ الصفحة الحالية.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        bookmarks.forEach { p ->
                            Text(
                                text = "صفحة ${p + 1}",
                                fontSize = 15.sp,
                                color = RiwaqBlue,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { pendingJump = p; showBookmarksDialog = false }
                                    .padding(vertical = 8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showBookmarksDialog = false }) { Text("إغلاق") } }
        )
    }
}

@Composable
private fun PdfPageItem(
    session: PdfSession,
    index: Int,
    widthPx: Int,
    night: Boolean,
    cache: LruCache<String, Bitmap>
) {
    val key = "$index@$widthPx"
    val bmp by produceState<Bitmap?>(initialValue = cache.get(key), key) {
        if (value == null) {
            val r = session.render(index, widthPx)
            if (r != null) {
                cache.put(key, r)
                value = r
            }
        }
    }
    var lastBmp by remember { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(bmp) { if (bmp != null) lastBmp = bmp }
    val b = bmp ?: lastBmp
    val ratio = if (b != null) b.height.toFloat() / b.width.toFloat() else 1.414f
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f / ratio)
            .background(if (night) Color(0xFF1A1A1A) else Color.White),
        contentAlignment = Alignment.Center
    ) {
        if (b == null) {
            CircularProgressIndicator(color = RiwaqBlue)
        } else {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "صفحة ${index + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                colorFilter = if (night) InvertFilter else null
            )
        }
    }
}
