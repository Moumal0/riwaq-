package com.example.ui.screens

import android.graphics.Color as AndroidColor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.rememberAsyncImagePainter
import com.example.data.model.CalendarEventEntity
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.FoxEmblem
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun CalendarScreen(
    viewModel: RiwaqViewModel,
    modifier: Modifier = Modifier
) {
    val events by viewModel.allCalendarEvents.collectAsStateWithLifecycle()
    val selectedDate by viewModel.selectedCalendarDate.collectAsStateWithLifecycle()
    val settings by viewModel.appSettings.collectAsStateWithLifecycle()

    val boxColor = remember(settings.calendarBoxColorHex) {
        try { Color(AndroidColor.parseColor(settings.calendarBoxColorHex)) } catch (_: Exception) { Color.White }
    }
    val headerColor = remember(settings.calendarHeaderColorHex) {
        try { Color(AndroidColor.parseColor(settings.calendarHeaderColorHex)) } catch (_: Exception) { RiwaqBlue }
    }
    val cellsColor = remember(settings.calendarCellsColorHex) {
        try { Color(AndroidColor.parseColor(settings.calendarCellsColorHex)) } catch (_: Exception) { Color(0xFFE8F0FE) }
    }
    val dividersColor = remember(settings.calendarDividersColorHex) {
        try { Color(AndroidColor.parseColor(settings.calendarDividersColorHex)) } catch (_: Exception) { RiwaqCardBorder }
    }
    val textColor = remember(settings.calendarTextColorHex) {
        try { Color(AndroidColor.parseColor(settings.calendarTextColorHex)) } catch (_: Exception) { Color(0xFF1E293B) }
    }
    val eventColor = remember(settings.calendarEventColorHex) {
        try { Color(AndroidColor.parseColor(settings.calendarEventColorHex)) } catch (_: Exception) { Color(0xFFE07A5F) }
    }

    val calendarImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.setCalendarCustomImage(uri)
        }
    }

    val currentYear by viewModel.calendarSelectedYear.collectAsStateWithLifecycle()
    val currentMonth by viewModel.calendarSelectedMonth.collectAsStateWithLifecycle()

    var showAddEventDialog by remember { mutableStateOf(false) }
    var eventToDelete by remember { mutableStateOf<CalendarEventEntity?>(null) }

    val monthEvents = remember(events, currentYear, currentMonth) {
        val monthPrefix = String.format(Locale.US, "%04d-%02d", currentYear, currentMonth + 1)
        events.filter { it.dateString.startsWith(monthPrefix) }
    }

    val selectedDayEvents = remember(events, selectedDate) {
        events.filter { it.dateString == selectedDate }
    }

    val monthName = remember(currentMonth, currentYear) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, currentYear)
            set(Calendar.MONTH, currentMonth)
        }
        SimpleDateFormat("MMMM", Locale.ENGLISH).format(cal.time)
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Calendar Header: Month + Fox Badge + Year + Navigation (Matching Screenshot 10)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        if (currentMonth == 0) {
                            viewModel.setCalendarMonthYear(currentYear - 1, 11)
                        } else {
                            viewModel.setCalendarMonthYear(currentYear, currentMonth - 1)
                        }
                    }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "الشهر السابق", tint = RiwaqBlue)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = monthName,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = RiwaqTextPrimary
                        )

                        // Central Fox / Custom Avatar Badge
                        val customImgPath = settings.calendarCustomImagePath
                        val hasCustomImg = customImgPath != null && File(customImgPath).exists()

                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE89F22))
                                .border(1.dp, dividersColor, CircleShape)
                                .clickable {
                                    calendarImagePicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (hasCustomImg) {
                                Image(
                                    painter = rememberAsyncImagePainter(File(customImgPath!!)),
                                    contentDescription = "صورة التقويم الدائرية",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                FoxEmblem(size = 38.dp)
                            }
                        }

                        Text(
                            text = "$currentYear",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = RiwaqTextPrimary
                        )
                    }

                    IconButton(onClick = {
                        if (currentMonth == 11) {
                            viewModel.setCalendarMonthYear(currentYear + 1, 0)
                        } else {
                            viewModel.setCalendarMonthYear(currentYear, currentMonth + 1)
                        }
                    }) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "الشهر التالي", tint = RiwaqBlue)
                    }
                }
            }

            // Month Grid of Days (Matching Screenshot 10 blue squares)
            item {
                CalendarGrid(
                    year = currentYear,
                    month = currentMonth,
                    selectedDate = selectedDate,
                    events = monthEvents,
                    boxColor = boxColor,
                    headerColor = headerColor,
                    cellsColor = cellsColor,
                    dividersColor = dividersColor,
                    textColor = textColor,
                    eventColor = eventColor,
                    onSelectDate = { viewModel.selectCalendarDate(it) }
                )
            }

            // "حدث اليوم" Card (Matching Screenshot 10)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "حدث اليوم",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary
                    )
                }
            }

            if (selectedDayEvents.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد أحداث مسجلة في هذا اليوم ($selectedDate)",
                            fontSize = 13.sp,
                            color = RiwaqTextMuted
                        )
                    }
                }
            } else {
                items(selectedDayEvents, key = { "event_${it.id}" }) { event ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(onClick = { eventToDelete = event }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف الحدث",
                                    tint = RiwaqPriorityRed,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = event.title,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = RiwaqTextPrimary
                                    )
                                    if (event.time.isNotBlank()) {
                                        Text(text = event.time, fontSize = 12.sp, color = RiwaqTextSecondary)
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.CardGiftcard,
                                    contentDescription = null,
                                    tint = eventColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Floating Action Button (Edit / Add Event)
        FloatingActionButton(
            onClick = { showAddEventDialog = true },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
                .testTag("add_event_fab"),
            containerColor = Color.White,
            contentColor = RiwaqBlue,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "إضافة حدث جديد",
                modifier = Modifier.size(26.dp)
            )
        }

        // Add Event Dialog
        if (showAddEventDialog) {
            AddEventDialog(
                dateString = selectedDate,
                onDismiss = { showAddEventDialog = false },
                onSave = { title, time, note ->
                    viewModel.addCalendarEvent(
                        title = title,
                        dateString = selectedDate,
                        time = time,
                        colorHex = "#92B4F8",
                        note = note
                    )
                    showAddEventDialog = false
                }
            )
        }

        // Delete Event Confirmation
        if (eventToDelete != null) {
            AlertDialog(
                onDismissRequest = { eventToDelete = null },
                title = { Text("حذف الحدث") },
                text = { Text("هل تريد بالتأكيد حذف حدث '${eventToDelete?.title}'؟") },
                confirmButton = {
                    TextButton(onClick = {
                        eventToDelete?.let { viewModel.deleteCalendarEvent(it) }
                        eventToDelete = null
                    }) {
                        Text("حذف", color = RiwaqPriorityRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { eventToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
internal fun CalendarGrid(
    year: Int,
    month: Int,
    selectedDate: String,
    events: List<CalendarEventEntity>,
    boxColor: Color,
    headerColor: Color,
    cellsColor: Color,
    dividersColor: Color,
    textColor: Color,
    eventColor: Color,
    onSelectDate: (String) -> Unit
) {
    val eventsByDate = remember(events) { events.groupBy { it.dateString } }

    val daysInMonth = remember(year, month) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1=Sunday, 7=Saturday
        Pair(maxDays, firstDayOfWeek)
    }

    val totalCells = 42 // 6 rows x 7 cols
    val daysList = remember(year, month, daysInMonth) {
        val list = mutableListOf<String?>()
        val offset = (daysInMonth.second - Calendar.SUNDAY + 7) % 7
        for (i in 0 until offset) {
            list.add(null)
        }
        for (day in 1..daysInMonth.first) {
            val dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
            list.add(dateStr)
        }
        while (list.size < totalCells) {
            list.add(null)
        }
        list
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(boxColor)
            .border(1.dp, dividersColor, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            // Day names row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("ح", "ن", "ث", "ر", "خ", "ج", "س").forEach { d ->
                    Text(
                        text = d,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = headerColor,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // 6 Rows x 7 Columns
            daysList.chunked(7).forEach { week ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    week.forEach { dateStr ->
                        if (dateStr == null) {
                            Box(modifier = Modifier.weight(1f).aspectRatio(1f))
                        } else {
                            val isSelected = dateStr == selectedDate
                            val dayEvents = eventsByDate[dateStr] ?: emptyList()
                            val hasEvent = dayEvents.isNotEmpty()
                            val dayNum = dateStr.substringAfterLast("-").toIntOrNull() ?: 1

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when {
                                            isSelected -> RiwaqBlue
                                            hasEvent -> Color(0xFFC7DCFF)
                                            else -> cellsColor
                                        }
                                    )
                                    .clickable { onSelectDate(dateStr) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (hasEvent) {
                                    Icon(
                                        imageVector = Icons.Default.CardGiftcard,
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else eventColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    Text(
                                        text = "$dayNum",
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else textColor
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddEventDialog(
    dateString: String,
    onDismiss: () -> Unit,
    onSave: (title: String, time: String, note: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة حدث لليوم ($dateString)") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("عنوان الحدث") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    placeholder = { Text("الوقت (مثال: 10:00 ص)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    placeholder = { Text("ملاحظات إضافية (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (title.isNotBlank()) {
                    onSave(title, time, note)
                }
            }) {
                Text("حفظ", color = RiwaqBlue)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
