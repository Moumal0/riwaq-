package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppSettings
import com.example.ui.RiwaqViewModel
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary

private fun hexColor(hex: String): Color = try {
    Color(android.graphics.Color.parseColor(hex))
} catch (_: Exception) {
    Color.Gray
}

/** سمات جاهزة مستوحاة من سمات سطح مكتب لينكس الشهيرة (بنسخها الفاتحة). */
private data class ThemePreset(
    val name: String,
    val primary: String,
    val background: String,
    val sidebar: String,
    val calHeader: String,
    val calCells: String
)

private val ThemePresets = listOf(
    ThemePreset("رِواق", "#3B82F6", "#F8FAFC", "#92B4F8", "#3B82F6", "#E8F0FE"),
    ThemePreset("Nord", "#5E81AC", "#ECEFF4", "#5E81AC", "#5E81AC", "#E5E9F0"),
    ThemePreset("Dracula", "#BD93F9", "#F8F8F2", "#6272A4", "#BD93F9", "#EDE7F6"),
    ThemePreset("Gruvbox", "#D65D0E", "#FBF1C7", "#B57614", "#D65D0E", "#F2E5BC"),
    ThemePreset("Solarized", "#268BD2", "#FDF6E3", "#586E75", "#268BD2", "#EEE8D5"),
    ThemePreset("Catppuccin", "#8839EF", "#EFF1F5", "#7287FD", "#8839EF", "#E6E9EF"),
    ThemePreset("Everforest", "#8DA101", "#F3EAD3", "#6B8E5A", "#8DA101", "#EAE4CA"),
    ThemePreset("Tokyo Night", "#34548A", "#E1E2E7", "#34548A", "#34548A", "#D5D6DB")
)

@Composable
fun ThemePresetsRow(settings: AppSettings, onApply: (AppSettings) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("سمات جاهزة", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ThemePresets, key = { it.name }) { t ->
                val selected = settings.primaryColorHex.equals(t.primary, ignoreCase = true) &&
                    settings.backgroundColorHex.equals(t.background, ignoreCase = true)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(hexColor(t.background))
                        .border(
                            if (selected) 2.dp else 1.dp,
                            if (selected) hexColor(t.primary) else RiwaqCardBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            onApply(
                                settings.copy(
                                    primaryColorHex = t.primary,
                                    backgroundColorHex = t.background,
                                    sidebarColorHex = t.sidebar,
                                    calendarHeaderColorHex = t.calHeader,
                                    calendarCellsColorHex = t.calCells
                                )
                            )
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(hexColor(t.primary)))
                    Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(hexColor(t.sidebar)))
                    Text(t.name, fontSize = 12.sp, color = Color(0xFF1E293B))
                }
            }
        }
    }
}

/** الخط وحجمه (روح الطرفية): خط أحادي المسافة وتكبير/تصغير النص. */
@Composable
fun FontCustomization(settings: AppSettings, onChange: (AppSettings) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("خط الطرفية (Monospace)", fontSize = 14.sp, color = RiwaqTextPrimary)
            Switch(checked = settings.monoFont, onCheckedChange = { onChange(settings.copy(monoFont = it)) })
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("حجم الخط: ${(settings.fontScale * 100).toInt()}%", fontSize = 14.sp, color = RiwaqTextPrimary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    onChange(settings.copy(fontScale = (settings.fontScale - 0.05f).coerceAtLeast(0.8f)))
                }) { Icon(Icons.Default.Remove, contentDescription = "تصغير", tint = RiwaqBlue) }
                IconButton(onClick = {
                    onChange(settings.copy(fontScale = (settings.fontScale + 0.05f).coerceAtMost(1.4f)))
                }) { Icon(Icons.Default.Add, contentDescription = "تكبير", tint = RiwaqBlue) }
            }
        }
    }
}

private data class CalendarPreset(
    val name: String,
    val box: String,
    val header: String,
    val cells: String,
    val dividers: String,
    val text: String,
    val event: String
)

private val CalendarPresets = listOf(
    CalendarPreset("رِواق", "#FFFFFF", "#3B82F6", "#E8F0FE", "#E2E8F0", "#1E293B", "#E07A5F"),
    CalendarPreset("رمل", "#FFFBF2", "#C27D6B", "#F6E9DC", "#E8D8C4", "#4A3728", "#2A9D8F"),
    CalendarPreset("غابة", "#F7FAF5", "#4C956C", "#E3F0E6", "#D4E4D8", "#1F3D2B", "#E9A23B"),
    CalendarPreset("ليلك", "#FBF8FF", "#7C5CBF", "#EDE7F6", "#DDD3EE", "#2E1F4D", "#E56B8A"),
    CalendarPreset("محيط", "#F5FBFF", "#0E7490", "#DDF1F7", "#C5E3EC", "#0F3A47", "#F59E0B"),
    CalendarPreset("وردي", "#FFF7F8", "#E11D48", "#FDE7EB", "#F6D0D8", "#4A1D26", "#0EA5E9")
)

@Composable
fun CalendarPresetsRow(settings: AppSettings, onApply: (AppSettings) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("أنماط جاهزة للتقويم", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CalendarPresets, key = { it.name }) { c ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(hexColor(c.box))
                        .border(1.dp, hexColor(c.dividers), RoundedCornerShape(14.dp))
                        .clickable {
                            onApply(
                                settings.copy(
                                    calendarBoxColorHex = c.box,
                                    calendarHeaderColorHex = c.header,
                                    calendarCellsColorHex = c.cells,
                                    calendarDividersColorHex = c.dividers,
                                    calendarTextColorHex = c.text,
                                    calendarEventColorHex = c.event
                                )
                            )
                        }
                        .padding(10.dp)
                ) {
                    Box(modifier = Modifier.size(width = 56.dp, height = 12.dp).clip(RoundedCornerShape(4.dp)).background(hexColor(c.header)))
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp), modifier = Modifier.padding(top = 4.dp)) {
                        repeat(4) { Box(modifier = Modifier.size(11.dp).clip(RoundedCornerShape(3.dp)).background(hexColor(c.cells))) }
                    }
                    Box(modifier = Modifier.padding(top = 4.dp).size(8.dp).clip(CircleShape).background(hexColor(c.event)))
                    Text(c.name, fontSize = 11.sp, color = hexColor(c.text), modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}

/** إعدادات خاصة بكل قسم. */
@Composable
fun SectionSettingsCard(viewModel: RiwaqViewModel) {
    val ctx = LocalContext.current
    val pomo by viewModel.pomodoro.collectAsStateWithLifecycle()
    val readerPrefs = remember { ctx.getSharedPreferences("riwaq_reader", Context.MODE_PRIVATE) }
    val sportPrefs = remember { ctx.getSharedPreferences("riwaq_sports", Context.MODE_PRIVATE) }
    var readerNight by remember { mutableStateOf(readerPrefs.getBoolean("night", false)) }
    var goal by remember { mutableIntStateOf(sportPrefs.getInt("kcal_goal", 2000)) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SettingGroupTitle("بومودورو")
        StepperRow("مدة التركيز", "${pomo.workMin} د",
            onMinus = { viewModel.pomodoroSetDurations(pomo.workMin - 5, pomo.breakMin) },
            onPlus = { viewModel.pomodoroSetDurations(pomo.workMin + 5, pomo.breakMin) })
        StepperRow("مدة الاستراحة", "${pomo.breakMin} د",
            onMinus = { viewModel.pomodoroSetDurations(pomo.workMin, pomo.breakMin - 1) },
            onPlus = { viewModel.pomodoroSetDurations(pomo.workMin, pomo.breakMin + 1) })

        SettingGroupTitle("قارئ الكتب")
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("الوضع الليلي افتراضياً", fontSize = 14.sp, color = RiwaqTextPrimary)
            Switch(checked = readerNight, onCheckedChange = {
                readerNight = it
                readerPrefs.edit().putBoolean("night", it).apply()
            })
        }

        SettingGroupTitle("الأمان")
        val lockPrefs = remember { ctx.getSharedPreferences("riwaq_lock", Context.MODE_PRIVATE) }
        var lockOn by remember { mutableStateOf(lockPrefs.getBoolean("enabled", false)) }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("قفل التطبيق (بصمة / PIN الجهاز)", fontSize = 14.sp, color = RiwaqTextPrimary)
            Switch(checked = lockOn, onCheckedChange = {
                lockOn = it
                lockPrefs.edit().putBoolean("enabled", it).apply()
            })
        }

        SettingGroupTitle("الرياضة والتغذية")
        StepperRow("الهدف اليومي للسعرات", "$goal",
            onMinus = { goal = (goal - 100).coerceAtLeast(800); sportPrefs.edit().putInt("kcal_goal", goal).apply() },
            onPlus = { goal = (goal + 100).coerceAtMost(6000); sportPrefs.edit().putInt("kcal_goal", goal).apply() })
    }
}

@Composable
private fun SettingGroupTitle(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = RiwaqTextSecondary)
}

@Composable
private fun StepperRow(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 14.sp, color = RiwaqTextPrimary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMinus) { Icon(Icons.Default.Remove, contentDescription = "إنقاص", tint = RiwaqBlue) }
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = RiwaqTextPrimary)
            IconButton(onClick = onPlus) { Icon(Icons.Default.Add, contentDescription = "زيادة", tint = RiwaqBlue) }
        }
    }
}
