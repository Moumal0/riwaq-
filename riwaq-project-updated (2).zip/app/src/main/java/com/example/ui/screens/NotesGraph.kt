package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RiwaqViewModel
import com.example.ui.navigation.Screen
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqTextMuted
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** رسم بياني للملاحظات (مثل Obsidian): العقد = ملاحظات، الخطوط = روابط [[عنوان|رقم]]. */
@Composable
fun NotesGraphPane(
    viewModel: RiwaqViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val notes by viewModel.allNotes.collectAsStateWithLifecycle()
    val linkRegex = remember { Regex("\\[\\[[^\\]|]*\\|(\\d+)\\]\\]") }

    val ids = remember(notes) { notes.map { it.id } }
    val edges = remember(notes) {
        val set = ids.toSet()
        notes.flatMap { n ->
            linkRegex.findAll(n.content).mapNotNull { it.groupValues[1].toLongOrNull() }
                .filter { it in set && it != n.id }.map { n.id to it }.toList()
        }.distinct()
    }
    val degree = remember(edges) {
        val m = HashMap<Long, Int>()
        edges.forEach { (a, b) -> m[a] = (m[a] ?: 0) + 1; m[b] = (m[b] ?: 0) + 1 }
        m
    }
    // تخطيط قوى بسيط في مساحة 0..1
    val pos = remember(notes, edges) {
        val n = ids.size
        val x = FloatArray(n) { 0.5f + 0.35f * cos(2.0 * Math.PI * it / max(1, n)).toFloat() }
        val y = FloatArray(n) { 0.5f + 0.35f * sin(2.0 * Math.PI * it / max(1, n)).toFloat() }
        val idx = ids.withIndex().associate { it.value to it.index }
        repeat(120) {
            val dx = FloatArray(n); val dy = FloatArray(n)
            for (i in 0 until n) for (j in i + 1 until n) {
                var vx = x[i] - x[j]; var vy = y[i] - y[j]
                val d = max(0.02f, sqrt(vx * vx + vy * vy))
                val f = 0.0006f / (d * d)
                vx = vx / d * f; vy = vy / d * f
                dx[i] += vx; dy[i] += vy; dx[j] -= vx; dy[j] -= vy
            }
            for ((a, b) in edges) {
                val i = idx[a] ?: continue; val j = idx[b] ?: continue
                val vx = x[j] - x[i]; val vy = y[j] - y[i]
                dx[i] += vx * 0.02f; dy[i] += vy * 0.02f
                dx[j] -= vx * 0.02f; dy[j] -= vy * 0.02f
            }
            for (i in 0 until n) {
                dx[i] += (0.5f - x[i]) * 0.004f; dy[i] += (0.5f - y[i]) * 0.004f
                x[i] = (x[i] + dx[i]).coerceIn(0.06f, 0.94f)
                y[i] = (y[i] + dy[i]).coerceIn(0.06f, 0.94f)
            }
        }
        ids.indices.map { Offset(x[it], y[it]) }
    }

    if (notes.isEmpty()) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا توجد ملاحظات بعد", color = RiwaqTextMuted)
        }
        return
    }

    Box(modifier = modifier.fillMaxSize().padding(8.dp)) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(notes, pos) {
                    detectTapGestures { tap ->
                        val w = size.width.toFloat(); val h = size.height.toFloat()
                        var best = -1; var bd = Float.MAX_VALUE
                        pos.forEachIndexed { i, p ->
                            val ox = p.x * w - tap.x; val oy = p.y * h - tap.y
                            val d = ox * ox + oy * oy
                            if (d < bd) { bd = d; best = i }
                        }
                        if (best >= 0 && bd < 48f * 48f * 2.2f) {
                            val note = notes[best]
                            onNavigate(Screen.NoteEditor(note.id, note.folderId))
                        }
                    }
                }
        ) {
            val w = size.width; val h = size.height
            val idx = ids.withIndex().associate { it.value to it.index }
            edges.forEach { (a, b) ->
                val i = idx[a] ?: return@forEach; val j = idx[b] ?: return@forEach
                drawLine(
                    RiwaqTextMuted.copy(alpha = 0.6f),
                    Offset(pos[i].x * w, pos[i].y * h), Offset(pos[j].x * w, pos[j].y * h), 2f
                )
            }
            val paint = android.graphics.Paint().apply {
                isAntiAlias = true
                textSize = 11.sp.toPx()
                color = android.graphics.Color.DKGRAY
                textAlign = android.graphics.Paint.Align.CENTER
            }
            notes.forEachIndexed { i, n ->
                val c = Offset(pos[i].x * w, pos[i].y * h)
                val r = 8.dp.toPx() + (degree[n.id] ?: 0) * 2.dp.toPx()
                drawCircle(RiwaqBlue, r, c)
                drawCircle(Color.White, r, c, style = Stroke(2f))
                val title = if (n.title.length > 14) n.title.take(13) + "…" else n.title
                drawContext.canvas.nativeCanvas.drawText(title, c.x, c.y + r + 14.dp.toPx(), paint)
            }
        }
    }
}
