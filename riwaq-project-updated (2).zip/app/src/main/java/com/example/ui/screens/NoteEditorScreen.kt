package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.NoteEntity
import com.example.ui.RiwaqViewModel
import com.example.ui.navigation.Screen
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NoteEditorScreen(
    noteId: Long,
    initialFolderId: Long?,
    viewModel: RiwaqViewModel,
    onBack: () -> Unit,
    onNavigateToScreen: (Screen) -> Unit,
    formatActionTrigger: String?,
    onFormatActionConsumed: () -> Unit,
    modifier: Modifier = Modifier
) {
    val notes by viewModel.allNotes.collectAsStateWithLifecycle()
    val folders by viewModel.allFolders.collectAsStateWithLifecycle()

    val existingNote = remember(notes, noteId) {
        if (noteId != 0L) notes.find { it.id == noteId } else null
    }

    var titleValue by remember { mutableStateOf(existingNote?.title ?: "") }
    var bodyValue by remember {
        mutableStateOf(TextFieldValue(existingNote?.content ?: ""))
    }
    var currentFolderId by remember { mutableStateOf(existingNote?.folderId ?: initialFolderId) }

    // Undo / Redo history
    val undoStack = remember { mutableStateListOf<String>() }
    val redoStack = remember { mutableStateListOf<String>() }

    var showFolderMenu by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var showInfoDialog by remember { mutableStateOf(false) }

    // --- Note Linking Autocomplete State (Triggered by '[') ---
    var noteSearchQuery by remember { mutableStateOf<String?>(null) }
    var bracketStartPos by remember { mutableIntStateOf(-1) }

    // Filter matching notes for suggestion list
    val matchingNotes = remember(notes, noteSearchQuery, noteId) {
        val q = (noteSearchQuery ?: "").trim().lowercase()
        notes.filter { it.id != noteId }
            .filter { q.isEmpty() || it.title.lowercase().contains(q) }
    }

    // --- Linked Notes Detection ---
    val linkedNotesList = remember(bodyValue.text, notes) {
        val regex = Regex("\\[\\[(.*?)\\]\\]")
        val matches = regex.findAll(bodyValue.text)
        val list = mutableListOf<NoteEntity>()
        matches.forEach { m ->
            val raw = m.groupValues[1]
            val parts = raw.split("|")
            val titleOrName = parts[0].trim()
            val idVal = parts.getOrNull(1)?.toLongOrNull()
            val found = notes.find { (idVal != null && it.id == idVal) || it.title.equals(titleOrName, ignoreCase = true) }
            if (found != null && !list.any { it.id == found.id }) {
                list.add(found)
            }
        }
        list
    }

    // --- Task Items in Note (Lines with '☐' or '☑' or '- [ ]' or '- [x]') ---
    val taskLines = remember(bodyValue.text) {
        bodyValue.text.lines().filter { line ->
            val trimmed = line.trimStart()
            trimmed.startsWith("☐") ||
            trimmed.startsWith("☑") ||
            trimmed.startsWith("- [ ]") ||
            trimmed.startsWith("- [x]")
        }
    }

    // Save note helper
    fun persistCurrentNote() {
        if (titleValue.isNotBlank() || bodyValue.text.isNotBlank()) {
            viewModel.saveNote(
                noteId = noteId,
                title = titleValue,
                content = bodyValue.text,
                folderId = currentFolderId
            )
        }
    }

    // Save and exit handler
    fun saveAndExit() {
        persistCurrentNote()
        onBack()
    }

    BackHandler {
        saveAndExit()
    }

    // Handle format actions from RiwaqSideRail
    LaunchedEffect(formatActionTrigger) {
        if (formatActionTrigger != null) {
            val text = bodyValue.text
            val sel = bodyValue.selection
            val before = text.substring(0, sel.min)
            val selected = text.substring(sel.min, sel.max)
            val after = text.substring(sel.max)

            undoStack.add(text)
            redoStack.clear()

            val newText = when (formatActionTrigger) {
                "bold" -> "$before**$selected**$after"
                "italic" -> "$before*$selected*$after"
                "strike" -> "$before~~$selected~~$after"
                "underline" -> "$before<u>$selected</u>$after"
                "heading" -> "$before\n## $selected$after"
                "style" -> "$before`$selected`$after"
                else -> text
            }
            bodyValue = TextFieldValue(newText, TextRange(newText.length))
            onFormatActionConsumed()
        }
    }

    // Insert helper
    fun insertTextAtCursor(insert: String) {
        val text = bodyValue.text
        val sel = bodyValue.selection
        val before = text.substring(0, sel.min)
        val after = text.substring(sel.max)
        val newText = "$before$insert$after"
        undoStack.add(text)
        redoStack.clear()
        bodyValue = TextFieldValue(newText, TextRange(before.length + insert.length))
    }

    // Toggle Task Line (☐ <-> ☑)
    fun toggleTaskLine(targetLine: String) {
        val isDone = targetLine.contains("☑") || targetLine.contains("- [x]")
        val toggled = if (isDone) {
            targetLine.replaceFirst("☑", "☐").replaceFirst("- [x]", "- [ ]")
        } else {
            targetLine.replaceFirst("☐", "☑").replaceFirst("- [ ]", "- [x]")
        }
        val newBody = bodyValue.text.replaceFirst(targetLine, toggled)
        undoStack.add(bodyValue.text)
        redoStack.clear()
        bodyValue = TextFieldValue(newBody, TextRange(bodyValue.selection.start.coerceAtMost(newBody.length)))
    }

    // Handler when user selects a note to link from autocomplete
    fun selectNoteForLink(chosenNote: NoteEntity) {
        val fullText = bodyValue.text
        val curPos = bodyValue.selection.start
        val startIdx = if (bracketStartPos >= 0 && bracketStartPos < fullText.length) bracketStartPos else curPos

        val prefix = fullText.substring(0, startIdx)
        val suffix = if (curPos in startIdx..fullText.length) fullText.substring(curPos) else fullText.substring(startIdx)
        val linkText = "[[${chosenNote.title}|${chosenNote.id}]] "
        val updatedText = prefix + linkText + suffix

        undoStack.add(fullText)
        redoStack.clear()
        bodyValue = TextFieldValue(updatedText, TextRange(prefix.length + linkText.length))
        noteSearchQuery = null
        bracketStartPos = -1
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Top Toolbar: Undo/Redo & Folder Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Back, Undo, Redo
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(onClick = { saveAndExit() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع وحفظ",
                            tint = RiwaqTextPrimary
                        )
                    }
                    IconButton(
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack.add(bodyValue.text)
                                val prev = undoStack.removeAt(undoStack.size - 1)
                                bodyValue = TextFieldValue(prev, TextRange(prev.length))
                            }
                        },
                        enabled = undoStack.isNotEmpty()
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "تراجع",
                            tint = if (undoStack.isNotEmpty()) RiwaqTextPrimary else RiwaqTextMuted
                        )
                    }
                    IconButton(
                        onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack.add(bodyValue.text)
                                val next = redoStack.removeAt(redoStack.size - 1)
                                bodyValue = TextFieldValue(next, TextRange(next.length))
                            }
                        },
                        enabled = redoStack.isNotEmpty()
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "إعادة",
                            tint = if (redoStack.isNotEmpty()) RiwaqTextPrimary else RiwaqTextMuted
                        )
                    }
                }

                // Right: Folder Selector & New Folder
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White)
                                .border(1.dp, RiwaqCardBorder, RoundedCornerShape(12.dp))
                                .clickable { showFolderMenu = true }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            val curFolderName = folders.find { it.id == currentFolderId }?.name ?: "اختيار مجلد"
                            Text(text = curFolderName, fontSize = 12.sp, color = RiwaqTextPrimary)
                        }

                        DropdownMenu(
                            expanded = showFolderMenu,
                            onDismissRequest = { showFolderMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("بدون مجلد") },
                                onClick = {
                                    currentFolderId = null
                                    showFolderMenu = false
                                }
                            )
                            folders.forEach { folder ->
                                DropdownMenuItem(
                                    text = { Text(folder.name) },
                                    onClick = {
                                        currentFolderId = folder.id
                                        showFolderMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(12.dp))
                            .clickable { showNewFolderDialog = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = "مجلد جديد", fontSize = 12.sp, color = RiwaqBlue)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title input
            OutlinedTextField(
                value = titleValue,
                onValueChange = { titleValue = it },
                placeholder = { Text("العنوان", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = RiwaqTextMuted) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_title_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = RiwaqTextPrimary
                )
            )

            // ========================================================
            // [ Auto-complete Suggestions Popup Card (When typing '[')
            // ========================================================
            if (noteSearchQuery != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF0F7FF))
                        .border(1.5.dp, RiwaqBlue, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.Link, contentDescription = null, tint = RiwaqBlue, modifier = Modifier.size(18.dp))
                                Text(
                                    text = "ربط ملاحظة (اختر ملاحظة للإدراج)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RiwaqBlue
                                )
                            }
                            IconButton(
                                onClick = {
                                    noteSearchQuery = null
                                    bracketStartPos = -1
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = RiwaqTextMuted, modifier = Modifier.size(16.dp))
                            }
                        }

                        if (noteSearchQuery!!.isNotBlank()) {
                            Text(
                                text = "تصفية حسب: \"${noteSearchQuery}\"",
                                fontSize = 11.sp,
                                color = RiwaqTextSecondary
                            )
                        }

                        if (matchingNotes.isEmpty()) {
                            Text(
                                text = if (notes.size <= 1) "لا توجد ملاحظات أخرى متاحة للربط" else "لا توجد ملاحظات تطابق البحث",
                                fontSize = 12.sp,
                                color = RiwaqTextMuted,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 180.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(matchingNotes, key = { "suggest_${it.id}" }) { itemNote ->
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.White)
                                            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(8.dp))
                                            .clickable { selectNoteForLink(itemNote) }
                                            .padding(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Text(text = "📝", fontSize = 13.sp)
                                                Text(
                                                    text = itemNote.title.ifBlank { "ملاحظة بدون عنوان" },
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = RiwaqTextPrimary
                                                )
                                            }
                                            Text(
                                                text = "إدراج رابط",
                                                fontSize = 11.sp,
                                                color = RiwaqBlue,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Content body
            OutlinedTextField(
                value = bodyValue,
                onValueChange = { newTfv ->
                    var updatedText = newTfv.text
                    val sel = newTfv.selection

                    // # Shortcut: Convert lines starting with "# " into "☐ "
                    val converted = updatedText.replace(Regex("(?m)^#\\s+"), "☐ ")
                    if (converted != updatedText) {
                        updatedText = converted
                    }

                    if (updatedText != bodyValue.text) {
                        undoStack.add(bodyValue.text)
                        redoStack.clear()
                    }

                    // [ Shortcut Detection: Check if cursor is right after '['
                    val curPos = sel.start
                    val textBeforeCursor = if (curPos in 0..updatedText.length) updatedText.substring(0, curPos) else ""
                    val lastBracket = textBeforeCursor.lastIndexOf('[')
                    if (lastBracket != -1) {
                        val segment = textBeforeCursor.substring(lastBracket + 1)
                        if (!segment.contains('\n') && !segment.contains(']')) {
                            noteSearchQuery = segment.trimStart('[')
                            bracketStartPos = lastBracket
                        } else {
                            noteSearchQuery = null
                            bracketStartPos = -1
                        }
                    } else {
                        noteSearchQuery = null
                        bracketStartPos = -1
                    }

                    bodyValue = TextFieldValue(updatedText, sel)
                },
                placeholder = { Text("ادخل النص هنا... (اكتب [ لربط ملاحظة، واكتب # لبدء عنصر مهمة)", color = RiwaqTextMuted) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .testTag("note_body_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontSize = 15.sp,
                    color = RiwaqTextPrimary,
                    lineHeight = 24.sp
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // ========================================================
            // Linked Notes Section (Clickable badges to jump to notes)
            // ========================================================
            if (linkedNotesList.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF1F5F9))
                        .border(1.dp, RiwaqCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = RiwaqBlue, modifier = Modifier.size(16.dp))
                            Text(
                                text = "الملاحظات المرتبطة (اضغط للانتقال للملاحظة)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = RiwaqTextPrimary
                            )
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            linkedNotesList.forEach { linkedNote ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                        .border(1.dp, RiwaqBlue.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .clickable {
                                            persistCurrentNote()
                                            onNavigateToScreen(Screen.NoteEditor(noteId = linkedNote.id, folderId = linkedNote.folderId))
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = linkedNote.title.ifBlank { "ملاحظة" },
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = RiwaqBlue
                                        )
                                        Icon(
                                            imageVector = Icons.Default.OpenInNew,
                                            contentDescription = "فتح الملاحظة",
                                            tint = RiwaqBlue,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // ========================================================
            // Interactive Task Items Panel (Click to toggle ☐ <-> ☑)
            // ========================================================
            if (taskLines.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White)
                        .border(1.dp, RiwaqCardBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val doneCount = taskLines.count { it.contains("☑") || it.contains("- [x]") }
                            Text(
                                text = "عناصر المهام في الملاحظة ($doneCount/${taskLines.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = RiwaqTextPrimary
                            )
                            Text(
                                text = "اضغط على العنصر لتحديده كمكتمل",
                                fontSize = 11.sp,
                                color = RiwaqTextSecondary
                            )
                        }

                        taskLines.forEach { line ->
                            val isDone = line.contains("☑") || line.contains("- [x]")
                            val cleanText = line
                                .replaceFirst("☐", "")
                                .replaceFirst("☑", "")
                                .replaceFirst("- [ ]", "")
                                .replaceFirst("- [x]", "")
                                .trim()

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { toggleTaskLine(line) }
                                    .padding(vertical = 4.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (isDone) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                                    contentDescription = if (isDone) "مكتمل" else "غير مكتمل",
                                    tint = if (isDone) RiwaqPriorityGreen else RiwaqTextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = cleanText.ifBlank { "مهمة فارغة" },
                                    fontSize = 13.sp,
                                    color = if (isDone) RiwaqTextMuted else RiwaqTextPrimary,
                                    textDecoration = if (isDone) TextDecoration.LineThrough else TextDecoration.None
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // ========================================================
            // Markdown Quick Helpers (Matching Screenshot 8)
            // ========================================================
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MarkdownShortcutPill(label = "]] ربط ملاحظة") {
                    val full = bodyValue.text
                    val cur = bodyValue.selection.start
                    insertTextAtCursor("[")
                    noteSearchQuery = ""
                    bracketStartPos = cur
                }
                MarkdownShortcutPill(label = "# قائمة مهمة") {
                    insertTextAtCursor("\n☐ ")
                }
                MarkdownShortcutPill(label = "@ ربط عنصر") {
                    insertTextAtCursor("@")
                }
                MarkdownShortcutPill(label = "< اقتباس") {
                    insertTextAtCursor("\n> ")
                }
                MarkdownShortcutPill(label = "- قائمة") {
                    insertTextAtCursor("\n- ")
                }
                MarkdownShortcutPill(label = "1. قائمة مرقمة") {
                    insertTextAtCursor("\n1. ")
                }
                MarkdownShortcutPill(label = "--- فاصل") {
                    insertTextAtCursor("\n---\n")
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Bottom Actions: Paperclip & Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(1.dp, RiwaqCardBorder, CircleShape)
                        .clickable { showInfoDialog = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "معلومات الملاحظة",
                        tint = RiwaqTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(1.dp, RiwaqCardBorder, CircleShape)
                        .clickable {
                            insertTextAtCursor("\n---\n")
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "إرفاق أو إضافة فاصل",
                        tint = RiwaqTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // New Folder Dialog
        if (showNewFolderDialog) {
            AlertDialog(
                onDismissRequest = {
                    showNewFolderDialog = false
                    newFolderName = ""
                },
                title = { Text("مجلد جديد") },
                text = {
                    OutlinedTextField(
                        value = newFolderName,
                        onValueChange = { newFolderName = it },
                        placeholder = { Text("اسم المجلد") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (newFolderName.isNotBlank()) {
                            viewModel.createFolder(newFolderName)
                            showNewFolderDialog = false
                            newFolderName = ""
                        }
                    }) {
                        Text("إنشاء", color = RiwaqBlue)
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showNewFolderDialog = false
                        newFolderName = ""
                    }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // Info Dialog
        if (showInfoDialog) {
            AlertDialog(
                onDismissRequest = { showInfoDialog = false },
                title = { Text("معلومات الملاحظة") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("عدد الكلمات: ${bodyValue.text.split("\\s+".toRegex()).filter { it.isNotBlank() }.size}")
                        Text("عدد الأحرف: ${bodyValue.text.length}")
                        Text("عدد المهام: ${taskLines.size}")
                        Text("الملاحظات المرتبطة: ${linkedNotesList.size}")
                        Text("تاريخ الحفظ: تلقائي عند الخروج أو الانتقال")
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showInfoDialog = false }) {
                        Text("حسناً")
                    }
                }
            )
        }
    }
}

@Composable
private fun MarkdownShortcutPill(
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(text = label, fontSize = 12.sp, color = RiwaqTextSecondary)
    }
}
