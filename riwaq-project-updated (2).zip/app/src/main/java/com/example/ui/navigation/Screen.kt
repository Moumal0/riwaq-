package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Habits : Screen("habits")
    object Tasks : Screen("tasks")
    object Notes : Screen("notes")
    object Library : Screen("library")
    object Calendar : Screen("calendar")
    object Enthusiasm : Screen("enthusiasm")
    object Settings : Screen("settings")
    object Sports : Screen("sports")
    data class NoteEditor(val noteId: Long = 0, val folderId: Long? = null) : Screen("note_editor")
    data class PdfReader(val bookId: Long) : Screen("pdf_reader")
}
