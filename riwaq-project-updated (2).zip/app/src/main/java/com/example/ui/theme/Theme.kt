package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = RiwaqBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = RiwaqRailBg,
    onSecondary = Color(0xFF1E293B),
    background = RiwaqBg,
    onBackground = RiwaqTextPrimary,
    surface = RiwaqCardBg,
    onSurface = RiwaqTextPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = RiwaqTextSecondary,
    outline = RiwaqCardBorder
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = Color(0xFF3B82F6),
    onSecondary = Color.White,
    background = Color(0xFF0F172A),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF1E293B),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF334155),
    onSurfaceVariant = Color(0xFFCBD5E1),
    outline = Color(0xFF475569)
)

@Composable
fun RiwaqTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    customPrimary: Color? = null,
    customBackground: Color? = null,
    monoFont: Boolean = false,
    content: @Composable () -> Unit
) {
    val baseScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val colorScheme = baseScheme.copy(
        primary = customPrimary ?: baseScheme.primary,
        background = customBackground ?: baseScheme.background
    )
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography
    ) {
        if (monoFont) {
            CompositionLocalProvider(
                LocalTextStyle provides LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace)
            ) { content() }
        } else {
            content()
        }
    }
}
