package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.AssignmentTurnedIn
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Stars
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.Screen
import com.example.ui.theme.RiwaqRailBg
import com.example.ui.theme.RiwaqRailIconActive
import com.example.ui.theme.RiwaqRailIconInactive

@Composable
fun RiwaqSideRail(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    onFoxClick: () -> Unit,
    modifier: Modifier = Modifier,
    sidebarColor: Color = RiwaqRailBg,
    widthDp: Int = 64,
    onFormatAction: ((String) -> Unit)? = null
) {
    val isNoteEditor = currentScreen is Screen.NoteEditor

    Column(
        modifier = modifier
            .width(widthDp.dp)
            .fillMaxHeight()
            .background(sidebarColor)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top: Fox Emblem
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            FoxEmblem(
                size = 52.dp,
                onClick = onFoxClick
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (!isNoteEditor) {
                // Navigation Icons
                RailIconButton(
                    icon = if (currentScreen is Screen.Home) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "الرئيسية",
                    isSelected = currentScreen is Screen.Home,
                    testTag = "nav_home",
                    onClick = { onNavigate(Screen.Home) }
                )
                Spacer(modifier = Modifier.height(12.dp))

                RailIconButton(
                    icon = if (currentScreen is Screen.Habits) Icons.Filled.Stars else Icons.Outlined.Stars,
                    contentDescription = "العادات",
                    isSelected = currentScreen is Screen.Habits,
                    testTag = "nav_habits",
                    onClick = { onNavigate(Screen.Habits) }
                )
                Spacer(modifier = Modifier.height(12.dp))

                RailIconButton(
                    icon = Icons.Outlined.Checklist,
                    contentDescription = "المهمات",
                    isSelected = currentScreen is Screen.Tasks,
                    testTag = "nav_tasks",
                    onClick = { onNavigate(Screen.Tasks) }
                )
                Spacer(modifier = Modifier.height(12.dp))

                RailIconButton(
                    icon = Icons.Outlined.Description,
                    contentDescription = "الملاحظات",
                    isSelected = currentScreen is Screen.Notes,
                    testTag = "nav_notes",
                    onClick = { onNavigate(Screen.Notes) }
                )
                Spacer(modifier = Modifier.height(12.dp))

                RailIconButton(
                    icon = if (currentScreen is Screen.Library) Icons.Filled.Book else Icons.Outlined.Book,
                    contentDescription = "المكتبة",
                    isSelected = currentScreen is Screen.Library,
                    testTag = "nav_library",
                    onClick = { onNavigate(Screen.Library) }
                )
                Spacer(modifier = Modifier.height(12.dp))

                RailIconButton(
                    icon = Icons.Outlined.FitnessCenter,
                    contentDescription = "الرياضة",
                    isSelected = currentScreen is Screen.Sports,
                    testTag = "nav_sports",
                    onClick = { onNavigate(Screen.Sports) }
                )
            } else {
                // Formatting Tools in Note Editor
                FormattingButton(label = "A", testTag = "format_style") { onFormatAction?.invoke("style") }
                Spacer(modifier = Modifier.height(10.dp))
                FormattingButton(label = "B", isBold = true, testTag = "format_bold") { onFormatAction?.invoke("bold") }
                Spacer(modifier = Modifier.height(10.dp))
                FormattingButton(label = "S", isStrike = true, testTag = "format_strike") { onFormatAction?.invoke("strike") }
                Spacer(modifier = Modifier.height(10.dp))
                FormattingButton(label = "U", isUnderline = true, testTag = "format_underline") { onFormatAction?.invoke("underline") }
                Spacer(modifier = Modifier.height(10.dp))
                FormattingButton(label = "I", isItalic = true, testTag = "format_italic") { onFormatAction?.invoke("italic") }
                Spacer(modifier = Modifier.height(10.dp))
                FormattingButton(label = "H", testTag = "format_heading") { onFormatAction?.invoke("heading") }
            }
        }

        // Bottom Section
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                RailIconButton(
                    icon = Icons.Outlined.CalendarMonth,
                    contentDescription = "التقويم",
                    isSelected = currentScreen is Screen.Calendar,
                    testTag = "nav_calendar",
                    onClick = { onNavigate(Screen.Calendar) }
                )
                Spacer(modifier = Modifier.height(12.dp))
                RailIconButton(
                    icon = Icons.Outlined.Settings,
                    contentDescription = "الإعدادات",
                    isSelected = currentScreen is Screen.Settings,
                    testTag = "nav_settings",
                    onClick = { onNavigate(Screen.Settings) }
                )
            }
        }
    }
}

@Composable
private fun RailIconButton(
    icon: ImageVector,
    contentDescription: String,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val bg = if (isSelected) Color.White.copy(alpha = 0.35f) else Color.Transparent
    val tint = if (isSelected) Color.White else RiwaqRailIconInactive

    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(28.dp)
        )
    }
}

@Composable
private fun FormattingButton(
    label: String,
    testTag: String,
    isBold: Boolean = false,
    isItalic: Boolean = false,
    isUnderline: Boolean = false,
    isStrike: Boolean = false,
    onClick: () -> Unit
) {
    val textDeco = when {
        isUnderline -> TextDecoration.Underline
        isStrike -> TextDecoration.LineThrough
        else -> TextDecoration.None
    }

    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.25f))
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 20.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
            textDecoration = textDeco,
            color = Color.White
        )
    }
}
