package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RiwaqViewModel
import com.example.ui.SeasonData
import com.example.ui.components.FoxEmblem
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqTerracottaHeader
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import kotlinx.coroutines.delay
import java.util.Calendar

@Composable
fun EnthusiasmScreen(
    viewModel: RiwaqViewModel,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.statistics.collectAsStateWithLifecycle()
    val settings by viewModel.appSettings.collectAsStateWithLifecycle()
    val seasonHabits by viewModel.allHabits.collectAsStateWithLifecycle()
    val seasonHabitLogs by viewModel.allHabitLogs.collectAsStateWithLifecycle()
    val seasonTasks by viewModel.allTasks.collectAsStateWithLifecycle()
    val seasonSportPlan by viewModel.sportPlan.collectAsStateWithLifecycle()
    val seasonSportLogs by viewModel.sportPlanLogs.collectAsStateWithLifecycle()

    // Determine current bi-monthly season (1 to 6)
    val currentCalendarMonth = remember { Calendar.getInstance().get(Calendar.MONTH) }
    val currentSeasonNumber = remember(currentCalendarMonth) { (currentCalendarMonth / 2) + 1 }

    // Accordion expansion state: current season open by default
    val expandedSeasons = remember {
        mutableStateMapOf<Int, Boolean>().apply {
            (1..6).forEach { num ->
                this[num] = (num == currentSeasonNumber)
            }
        }
    }

    // Check if the Yesterday's Paper burning ceremony should be displayed today
    val todayDateStr = remember { RiwaqViewModel.getTodayDateString() }
    val alreadyViewedBurnToday = settings.lastEnthusiasmBurnViewedDate == todayDateStr
    var showBurnCeremony by remember { mutableStateOf(!alreadyViewedBurnToday) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 20.dp, bottom = 96.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Large Circular Streak Counter
            item {
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(6.dp, RiwaqBlue, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (stats.enthusiasmStreakDays > 0) "D${stats.enthusiasmStreakDays}" else "D0",
                            fontSize = 56.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = RiwaqTextPrimary
                        )
                    }
                }
            }

            // Days badge pill
            item {
                HabitSeasonsSection(
                    habits = seasonHabits,
                    logs = seasonHabitLogs,
                    tasks = seasonTasks,
                    sportItems = seasonSportPlan,
                    sportLogs = seasonSportLogs,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(12.dp))
                            .padding(horizontal = 18.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${stats.enthusiasmStreakDays} DAYS",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = RiwaqTextPrimary
                        )
                    }

                    if (stats.bestStreakDays > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFFEF3C7))
                                .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(12.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "أفضل رقم: D${stats.bestStreakDays}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E)
                            )
                        }
                    }
                }
            }

            // Discipline rule note
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "قاعدة الحماس: إنجاز 85% أو أكثر من مهام اليوم يضيف يوماً إلى سلسلتك المتتالية.",
                        fontSize = 12.sp,
                        color = RiwaqTextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (stats.taskCompletionRatePercent >= 85 && stats.totalTasksCount > 0)
                            "إنجاز اليوم: ${stats.taskCompletionRatePercent}% — يوم حماس محقق اليوم! ✓"
                        else
                            "إنجاز اليوم الحالي: ${stats.taskCompletionRatePercent}% من 85%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (stats.taskCompletionRatePercent >= 85 && stats.totalTasksCount > 0)
                            RiwaqPriorityGreen
                        else
                            RiwaqTextSecondary
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // ==========================================
            // الفصول الستة (The 6 Seasons of the Year)
            // ==========================================
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "رحلة الفصول الستة",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary
                    )
                }
            }

            val seasons = stats.seasons
            if (seasons.isNotEmpty()) {
                seasons.forEach { season ->
                    item(key = "season_${season.seasonNumber}") {
                        SeasonAccordionCard(
                            season = season,
                            isCurrentSeason = (season.seasonNumber == currentSeasonNumber),
                            isExpanded = expandedSeasons[season.seasonNumber] ?: false,
                            onToggle = {
                                expandedSeasons[season.seasonNumber] = !(expandedSeasons[season.seasonNumber] ?: false)
                            }
                        )
                    }
                }
            } else {
                item {
                    Text(
                        text = "جاري حساب بيانات الفصول الستة...",
                        fontSize = 13.sp,
                        color = RiwaqTextMuted
                    )
                }
            }
        }

        // ==========================================
        // Yesterday's Burning Page Ceremony Overlay
        // ==========================================
        if (showBurnCeremony) {
            YesterdayBurnCeremonyOverlay(
                yesterdayStreak = stats.yesterdayStreakDays,
                onComplete = {
                    showBurnCeremony = false
                    viewModel.markEnthusiasmBurnViewedForToday()
                }
            )
        }
    }
}

/**
 * Calm, symbolic burning ceremony for yesterday's paper.
 * Shown only on first entry to Enthusiasm on that day.
 */
@Composable
private fun YesterdayBurnCeremonyOverlay(
    yesterdayStreak: Int,
    onComplete: () -> Unit
) {
    val burnProgress = remember { Animatable(0f) }
    var ceremonySkipped by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        // Phase 1: Still moment showing yesterday's card clearly
        delay(1100)
        // Phase 2: Gentle peaceful burn transition
        burnProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 2000, easing = LinearEasing)
        )
        // Phase 3: Finish and transition to today
        delay(200)
        if (!ceremonySkipped) {
            onComplete()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable {
                // Tapping anywhere smoothly skips the ceremony
                ceremonySkipped = true
                onComplete()
            },
        contentAlignment = Alignment.Center
    ) {
        val p = burnProgress.value
        val paperAlpha = (1f - p).coerceIn(0f, 1f)
        val upwardShift = (-24 * p).dp

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.offset(y = upwardShift)
        ) {
            Box(
                modifier = Modifier
                    .size(width = 240.dp, height = 310.dp)
                    .alpha(paperAlpha)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFFFFDF8))
                    .border(1.5.dp, Color(0xFFD6C8B5), RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top Paper Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "اليوم السابق",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Serif,
                            color = Color(0xFF786C5E)
                        )
                        FoxEmblem(size = 32.dp)
                    }

                    // Center D-number on the paper
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "D${yesterdayStreak}",
                            fontSize = 62.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            color = Color(0xFF2C241B)
                        )
                        Text(
                            text = "سلسلة أمس",
                            fontSize = 12.sp,
                            color = Color(0xFF8C7E6D),
                            fontFamily = FontFamily.Serif
                        )
                    }

                    // Bottom poetic motto
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "أمس انتهى • الآن يبدأ يومك الجديد",
                            fontSize = 11.sp,
                            color = Color(0xFF786C5E),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Fire & Ember edge canvas drawn over the paper as it burns upward
                if (p > 0.05f) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val burnY = h * (1f - p)

                        // Fiery ember line
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xFFF59E0B).copy(alpha = 0.7f),
                                    Color(0xFFE07A5F).copy(alpha = 0.9f),
                                    Color(0xFF7C2D12)
                                ),
                                startY = burnY - 40f,
                                endY = burnY + 30f
                            ),
                            topLeft = Offset(0f, (burnY - 40f).coerceAtLeast(0f)),
                            size = Size(w, 70f)
                        )

                        // Dissolved charred region
                        drawRect(
                            color = Color(0xFF1C1917).copy(alpha = (p * 0.85f).coerceAtMost(0.95f)),
                            topLeft = Offset(0f, burnY),
                            size = Size(w, h - burnY)
                        )

                        // Gentle glowing spark dots
                        val sparkX1 = w * 0.25f + (p * 20f)
                        val sparkX2 = w * 0.65f - (p * 15f)
                        drawCircle(Color(0xFFFDE047), radius = 3f, center = Offset(sparkX1, burnY - 12f))
                        drawCircle(Color(0xFFF97316), radius = 2.5f, center = Offset(sparkX2, burnY - 18f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "المس الشاشة للمتابعة",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.7f)
            )
        }
    }
}

/**
 * Accordion Card representing one of the 6 Seasons of the Year (Jan+Feb to Nov+Dec).
 */
@Composable
private fun SeasonAccordionCard(
    season: SeasonData,
    isCurrentSeason: Boolean,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(
                width = if (isCurrentSeason) 1.5.dp else 1.dp,
                color = if (isCurrentSeason) RiwaqBlue else RiwaqCardBorder,
                shape = RoundedCornerShape(16.dp)
            )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isCurrentSeason) RiwaqBlue else RiwaqTerracottaHeader)
                    .clickable(onClick = onToggle)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "فتح أو إغلاق الفصل",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (isCurrentSeason) {
                            Text(
                                text = "الفصل الحالي",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.White.copy(alpha = 0.25f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = "الفصل ${season.seasonNumber} — ${season.title}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Body
            AnimatedVisibility(visible = isExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    if (!season.hasData) {
                        Text(
                            text = "لا توجد أنشطة مسجلة في هذا الفصل بعد.",
                            fontSize = 13.sp,
                            color = RiwaqTextMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp)
                        )
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SeasonStatRow(
                                label = "المهام المنجزة في الفصل",
                                value = "${season.completedTasksCount} مهمة"
                            )
                            SeasonStatRow(
                                label = "العادات المنفذة",
                                value = "${season.completedHabitsCount} عادة"
                            )
                            SeasonStatRow(
                                label = "أيام الحماس المحققة (85%+)",
                                value = "${season.enthusiasmDaysCount} يوم"
                            )
                            SeasonStatRow(
                                label = "الكتب المنتهية",
                                value = "${season.completedBooksCount} كتاب"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeasonStatRow(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = RiwaqTextPrimary
        )
        Text(
            text = label,
            fontSize = 13.sp,
            color = RiwaqTextSecondary
        )
    }
}
