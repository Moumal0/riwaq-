package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.TabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.NoteEntity
import com.example.data.model.NoteFolderEntity
import com.example.ui.RiwaqViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.navigation.Screen
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun NotesListPane(
    viewModel: RiwaqViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val notes by viewModel.allNotes.collectAsStateWithLifecycle()
    val folders by viewModel.allFolders.collectAsStateWithLifecycle()
    val selectedFolderId by viewModel.selectedFolderId.collectAsStateWithLifecycle()

    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var folderNameInput by remember { mutableStateOf("") }
    var noteToDelete by remember { mutableStateOf<NoteEntity?>(null) }
    var folderToDelete by remember { mutableStateOf<NoteFolderEntity?>(null) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedTag by remember { mutableStateOf<String?>(null) }

    // وسوم بنمط Obsidian: #وسم
    val tagRegex = remember { Regex("#([\\p{L}\\p{N}_]+)") }
    val linkRegex = remember { Regex("\\[\\[[^\\]|]*\\|(\\d+)\\]\\]") }

    val allTags = remember(notes) {
        notes.flatMap { n -> tagRegex.findAll(n.content).map { it.groupValues[1] }.toList() }
            .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key }
    }
    // الروابط الخلفية: كم ملاحظة تشير إلى هذه الملاحظة عبر [[عنوان|معرف]]
    val backlinkCounts = remember(notes) {
        val map = HashMap<Long, Int>()
        notes.forEach { n ->
            linkRegex.findAll(n.content)
                .mapNotNull { it.groupValues[1].toLongOrNull() }
                .toSet()
                .filter { it != n.id }
                .forEach { target -> map[target] = (map[target] ?: 0) + 1 }
        }
        map
    }

    val filteredNotes = remember(notes, selectedFolderId, searchQuery, selectedTag) {
        val q = searchQuery.trim().lowercase()
        notes.filter { n ->
            (selectedFolderId == null || n.folderId == selectedFolderId) &&
                (q.isEmpty() || n.title.lowercase().contains(q) || n.content.lowercase().contains(q)) &&
                (selectedTag == null || n.content.contains("#" + selectedTag))
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showCreateFolderDialog = true }) {
                        Icon(imageVector = Icons.Default.CreateNewFolder, contentDescription = null, tint = RiwaqBlue)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "مجلد جديد", color = RiwaqBlue)
                    }
                    Text(
                        text = "الملاحظات",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = RiwaqTextPrimary
                    )
                }
            }

            // Search (Obsidian-style quick search)
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث في الملاحظات...", color = RiwaqTextMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = RiwaqTextMuted) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Tags
            if (allTags.isNotEmpty()) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(allTags, key = { "tag_$it" }) { tag ->
                            val sel = selectedTag == tag
                            Text(
                                text = "#$tag",
                                fontSize = 12.sp,
                                color = if (sel) Color.White else RiwaqBlue,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (sel) RiwaqBlue else Color(0xFFE8F0FE))
                                    .clickable { selectedTag = if (sel) null else tag }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            // Folders Horizontal List
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // "All" chip
                    item {
                        FolderChip(
                            name = "الكل",
                            isSelected = selectedFolderId == null,
                            onClick = { viewModel.selectFolder(null) },
                            onLongClick = {}
                        )
                    }
                    items(folders, key = { "folder_${it.id}" }) { folder ->
                        FolderChip(
                            name = folder.name,
                            isSelected = selectedFolderId == folder.id,
                            onClick = { viewModel.selectFolder(folder.id) },
                            onLongClick = { folderToDelete = folder }
                        )
                    }
                }
            }

            // Notes List
            if (filteredNotes.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "لا توجد ملاحظات هنا",
                        subtitle = "اضغط على زر (+) لتدوين ملاحظة جديدة"
                    )
                }
            } else {
                items(filteredNotes, key = { "note_${it.id}" }) { note ->
                    NoteItemCard(
                        note = note,
                        folderName = folders.find { it.id == note.folderId }?.name,
                        backlinks = backlinkCounts[note.id] ?: 0,
                        onClick = { onNavigate(Screen.NoteEditor(note.id, note.folderId)) },
                        onDelete = { noteToDelete = note }
                    )
                }
            }
        }

        // Floating Action Button (+)
        FloatingActionButton(
            onClick = { onNavigate(Screen.NoteEditor(0, selectedFolderId)) },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
                .testTag("add_note_fab"),
            containerColor = Color.White,
            contentColor = RiwaqBlue,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "كتابة ملاحظة جديدة",
                modifier = Modifier.size(28.dp)
            )
        }

        // Create Folder Dialog
        if (showCreateFolderDialog) {
            AlertDialog(
                onDismissRequest = {
                    showCreateFolderDialog = false
                    folderNameInput = ""
                },
                title = { Text("إنشاء مجلد جديد") },
                text = {
                    OutlinedTextField(
                        value = folderNameInput,
                        onValueChange = { folderNameInput = it },
                        placeholder = { Text("اسم المجلد...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (folderNameInput.isNotBlank()) {
                            viewModel.createFolder(folderNameInput)
                            showCreateFolderDialog = false
                            folderNameInput = ""
                        }
                    }) {
                        Text("إنشاء", color = RiwaqBlue)
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showCreateFolderDialog = false
                        folderNameInput = ""
                    }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // Delete Note Confirmation
        if (noteToDelete != null) {
            AlertDialog(
                onDismissRequest = { noteToDelete = null },
                title = { Text("حذف الملاحظة") },
                text = { Text("هل أنت متأكد من رغبتك في حذف '${noteToDelete?.title}'؟") },
                confirmButton = {
                    TextButton(onClick = {
                        noteToDelete?.let { viewModel.deleteNote(it) }
                        noteToDelete = null
                    }) {
                        Text("حذف", color = RiwaqPriorityRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { noteToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // Delete Folder Confirmation
        if (folderToDelete != null) {
            AlertDialog(
                onDismissRequest = { folderToDelete = null },
                title = { Text("حذف المجلد") },
                text = { Text("هل تريد حذف مجلد '${folderToDelete?.name}'؟ الملاحظات داخله لن تُحذف.") },
                confirmButton = {
                    TextButton(onClick = {
                        folderToDelete?.let { viewModel.deleteFolder(it) }
                        folderToDelete = null
                    }) {
                        Text("حذف", color = RiwaqPriorityRed)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { folderToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun FolderChip(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) RiwaqBlue else Color.White)
            .border(1.dp, if (isSelected) RiwaqBlue else RiwaqCardBorder, RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = if (isSelected) Icons.Filled.Folder else Icons.Outlined.Folder,
            contentDescription = null,
            tint = if (isSelected) Color.White else RiwaqBlue,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = name,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else RiwaqTextPrimary
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun NoteItemCard(
    note: NoteEntity,
    folderName: String?,
    backlinks: Int,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val dateStr = remember(note.updatedAtMillis) {
        SimpleDateFormat("yyyy/MM/dd", Locale("ar")).format(Date(note.updatedAtMillis))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onDelete
            )
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = dateStr,
                    fontSize = 11.sp,
                    color = RiwaqTextMuted
                )
                Text(
                    text = note.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = RiwaqTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (note.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = note.content,
                    fontSize = 13.sp,
                    color = RiwaqTextSecondary,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (folderName != null || backlinks > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End)
                ) {
                    if (backlinks > 0) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFE8F0FE))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(text = "↩ $backlinks", fontSize = 11.sp, color = RiwaqBlue)
                        }
                    }
                    if (folderName != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFF1F5F9))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(text = folderName, fontSize = 11.sp, color = RiwaqTextSecondary)
                    }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(
    viewModel: RiwaqViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    var tab by remember { mutableStateOf(0) }
    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = RiwaqBlue) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("الملاحظات") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("المحادثات") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("الرسم") })
        }
        if (tab == 0) {
            NotesListPane(
                viewModel = viewModel,
                onNavigate = onNavigate,
                modifier = Modifier.weight(1f)
            )
        } else if (tab == 2) {
            NotesGraphPane(viewModel = viewModel, onNavigate = onNavigate, modifier = Modifier.weight(1f))
        } else {
            ChatsPanel(viewModel = viewModel, modifier = Modifier.weight(1f))
        }
    }
}
