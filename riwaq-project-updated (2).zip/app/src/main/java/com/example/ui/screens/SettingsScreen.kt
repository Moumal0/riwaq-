package com.example.ui.screens

import android.graphics.Color as AndroidColor
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.rememberAsyncImagePainter
import com.example.data.model.AppSettings
import com.example.data.model.ImportSummary
import com.example.data.BackupPasswordRequiredException
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.example.data.model.RiwaqBackupData
import com.example.ui.RiwaqViewModel
import com.example.ui.components.ColorPickerWithPresetsRow
import com.example.ui.components.FoxEmblem
import com.example.ui.components.parseHexColor
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Restore
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqCardBorder
import com.example.ui.theme.RiwaqPriorityGreen
import com.example.ui.theme.RiwaqPriorityOrange
import com.example.ui.theme.RiwaqPriorityRed
import com.example.ui.theme.RiwaqTextMuted
import com.example.ui.theme.RiwaqTextPrimary
import com.example.ui.theme.RiwaqTextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    viewModel: RiwaqViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val settings by viewModel.appSettings.collectAsStateWithLifecycle()

    var isExporting by remember { mutableStateOf(false) }
    var isImporting by remember { mutableStateOf(false) }
    var inspectionResult by remember { mutableStateOf<RiwaqBackupData?>(null) }
    var showImportConfirmDialog by remember { mutableStateOf(false) }
    var importErrorMessage by remember { mutableStateOf<String?>(null) }
    var importSuccessSummary by remember { mutableStateOf<ImportSummary?>(null) }

    // Clear Data Dialog States
    var showFirstClearWarning by remember { mutableStateOf(false) }
    var showSecondClearConfirmation by remember { mutableStateOf(false) }

    // Encrypted backup states
    var showExportPasswordDialog by remember { mutableStateOf(false) }
    var exportPassword by remember { mutableStateOf("") }
    var exportPasswordConfirm by remember { mutableStateOf("") }
    var pendingExportPassword by remember { mutableStateOf<String?>(null) }
    var showImportPasswordDialog by remember { mutableStateOf(false) }
    var importPassword by remember { mutableStateOf("") }
    var pendingImportBytes by remember { mutableStateOf<ByteArray?>(null) }

    // Encrypted export launcher
    val exportDocxLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val password = pendingExportPassword
        pendingExportPassword = null
        if (uri != null && password != null) {
            isExporting = true
            coroutineScope.launch {
                try {
                    val outputStream = context.contentResolver.openOutputStream(uri)
                    if (outputStream != null) {
                        val result = withContext(Dispatchers.IO) {
                            outputStream.use { stream ->
                                viewModel.exportBackup(stream, password)
                            }
                        }
                        if (result.isSuccess) {
                            Toast.makeText(context, "تم تصدير نسخة مشفّرة بنجاح. احتفظ برمز المرور!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "فشل التصدير: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "خطأ أثناء التصدير: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    isExporting = false
                }
            }
        }
    }

    // Import launcher (encrypted .riwaq or legacy .docx)
    val importDocxLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            isImporting = true
            coroutineScope.launch {
                try {
                    val bytes = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    }
                    if (bytes != null) {
                        val result = viewModel.inspectBackupBytes(bytes, null)
                        result.onSuccess { data ->
                            inspectionResult = data
                            showImportConfirmDialog = true
                        }.onFailure { err ->
                            if (err is BackupPasswordRequiredException) {
                                pendingImportBytes = bytes
                                importPassword = ""
                                showImportPasswordDialog = true
                            } else {
                                importErrorMessage = err.message ?: "ملف النسخة الاحتياطية غير صالح"
                            }
                        }
                    }
                } catch (e: Exception) {
                    importErrorMessage = "تعذر قراءة الملف: ${e.message}"
                } finally {
                    isImporting = false
                }
            }
        }
    }

    // Calendar Custom Image Launcher
    val calendarImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setCalendarCustomImage(uri)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = "الإعدادات",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = RiwaqTextPrimary
                )
            }
        }

        // Branding Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.White)
                    .border(1.dp, RiwaqCardBorder, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "رِواق — Riwaq",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = RiwaqTextPrimary
                        )
                        Text(
                            text = "تطبيق شخصي موحد لإدارة الحياة اليومية",
                            fontSize = 12.sp,
                            color = RiwaqTextSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الإصدار 1.0 • يعمل محلياً 100% بدون إنترنت",
                            fontSize = 11.sp,
                            color = RiwaqBlue
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    FoxEmblem(size = 54.dp)
                }
            }
        }

        // ==========================================
        // 1. المظهر (Appearance)
        // ==========================================
        item {
            SettingsSectionHeader(title = "المظهر والتخصيص")
        }

        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    ThemePresetsRow(settings = settings, onApply = { viewModel.updateSettings(it) })
                    FontCustomization(settings = settings, onChange = { viewModel.updateSettings(it) })

                    // اللون الرئيسي للتطبيق
                    ColorPickerWithPresetsRow(
                        title = "اللون الرئيسي للتطبيق",
                        selectedHex = settings.primaryColorHex,
                        presets = listOf(
                            "#3B82F6" to "أزرق رِواق",
                            "#4F46E5" to "نيلي ملكي",
                            "#0D9488" to "تركواز هادئ",
                            "#475569" to "رمادي أردوازي",
                            "#059669" to "أخضر زمردي",
                            "#D97706" to "كهرماني دافئ"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(primaryColorHex = it)) }
                    )

                    // لون الخلفية
                    ColorPickerWithPresetsRow(
                        title = "لون الخلفية",
                        selectedHex = settings.backgroundColorHex,
                        presets = listOf(
                            "#F8FAFC" to "أبيض ناصع",
                            "#FDFBF7" to "ورق دافئ",
                            "#F1F5F9" to "رمادي جليدي",
                            "#EFF6FF" to "أزرق خافت"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(backgroundColorHex = it)) }
                    )

                    // لون الشريط الجانبي
                    ColorPickerWithPresetsRow(
                        title = "لون الشريط الجانبي",
                        selectedHex = settings.sidebarColorHex,
                        presets = listOf(
                            "#92B4F8" to "أزرق كلاسيكي",
                            "#7DD3FC" to "سماوي صافٍ",
                            "#A5B4FC" to "لافندر هادئ",
                            "#64748B" to "رمادي غامق",
                            "#86EFAC" to "نعناعي فاتح"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(sidebarColorHex = it)) }
                    )

                    // حجم الشريط الجانبي
                    Text(text = "حجم الشريط الجانبي", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = RiwaqTextPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(52 to "مدمج (52dp)", 64 to "عادي (64dp)", 76 to "عريض (76dp)").forEach { (width, label) ->
                            FilterChip(
                                selected = settings.sidebarWidthDp == width,
                                onClick = { viewModel.updateSettings(settings.copy(sidebarWidthDp = width)) },
                                label = { Text(label) }
                            )
                        }
                    }

                    // موضع الشريط الجانبي
                    Text(text = "موضع الشريط الجانبي", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = RiwaqTextPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = settings.sidebarPosition == "RIGHT",
                            onClick = { viewModel.updateSettings(settings.copy(sidebarPosition = "RIGHT")) },
                            label = { Text("يمين (الافتراضي للعربية)") }
                        )
                        FilterChip(
                            selected = settings.sidebarPosition == "LEFT",
                            onClick = { viewModel.updateSettings(settings.copy(sidebarPosition = "LEFT")) },
                            label = { Text("يسار") }
                        )
                    }

                    // اللغة
                    Text(text = "اللغة", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = RiwaqTextPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = settings.language == "AR",
                            onClick = { viewModel.updateSettings(settings.copy(language = "AR")) },
                            label = { Text("العربية (RTL)") }
                        )
                        FilterChip(
                            selected = settings.language == "EN",
                            onClick = { viewModel.updateSettings(settings.copy(language = "EN")) },
                            label = { Text("English (LTR)") }
                        )
                    }
                }
            }
        }

        // ==========================================
        // 2. المكتبة (Library)
        // ==========================================
        item {
            SettingsSectionHeader(title = "إعدادات الأقسام")
        }

        item {
            SettingsCard {
                SectionSettingsCard(viewModel = viewModel)
            }
        }

        item {
            SettingsSectionHeader(title = "المكتبة")
        }

        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "اتجاه عرض الكتب",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = RiwaqTextPrimary
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = settings.libraryDisplayDirection == "VERTICAL",
                            onClick = { viewModel.updateSettings(settings.copy(libraryDisplayDirection = "VERTICAL")) },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ViewModule, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("عمودي (شبكة ثلاثية)")
                                }
                            }
                        )
                        FilterChip(
                            selected = settings.libraryDisplayDirection == "HORIZONTAL",
                            onClick = { viewModel.updateSettings(settings.copy(libraryDisplayDirection = "HORIZONTAL")) },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ViewCarousel, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("أفقي (أرفف أفقية)")
                                }
                            }
                        )
                    }
                }
            }
        }

        // ==========================================
        // 3. التقويم (Calendar Customization with Live Preview & Wheel Pickers)
        // ==========================================
        item {
            SettingsSectionHeader(title = "تخصيص التقويم (معاينة حية ومحرر ألوان)")
        }

        item {
            SettingsCard {
                CalendarPresetsRow(settings = settings, onApply = { viewModel.updateSettings(it) })
            }
        }

        // Live Calendar Preview Card
        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "معاينة مباشرة للتغييرات",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = RiwaqBlue
                        )
                        Text(
                            text = "شكل التقويم الحالي",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = RiwaqTextPrimary
                        )
                    }

                    // Mini live calendar preview rendering with user's actual chosen colors
                    val previewBoxColor = remember(settings.calendarBoxColorHex) { parseHexColor(settings.calendarBoxColorHex, Color.White) }
                    val previewHeaderColor = remember(settings.calendarHeaderColorHex) { parseHexColor(settings.calendarHeaderColorHex, RiwaqBlue) }
                    val previewCellsColor = remember(settings.calendarCellsColorHex) { parseHexColor(settings.calendarCellsColorHex, Color(0xFFE8F0FE)) }
                    val previewDividersColor = remember(settings.calendarDividersColorHex) { parseHexColor(settings.calendarDividersColorHex, RiwaqCardBorder) }
                    val previewTextColor = remember(settings.calendarTextColorHex) { parseHexColor(settings.calendarTextColorHex, RiwaqTextPrimary) }
                    val previewEventColor = remember(settings.calendarEventColorHex) { parseHexColor(settings.calendarEventColorHex, Color(0xFFE07A5F)) }

                    // Header in preview: month name + custom avatar badge + year
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(previewBoxColor)
                            .border(1.dp, previewDividersColor, RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "October", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = previewTextColor)
                        // Circular avatar / image
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE89F22))
                                .border(1.dp, previewDividersColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (settings.calendarCustomImagePath != null && File(settings.calendarCustomImagePath!!).exists()) {
                                Image(
                                    painter = rememberAsyncImagePainter(File(settings.calendarCustomImagePath!!)),
                                    contentDescription = "صورة التقويم",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                FoxEmblem(size = 28.dp)
                            }
                        }
                        Text(text = "2026", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = previewTextColor)
                    }

                    // Live Calendar Grid using the same component
                    CalendarGrid(
                        year = 2026,
                        month = 9, // October
                        selectedDate = "2026-10-15",
                        events = emptyList(),
                        boxColor = previewBoxColor,
                        headerColor = previewHeaderColor,
                        cellsColor = previewCellsColor,
                        dividersColor = previewDividersColor,
                        textColor = previewTextColor,
                        eventColor = previewEventColor,
                        onSelectDate = {}
                    )
                }
            }
        }

        // Color Customization Controls with Full Color Wheel Support
        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // لون مربع / خلفية التقويم
                    ColorPickerWithPresetsRow(
                        title = "لون خلفية بطاقة التقويم",
                        selectedHex = settings.calendarBoxColorHex,
                        presets = listOf(
                            "#FFFFFF" to "أبيض ناصع",
                            "#F8FAFC" to "رمادي فاتح",
                            "#EFF6FF" to "أزرق ثلجي",
                            "#FDFBF7" to "ورق كريمي",
                            "#F1F5F9" to "رمادي أردوازي"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(calendarBoxColorHex = it)) }
                    )

                    // لون أسماء أيام الأسبوع
                    ColorPickerWithPresetsRow(
                        title = "لون أسماء أيام الأسبوع",
                        selectedHex = settings.calendarHeaderColorHex,
                        presets = listOf(
                            "#3B82F6" to "أزرق رِواق",
                            "#1E293B" to "كحلي داكن",
                            "#4F46E5" to "نيلي ملكي",
                            "#0D9488" to "تركواز",
                            "#D97706" to "كهرماني"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(calendarHeaderColorHex = it)) }
                    )

                    // لون خلايا الأيام
                    ColorPickerWithPresetsRow(
                        title = "لون خلايا الأيام العادية",
                        selectedHex = settings.calendarCellsColorHex,
                        presets = listOf(
                            "#E8F0FE" to "أزرق هادئ",
                            "#F1F5F9" to "رمادي فاتح",
                            "#FEF3C7" to "أصفر هادئ",
                            "#DCFCE7" to "أخضر فاتح",
                            "#FCE7F3" to "وردي خافت"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(calendarCellsColorHex = it)) }
                    )

                    // لون الفواصل والحدود
                    ColorPickerWithPresetsRow(
                        title = "لون الفواصل والحدود",
                        selectedHex = settings.calendarDividersColorHex,
                        presets = listOf(
                            "#E2E8F0" to "رمادي فاتح",
                            "#CBD5E1" to "رمادي متوسط",
                            "#BFDBFE" to "أزرق رقيق",
                            "#D1D5DB" to "كلاسيكي",
                            "#94A3B8" to "فضي"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(calendarDividersColorHex = it)) }
                    )

                    // لون النصوص داخل التقويم
                    ColorPickerWithPresetsRow(
                        title = "لون نصوص الأرقام",
                        selectedHex = settings.calendarTextColorHex,
                        presets = listOf(
                            "#1E293B" to "كحلي داكن",
                            "#0F172A" to "أسود ناعم",
                            "#334155" to "رمادي فحمي",
                            "#1E3A8A" to "أزرق داكن",
                            "#14532D" to "أخضر داكن"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(calendarTextColorHex = it)) }
                    )

                    // لون أيقونات وعناصر الأحداث
                    ColorPickerWithPresetsRow(
                        title = "لون عناصر الأحداث (الهدية والوسوم)",
                        selectedHex = settings.calendarEventColorHex,
                        presets = listOf(
                            "#E07A5F" to "برتقالي هادئ",
                            "#EF4444" to "أحمر نابض",
                            "#F59E0B" to "ذهبي",
                            "#8B5CF6" to "بنفسجي",
                            "#10B981" to "زمردي"
                        ),
                        onColorSelected = { viewModel.updateSettings(settings.copy(calendarEventColorHex = it)) }
                    )

                    // الصورة الدائرية فوق التقويم
                    Text(text = "الصورة الدائرية فوق التقويم", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = RiwaqTextPrimary)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE89F22))
                                    .border(1.dp, RiwaqCardBorder, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (settings.calendarCustomImagePath != null && File(settings.calendarCustomImagePath!!).exists()) {
                                    Image(
                                        painter = rememberAsyncImagePainter(File(settings.calendarCustomImagePath!!)),
                                        contentDescription = "صورة التقويم المخصصة",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    FoxEmblem(size = 42.dp)
                                }
                            }

                            Column {
                                Text(
                                    text = if (settings.calendarCustomImagePath != null) "صورة مخصصة من جهازك" else "شعار الثعلب الافتراضي",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = RiwaqTextPrimary
                                )
                                Text(
                                    text = "تُعرض في أعلى التقويم بين الشهر والسنة وتُحفظ دائماً",
                                    fontSize = 11.sp,
                                    color = RiwaqTextMuted
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = {
                                    calendarImagePicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            ) {
                                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تغيير", fontSize = 12.sp)
                            }

                            if (settings.calendarCustomImagePath != null) {
                                TextButton(onClick = { viewModel.resetCalendarCustomImage() }) {
                                    Text("استعادة", color = RiwaqPriorityRed, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 4. الإشعارات (Notifications)
        // ==========================================
        item {
            SettingsSectionHeader(title = "الإشعارات والتذكير")
        }

        item {
            SettingsCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    NotificationToggleItem(
                        title = "تذكير المهام اليومية",
                        subtitle = "تنبيهك بالمهام المستحقة خلال اليوم",
                        isChecked = settings.notificationsTaskReminders,
                        onCheckedChange = { viewModel.updateSettings(settings.copy(notificationsTaskReminders = it)) }
                    )
                    NotificationToggleItem(
                        title = "تذكير الالتزام بالعادات",
                        subtitle = "تذكير لتسجيل تقدم العادات في وقتها",
                        isChecked = settings.notificationsHabitReminders,
                        onCheckedChange = { viewModel.updateSettings(settings.copy(notificationsHabitReminders = it)) }
                    )
                    NotificationToggleItem(
                        title = "تنبيه أيام الحماس (85%+)",
                        subtitle = "إشعار عند اقترابك أو تحقيقك لنسبة 85% لليوم",
                        isChecked = settings.notificationsEnthusiasmReminders,
                        onCheckedChange = { viewModel.updateSettings(settings.copy(notificationsEnthusiasmReminders = it)) }
                    )
                    NotificationToggleItem(
                        title = "الملخص والتقرير المسائي",
                        subtitle = "ملخص يومي بإنجازاتك ونشاطك",
                        isChecked = settings.notificationsDailyReminders,
                        onCheckedChange = { viewModel.updateSettings(settings.copy(notificationsDailyReminders = it)) }
                    )
                }
            }
        }

        // ==========================================
        // 5. التخزين وإدارة البيانات (Storage)
        // ==========================================
        item {
            SettingsSectionHeader(title = "التخزين والبيانات")
        }

        // Export to DOCX
        item {
            SettingsActionCard(
                title = "تصدير نسخة احتياطية مشفّرة",
                subtitle = "ملف مشفّر بـ AES-256 لا يمكن قراءته أو فتحه دون رمز المرور الذي تختاره",
                icon = Icons.Default.CloudUpload,
                isLoading = isExporting,
                onClick = {
                    exportPassword = ""
                    exportPasswordConfirm = ""
                    showExportPasswordDialog = true
                }
            )
        }

        // Import from DOCX
        item {
            SettingsActionCard(
                title = "استيراد نسخة احتياطية",
                subtitle = "استعادة بياناتك من ملف .riwaq (سيُطلب رمز المرور) أو من ملف DOCX قديم",
                icon = Icons.Default.CloudDownload,
                isLoading = isImporting,
                onClick = {
                    importDocxLauncher.launch(
                        arrayOf(
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/msword",
                            "application/octet-stream"
                        )
                    )
                }
            )
        }

        // Clear All Data
        item {
            SettingsActionCard(
                title = "مسح جميع البيانات",
                subtitle = "حذف كافة المهام والعادات والملاحظات والكتب وسجلات الحماس والبدء من الصفر",
                icon = Icons.Default.DeleteForever,
                iconTint = RiwaqPriorityRed,
                isLoading = false,
                onClick = { showFirstClearWarning = true }
            )
        }
    }

    // ==========================================
    // Dialogs & Confirmations
    // ==========================================

    // First Clear Data Warning Dialog
    if (showFirstClearWarning) {
        AlertDialog(
            onDismissRequest = { showFirstClearWarning = false },
            title = { Text("تحذير: مسح جميع البيانات", color = RiwaqPriorityRed) },
            text = {
                Text(
                    "هل أنت متأكد من رغبتك في مسح كافة البيانات؟ سيؤدي هذا الإجراء إلى حذف جميع المهام، العادات، الكتب، الملاحظات، وسجلات الحماس نهائياً من جهازك."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showFirstClearWarning = false
                    showSecondClearConfirmation = true
                }) {
                    Text("متابعة المسح", color = RiwaqPriorityRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFirstClearWarning = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Second Clear Data Confirmation Dialog
    if (showSecondClearConfirmation) {
        AlertDialog(
            onDismissRequest = { showSecondClearConfirmation = false },
            title = { Text("تأكيد نهائي وحاسم", color = RiwaqPriorityRed) },
            text = {
                Text(
                    "لا يمكن التراجع عن هذه الخطوة إطلاقاً! هل توافق على مسح كامل قاعدة البيانات وملفات الكتب الآن؟"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showSecondClearConfirmation = false
                    viewModel.clearAllUserData {
                        Toast.makeText(context, "تم مسح كافة البيانات والبدء من الصفر", Toast.LENGTH_LONG).show()
                    }
                }) {
                    Text("نعم، احذف كل شيء", color = RiwaqPriorityRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSecondClearConfirmation = false }) {
                    Text("تراجع")
                }
            }
        )
    }

    // Import Confirmation Dialog (Replace vs Merge)
    if (showImportConfirmDialog && inspectionResult != null) {
        val data = inspectionResult!!
        AlertDialog(
            onDismissRequest = {
                showImportConfirmDialog = false
                inspectionResult = null
            },
            title = { Text("تأكيد استيراد البيانات") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "عُثر على نسخة احتياطية صادرة في: ${data.exportDate}")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "• ${data.tasks.size} مهمة")
                    Text(text = "• ${data.habits.size} عادة")
                    Text(text = "• ${data.notes.size} ملاحظة")
                    Text(text = "• ${data.books.size} كتاب")
                    Text(text = "• ${data.calendarEvents.size} حدث في التقويم")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "اختر كيفية استعادة البيانات:")
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        showImportConfirmDialog = false
                        viewModel.restoreBackupData(data, replaceExisting = false) { summary ->
                            importSuccessSummary = summary
                        }
                        inspectionResult = null
                    }) {
                        Text("دمج البيانات", color = RiwaqBlue)
                    }
                    TextButton(onClick = {
                        showImportConfirmDialog = false
                        viewModel.restoreBackupData(data, replaceExisting = true) { summary ->
                            importSuccessSummary = summary
                        }
                        inspectionResult = null
                    }) {
                        Text("استبدال البيانات", color = RiwaqPriorityRed)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showImportConfirmDialog = false
                    inspectionResult = null
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showExportPasswordDialog) {
        val tooShort = exportPassword.length < 6
        val mismatch = exportPassword != exportPasswordConfirm
        AlertDialog(
            onDismissRequest = { showExportPasswordDialog = false },
            title = { Text("حماية النسخة برمز مرور") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("اختر رمز مرور (6 أحرف على الأقل). ستحتاجه عند الاستيراد على أي جهاز، ولا يمكن استرجاع الملف إن نسيته.")
                    OutlinedTextField(
                        value = exportPassword,
                        onValueChange = { exportPassword = it },
                        label = { Text("رمز المرور") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    OutlinedTextField(
                        value = exportPasswordConfirm,
                        onValueChange = { exportPasswordConfirm = it },
                        label = { Text("تأكيد الرمز") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    if (exportPasswordConfirm.isNotEmpty() && mismatch) {
                        Text("الرمزان غير متطابقين", color = RiwaqPriorityRed)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !tooShort && !mismatch,
                    onClick = {
                        pendingExportPassword = exportPassword
                        showExportPasswordDialog = false
                        val dateSuffix = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
                        exportDocxLauncher.launch("Riwaq_Backup_$dateSuffix.riwaq")
                    }
                ) { Text("متابعة", color = RiwaqBlue) }
            },
            dismissButton = { TextButton(onClick = { showExportPasswordDialog = false }) { Text("إلغاء") } }
        )
    }

    if (showImportPasswordDialog) {
        AlertDialog(
            onDismissRequest = { showImportPasswordDialog = false; pendingImportBytes = null },
            title = { Text("الملف مشفّر") },
            text = {
                OutlinedTextField(
                    value = importPassword,
                    onValueChange = { importPassword = it },
                    label = { Text("رمز المرور") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val bytes = pendingImportBytes
                    val pw = importPassword
                    showImportPasswordDialog = false
                    if (bytes != null) {
                        coroutineScope.launch {
                            viewModel.inspectBackupBytes(bytes, pw)
                                .onSuccess { data ->
                                    pendingImportBytes = null
                                    inspectionResult = data
                                    showImportConfirmDialog = true
                                }
                                .onFailure { err ->
                                    pendingImportBytes = null
                                    importErrorMessage = err.message ?: "رمز المرور غير صحيح"
                                }
                        }
                    }
                }) { Text("فتح", color = RiwaqBlue) }
            },
            dismissButton = {
                TextButton(onClick = { showImportPasswordDialog = false; pendingImportBytes = null }) { Text("إلغاء") }
            }
        )
    }

    // Error Dialog
    if (importErrorMessage != null) {
        AlertDialog(
            onDismissRequest = { importErrorMessage = null },
            title = { Text("خطأ في الاستيراد") },
            text = { Text(importErrorMessage!!) },
            confirmButton = {
                TextButton(onClick = { importErrorMessage = null }) {
                    Text("حسناً")
                }
            }
        )
    }

    // Success Summary Dialog
    if (importSuccessSummary != null) {
        val s = importSuccessSummary!!
        AlertDialog(
            onDismissRequest = { importSuccessSummary = null },
            title = { Text("اكتمل الاستيراد بنجاح") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تم استيراد:")
                    Text("• ${s.tasksCount} مهمة")
                    Text("• ${s.habitsCount} عادات")
                    Text("• ${s.notesCount} ملاحظات")
                    Text("• ${s.booksCount} كتب")
                    Text("• ${s.eventsCount} حدثاً")
                }
            },
            confirmButton = {
                TextButton(onClick = { importSuccessSummary = null }) {
                    Text("تم", color = RiwaqBlue)
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = RiwaqTextPrimary
        )
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
private fun ColorPaletteRow(
    selectedHex: String,
    colors: List<Pair<String, String>>,
    onSelect: (String) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 4.dp)
    ) {
        items(colors) { (hex, name) ->
            val isSelected = selectedHex.equals(hex, ignoreCase = true)
            val color = try { Color(AndroidColor.parseColor(hex)) } catch (_: Exception) { Color.Gray }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelect(hex) }
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(color)
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) RiwaqBlue else RiwaqCardBorder,
                            shape = CircleShape
                        )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = name,
                    fontSize = 10.sp,
                    color = if (isSelected) RiwaqBlue else RiwaqTextSecondary,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun NotificationToggleItem(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = RiwaqBlue
            )
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 12.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = RiwaqTextPrimary)
            Text(text = subtitle, fontSize = 11.sp, color = RiwaqTextSecondary)
        }
    }
}

@Composable
private fun SettingsActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isLoading: Boolean,
    iconTint: Color = RiwaqBlue,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, RiwaqCardBorder, RoundedCornerShape(16.dp))
            .clickable(enabled = !isLoading, onClick = onClick)
            .padding(16.dp)
            .testTag("settings_action_${title.take(6)}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = RiwaqBlue)
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = RiwaqTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = RiwaqTextSecondary
                )
            }
        }
    }
}
