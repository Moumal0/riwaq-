package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.RiwaqViewModel
import com.example.ui.components.RiwaqSideRail
import com.example.ui.navigation.Screen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.EnthusiasmScreen
import com.example.ui.screens.HabitsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.NoteEditorScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.PdfReaderScreen
import com.example.ui.screens.SportsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.theme.RiwaqBg
import com.example.ui.theme.RiwaqBlue
import com.example.ui.theme.RiwaqRailBg
import com.example.ui.theme.RiwaqTheme

class MainActivity : ComponentActivity() {

    private val viewModel: RiwaqViewModel by viewModels()

    private var unlocked by androidx.compose.runtime.mutableStateOf(false)

    private val lockLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == RESULT_OK) unlocked = true else finish() }

    private fun requestUnlockIfNeeded() {
        val enabled = getSharedPreferences("riwaq_lock", MODE_PRIVATE).getBoolean("enabled", false)
        val km = getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        if (!enabled || !km.isDeviceSecure) { unlocked = true; return }
        @Suppress("DEPRECATION")
        val intent = km.createConfirmDeviceCredentialIntent("رِواق", "أكّد هويتك لفتح التطبيق")
        if (intent == null) unlocked = true else lockLauncher.launch(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) requestUnlockIfNeeded() else unlocked = true
        setContent {
            val settings by viewModel.appSettings.collectAsStateWithLifecycle()

            val primaryColor = remember(settings.primaryColorHex) {
                try { Color(AndroidColor.parseColor(settings.primaryColorHex)) } catch (_: Exception) { RiwaqBlue }
            }
            val backgroundColor = remember(settings.backgroundColorHex) {
                try { Color(AndroidColor.parseColor(settings.backgroundColorHex)) } catch (_: Exception) { RiwaqBg }
            }

            // اللون المميز الديناميكي (يُطبَّق قبل رسم الواجهة)
            remember(primaryColor) { com.example.ui.theme.ThemeState.accent = primaryColor; 0 }

            val baseDensity = androidx.compose.ui.platform.LocalDensity.current
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(
                    baseDensity.density,
                    baseDensity.fontScale * settings.fontScale
                )
            ) {
                RiwaqTheme(
                    customPrimary = primaryColor,
                    customBackground = backgroundColor,
                    monoFont = settings.monoFont
                ) {
                    if (unlocked) RiwaqMainApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun RiwaqMainApp(viewModel: RiwaqViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val settings by viewModel.appSettings.collectAsStateWithLifecycle()

    val backgroundColor = remember(settings.backgroundColorHex) {
        try { Color(AndroidColor.parseColor(settings.backgroundColorHex)) } catch (_: Exception) { RiwaqBg }
    }
    val sidebarColor = remember(settings.sidebarColorHex) {
        try { Color(AndroidColor.parseColor(settings.sidebarColorHex)) } catch (_: Exception) { RiwaqRailBg }
    }

    val isArabic = settings.language == "AR"
    val contentDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
    val isRailOnRight = settings.sidebarPosition == "RIGHT"

    var formatActionTrigger by remember { mutableStateOf<String?>(null) }

    // Display user messages
    LaunchedEffect(Unit) {
        viewModel.userMessage.collect { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }

    // Handle back button
    BackHandler(enabled = currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = backgroundColor
    ) { innerPadding ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(backgroundColor)
            ) {
                // If rail on left
                if (!isRailOnRight && currentScreen !is Screen.PdfReader) {
                    RiwaqSideRail(
                        currentScreen = currentScreen,
                        sidebarColor = sidebarColor,
                        widthDp = settings.sidebarWidthDp,
                        onNavigate = { viewModel.navigateTo(it) },
                        onFoxClick = { viewModel.navigateTo(Screen.Enthusiasm) },
                        onFormatAction = { action -> formatActionTrigger = action }
                    )
                }

                // Main Content Area
                CompositionLocalProvider(LocalLayoutDirection provides contentDirection) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                    ) {
                        when (val screen = currentScreen) {
                            is Screen.Home -> {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                            is Screen.Habits -> {
                                HabitsScreen(viewModel = viewModel)
                            }
                            is Screen.Tasks -> {
                                TasksScreen(viewModel = viewModel)
                            }
                            is Screen.Notes -> {
                                NotesScreen(
                                    viewModel = viewModel,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                            is Screen.NoteEditor -> {
                                NoteEditorScreen(
                                    noteId = screen.noteId,
                                    initialFolderId = screen.folderId,
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() },
                                    onNavigateToScreen = { viewModel.navigateTo(it) },
                                    formatActionTrigger = formatActionTrigger,
                                    onFormatActionConsumed = { formatActionTrigger = null }
                                )
                            }
                            is Screen.Library -> {
                                LibraryScreen(
                                    viewModel = viewModel,
                                    onNavigate = { viewModel.navigateTo(it) }
                                )
                            }
                            is Screen.PdfReader -> {
                                PdfReaderScreen(
                                    bookId = screen.bookId,
                                    viewModel = viewModel,
                                    onBack = { viewModel.navigateBack() }
                                )
                            }
                            is Screen.Calendar -> {
                                CalendarScreen(viewModel = viewModel)
                            }
                            is Screen.Enthusiasm -> {
                                EnthusiasmScreen(viewModel = viewModel)
                            }
                            is Screen.Settings -> {
                                SettingsScreen(viewModel = viewModel)
                            }
                            is Screen.Sports -> {
                                SportsScreen(viewModel = viewModel)
                            }
                        }
                    }
                }

                // If rail on right (default)
                if (isRailOnRight && currentScreen !is Screen.PdfReader) {
                    RiwaqSideRail(
                        currentScreen = currentScreen,
                        sidebarColor = sidebarColor,
                        widthDp = settings.sidebarWidthDp,
                        onNavigate = { viewModel.navigateTo(it) },
                        onFoxClick = { viewModel.navigateTo(Screen.Enthusiasm) },
                        onFormatAction = { action -> formatActionTrigger = action }
                    )
                }
            }
        }
    }
}
